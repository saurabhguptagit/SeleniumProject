

import org.apache.commons.codec.binary.Hex;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/**
 *
 * @author diwakarb
 */
public class HashGeneration45jantest {

	public static String getHashKey(String[] userParams, String randomKey) {
		String generatedHashKey = null;
		String userId = userParams[0];
		String pwd = userParams[1];
		String input = userId + pwd + randomKey;
		char[] tempArray = input.toCharArray();
		Arrays.sort(tempArray);
		try {
			generatedHashKey = new HashGeneration().getSHA512SecurePassword(new String(tempArray), randomKey.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return generatedHashKey;
	}


	public String getSHA512SecurePassword(String passwordToHash, byte[] randomKey) {
		String generatedPassword = null;
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			md.update(randomKey);
			byte[] bytes = md.digest(passwordToHash.getBytes());
			generatedPassword = new String(Hex.encodeHexString(bytes));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return generatedPassword;
	}

	public static void main(String[] arg) {
		String userid = "autd32";
		String pwd = "autd32";
		String randomKey = "123";
		String input = userid + pwd +randomKey;
		char[] tempArray = input.toCharArray();
		Arrays.sort(tempArray);
		input = new String(tempArray);
		try {
			System.out.println(new HashGeneration().getSHA512SecurePassword(input, randomKey.getBytes("UTF-8")));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}
