import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.ViewName;
import org.testng.annotations.Test;

public class ExtentBASETEST {
    static ExtentTest test;
    static ExtentReports report;

    @Test
//test
    public void LoadReport() {
        String reportPath = System.getProperty("user.dir") + "/test-output/APIEXTENTREPORT.html";

        ExtentSparkReporter sparkReport = new ExtentSparkReporter(reportPath).viewConfigurer().viewOrder().as(new ViewName[]{ViewName.DASHBOARD, ViewName.TEST, ViewName.CATEGORY, ViewName.AUTHOR, ViewName.DEVICE, ViewName.EXCEPTION, ViewName.LOG})
                .apply();
        report = new ExtentReports();
        report.attachReporter(sparkReport);


//test = report.startTest("API AUTOMATION RESULTS--->");

    }

    public static void STARTTEST(String testname) {
        test = report.createTest(testname);
    }

    public static void extentReportsDemo(String status, String MSG) {

        if (status.contentEquals("INFO")) {
            test.log(Status.INFO, MSG);
        } else if (status.contentEquals("PASS")) {
            test.log(Status.PASS, MSG);
        } else if (status.contentEquals("FAIL")) {
            test.log(Status.FAIL, MSG);
        } else if (status.contentEquals("ERROR")) {
            test.log(Status.WARNING, MSG);
        }

    }


    @Test
    public void endTest() {

        report.flush();

    }
}