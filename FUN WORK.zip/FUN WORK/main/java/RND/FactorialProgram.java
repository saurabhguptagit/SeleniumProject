package RND;

/**
 * Factorial Program - Calculates factorial of a number using multiple approaches
 */
public class FactorialProgram {

    /**
     * Calculate factorial using iterative approach
     *
     * @param n the number to calculate factorial for
     * @return factorial of n
     * @throws IllegalArgumentException if n is negative
     */
    public static long calculateFactorialIterative(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Number must be non-negative");
        }
        long result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }

    /**
     * Calculate factorial using recursive approach
     *
     * @param n the number to calculate factorial for
     * @return factorial of n
     * @throws IllegalArgumentException if n is negative
     */
    public static long calculateFactorialRecursive(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Number must be non-negative");
        }
        if (n == 0 || n == 1) {
            return 1;
        }
        return n * calculateFactorialRecursive(n - 1);
    }

    /**
     * Main method - demonstrates factorial calculation
     */
    public static void main(String[] args) {
        System.out.println("=== Factorial Program ===\n");

        // Test cases
        int[] testNumbers = {0, 1, 5, 10, 15, 20};

        for (int num : testNumbers) {
            try {
                long iterativeResult = calculateFactorialIterative(num);
                long recursiveResult = calculateFactorialRecursive(num);

                System.out.println("Factorial of " + num + ":");
                System.out.println("  Iterative Approach: " + iterativeResult);
                System.out.println("  Recursive Approach: " + recursiveResult);
                System.out.println("  Both approaches match: " + (iterativeResult == recursiveResult));
                System.out.println();
            } catch (IllegalArgumentException e) {
                System.out.println("Error for number " + num + ": " + e.getMessage());
                System.out.println();
            }
        }

        // Interactive input example
        System.out.println("=== Interactive Input Example ===");
        int customNumber = 7;
        try {
            long result = calculateFactorialIterative(customNumber);
            System.out.println("Factorial of " + customNumber + " is: " + result);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
