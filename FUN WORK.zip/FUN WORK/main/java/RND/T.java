package RND;

import java.sql.*;
public class T {

    public static void checkSchedulingAPPLOG()

    {
        System.out.println("log checking in cutom app");
    }
    public static void checkrecieverLOG()

    {
        System.out.println("reciever log checking");
    }

    public static void main(String[] args) throws SQLException {
        boolean result = false;
        Connection Recievercon=null;
        String ResponseID="schon-1643881405021-28-0102";
      String Pushreciever_liveTablename="PUSH_RECEIVER_3_2_15";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    "jdbc:mysql://10.0.6.116:3306/pushstage", "root", "Root@116");

            Statement stmt = Recievercon.createStatement();

            System.out.println("Reciever Table going to chekc is "+Pushreciever_liveTablename);
            String FinalresponseID=ResponseID.replaceAll("[\\n\\t ]", "");
            ResultSet rs = stmt.executeQuery("select * from "+Pushreciever_liveTablename+"  where responseId='"+FinalresponseID+"'");
            //System.out.println("temp"+rs.getFetchSize());
            while (rs.next()) {
                System.out.println(rs.getString(4) + "  " + rs.getString(29));

                String DBResponseID = rs.getString(4);
                String RecieverStatus = rs.getString(29);
                if ((DBResponseID.contentEquals(FinalresponseID)) && (RecieverStatus.contentEquals("SUBMITTED TO SMSC")) ) {
                    System.out.println("Scheduling Request is successfully recieved and processed by Reciever");


                }


            }



        } catch (Exception e) {
            System.out.println(e);
        }
        finally {
            Recievercon.close();

        }

    }


    //30 30 13 * * ?
}
