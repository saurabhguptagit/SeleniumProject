package RND;

public class BotTask {
    private String serverHost;
    private int port = 22;
    private String username;
    private String sshKeyPath;
    private String password; // Optional
    private String logPath;
    private String analysisPrompt;
    private boolean checkSystemHealth = false;
    
    // Builder pattern
    public static class Builder {
        private BotTask task = new BotTask();
        
        public Builder server(String host) {
            task.serverHost = host;
            return this;
        }
        
        public Builder port(int port) {
            task.port = port;
            return this;
        }
        
        public Builder credentials(String username, String sshKeyPath) {
            task.username = username;
            task.sshKeyPath = sshKeyPath;
            return this;
        }
        
        public Builder credentialsWithPassword(String username, String password) {
            task.username = username;
            task.password = password;
            return this;
        }
        
        public Builder logLocation(String path) {
            task.logPath = path;
            return this;
        }
        
        public Builder customPrompt(String prompt) {
            task.analysisPrompt = prompt;
            return this;
        }
        
        public Builder includeSystemHealth(boolean include) {
            task.checkSystemHealth = include;
            return this;
        }
        
        public BotTask build() {
            if (task.serverHost == null || task.serverHost.isEmpty()) {
                throw new IllegalStateException("Server host is required");
            }
            if (task.username == null || task.username.isEmpty()) {
                throw new IllegalStateException("Username is required");
            }
            if (task.logPath == null || task.logPath.isEmpty()) {
                throw new IllegalStateException("Log path is required");
            }
            return task;
        }
    }
    
    // Getters
    public String getServerHost() { return serverHost; }
    public int getPort() { return port; }
    public String getUsername() { return username; }
    public String getSshKeyPath() { return sshKeyPath; }
    public String getPassword() { return password; }
    public String getLogPath() { return logPath; }
    public String getAnalysisPrompt() { return analysisPrompt; }
    public boolean isCheckSystemHealth() { return checkSystemHealth; }
}