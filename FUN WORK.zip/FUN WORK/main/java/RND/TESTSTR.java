package RND;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import java.io.ByteArrayOutputStream;
import java.text.ParseException;

public class TESTSTR {
    public static String RUNLINUXCOMMANDANDGETSTRING(String UNAME,String PASS,String HOSTNAME,String loglocation) throws Exception
    {
        int port = 22;

        String responseString="";
        Session session = null;
        ChannelExec channel = null;

        try {
            //old was 1000
            // Thread.sleep(1000);
            session = new JSch().getSession(UNAME, HOSTNAME, port);
            session.setPassword(PASS);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            channel = (ChannelExec) session.openChannel("exec");
            //old was 15000
            // Thread.sleep(2000);
            channel.setCommand("cd "+loglocation+"; ls -lrth;");
            //old was 10000
            //Thread.sleep(1000);
            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
            channel.setOutputStream(responseStream);
            channel.connect();

            while (channel.isConnected()) {


            }//old was 4000
            //// Thread.sleep(1000);

            responseString = new String(responseStream.toByteArray());
            //old was 2000
            // Thread.sleep(1000);


        }
        finally {
            if (session != null) {
                session.disconnect();
            }
            if (channel != null) {
                channel.disconnect();
            }

        }
        return responseString;
    }
    static JSONObject jsonObject;
    public static void main(String sa []) throws ParseException {
try {
   // String log = RUNLINUXCOMMANDANDGETSTRING("saurabhg", "saurabhg@1234", "10.0.6.94", "/Operations/YULORE/apache-tomcat-8.5.8-YuloreGateway/logs");

        /*Scanner sc = new Scanner(System.in);
        System.out.println("Enter the radius of a random circle:");
        double pie = 3.14;
        double radius = sc.nextDouble();
        double circumference = (2*pie*radius);
        int roundoff = (int) (Math.round(circumference * 100) / 100);
        System.out.println(circumference);
        System.out.println(roundoff);

String Actualcsvfile=" Aug  1 10:27 push_receiver-1-8-2022-10.csv";



        String tm=Actualcsvfile.substring(8,13);
        System.out.println("Time is-->"+tm);
        Date Actualtime=new SimpleDateFormat("HH:mm").parse(tm);
        System.out.println("Actualtime-->"+Actualtime);

        Date date = new Date();
        System.out.println("date-->"+date);
        SimpleDateFormat Expecteddatetime = new SimpleDateFormat("HH:mm");
        System.out.println("Expecteddatetime1-->"+Expecteddatetime);
        String stringDate= Expecteddatetime.format(date);
        System.out.println("stringdate-->"+stringDate);
        Date Expecteddtime=new SimpleDateFormat("HH:mm").parse(stringDate);
        System.out.println("Expectedtime-->"+Expecteddtime);

            String tilta="Hello~java";
            String newline="Hello\njava";
            System.out.println(tilta.replace('~','\n'));
           // System.out.println(newline);
            System.out.println(newline.contentEquals("Hello\njava"));*/

   // System.out.println(log);
   /* String ldata="2023-05-01 13:07:24 DEBUG :- DLRRequestListener::DLR REQUEST HANDLER::{b=34, eno=34546160, status=1, intf=0, msgdetail=, operator=TATA, mobile=918527600000, joinid=4311682926644524917, msgid=msgid-rtest1-1682926644522-2684-12, senderid=BGFEDW, bsize=0, smscflag=0, entid=rtest1, smbl=32, c=5, responseid=rtest1-1682926644524-2683-12}\n" +
            "2023-05-01 13:07:24 DEBUG :- DLRJOb::getMessageDetail::msgDetail: NA operator::TATA\n" +
            "2023-05-01 13:07:24 DEBUG :- DLRJOb::checkMnp::errorCode NA operator::TATA intflag::0\n" +
            "2023-05-01 13:07:24 INFO  :- JOINID:4311682926644524917::RESPONSEID:rtest1-1682926644524-2683-12:: FOUND IN REDIS CACHE\n" +
            "2023-05-01 13:07:24 DEBUG :- {\"uid\":\"34546160\",\"s\":\"D\",\"entId\":\"rtest1\",\"hdr\":\"{}\",\"mobile\":\"918527600000\",\"dl\":\"2023-05-01 13:07:24.579\",\"jd\":\"4311682926644524917\",\"if\":\"0\",\"dlrUrl\":\"http://10.0.6.141:6090/UrlListner/requestListener?msg_id=msgid-rtest1-1682926644522-2684-12&mobile_no=918527600000&rqst_ack_id=rtest1-1682926644524-2683-12&vendor_recv_dttime=1682926644579&sms_delv_status=delivered&sms_delv_dttime=2023-05-01+13%3A07%3A24.579&Num_Retries=1&vendor_name=ACL&msgtext=Hi+demo+testing+for+rtest1appid.&enterpriseid=rtest1&author=rtest1&subauthor=rtest1&receivedsender=BGFEDW&receivedsdate=2023-05-01+13%3A07%3A24&contenttype=1&deliveryflag=0&requestreceivedtime=2023-05-01+13%3A07%3A24&priority=3&smbl=32\",\"retry\":0,\"responseid\":\"rtest1-1682926644524-2683-12\"}";
System.out.println(ldata);



    int ind = ldata.indexOf("DEBUG :- {");
    String temp2 = ldata.substring(ind + 9);

    int JSon = temp2.indexOf("\"}");
    System.out.println("<font color=\"brown\"><b>This is the DLR JSON ---></b></font> " + temp2.substring(0, JSon + 2));

    jsonObject = (JSONObject) JSONValue.parse(temp2.substring(0, JSon + 2));
    System.out.println("Below is the DLR JSON");
    System.out.println(jsonObject);*/

//NEW CODE

  /* String testing="0074006500730074006D0065007300730061006700650020004D0061006C0061007900730069006100200049004E005A00280055002700300030003600310030003000360032003000300036003300270029";
String result="";
    for(int i=0;i<testing.length();i++)
    {
       // int index=testing.indexOf(testing.charAt(i));
        result=result+testing.charAt(i);

        if (!(i % 2 == 0))
        {
            result=result+"%";

        }

    }
    System.out.println(result);
    System.out.println(testing); */

String LG="2026-02-26 22:29:48.594 DEBUG :- FallbackRedisListener::{\"auth\":\"bajaj41\",\"language\":\"en\",\"subauth\":\"user_1\",\"ffrq\":\"60\",\"rtype\":\"Fallback\",\"routing\":\"RCS-SMS\",\"shorten\":\"FALSE\",\"alert\":\"1\",\"brd\":\"emi_reminder\",\"body_var1\":\"ABC\",\"body_var2\":\"credit card\",\"body_var3\":\"XX1234\",\"subappid\":\"bajfalt\",\"from\":\"BAJAJF\",\"body_var4\":\"50%\",\"rcshvar\":\"cute-dog\",\"text\":\"Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.\",\"body_var5\":\"body_var5\",\"dtm\":\"34564\",\"peid\":\"123456\",\"pass\":\"bajfalt31\",\"rcsbotid\":\"bajajtrans\",\"rcstd\":\"sinch_sftp_test13\",\"msgid\":\"FALLBACK_RCS_SMS\",\"userId\":\"bajfalt\",\"intflag\":\"false\",\"contenttype\":\"1\",\"tlive\":\"1200\",\"button_var1\":\"Yes\",\"appid\":\"bajfalt\",\"bsize\":\"4\",\"button_var2\":\"Yes\",\"to\":\"917838787657\",\"title_var1\":\"Grab the offer\"}\n" +
        "2026-02-26 22:29:48.598 DEBUG :- FallbackRedisListener::{\"auth\":\"bajaj41\",\"language\":\"en\",\"subauth\":\"user_1\",\"ffrq\":\"60\",\"CHANNELS_IN_REQUEST_FLAG\":true,\"rtype\":\"Fallback\",\"routing\":\"RCS-SMS\",\"shorten\":\"0\",\"alert\":\"1\",\"brd\":\"emi_reminder\",\"body_var1\":\"ABC\",\"body_var2\":\"credit card\",\"body_var3\":\"XX1234\",\"subappid\":\"bajfalt\",\"from\":\"BAJAJF\",\"body_var4\":\"50%\",\"rcshvar\":\"cute-dog\",\"text\":\"Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.\",\"body_var5\":\"body_var5\",\"dtm\":\"34564\",\"sr\":\"45\",\"peid\":\"123456\",\"pass\":\"bajfalt31\",\"rcsbotid\":\"bajajtrans\",\"rcstd\":\"sinch_sftp_test13\",\"msgid\":\"FALLBACK_RCS_SMS\",\"userId\":\"bajfalt\",\"intflag\":\"false\",\"contenttype\":\"1\",\"tlive\":\"1200\",\"button_var1\":\"Yes\",\"CHANNELSMSFLAG\":true,\"appid\":\"bajfalt\",\"bsize\":\"4\",\"button_var2\":\"Yes\",\"shorteningParams\":[{\"button_var1\":\"Yes\",\"body_var1\":\"ABC\",\"body_var2\":\"credit card\",\"body_var3\":\"XX1234\",\"rcshvar\":\"cute-dog\",\"button_var2\":\"Yes\",\"body_var4\":\"50%\",\"body_var5\":\"body_var5\",\"title_var1\":\"Grab the offer\"}],\"to\":\"917838787657\",\"title_var1\":\"Grab the offer\",\"DTO\":\"[{\\\"channelId\\\":2,\\\"channelName\\\":\\\"RCS\\\",\\\"enterpriseId\\\":\\\"bajfalt\\\",\\\"ruleId\\\":\\\"01\\\",\\\"priority\\\":0,\\\"templateId\\\":\\\"ALL\\\",\\\"processed\\\":0,\\\"completed\\\":0,\\\"waittime\\\":60,\\\"sync\\\":0,\\\"errorstatus\\\":\\\"3\\\"},{\\\"channelId\\\":0,\\\"channelName\\\":\\\"SMS\\\",\\\"enterpriseId\\\":\\\"bajfalt\\\",\\\"ruleId\\\":\\\"11\\\",\\\"priority\\\":1,\\\"templateId\\\":\\\"ALL\\\",\\\"processed\\\":0,\\\"completed\\\":0,\\\"waittime\\\":60,\\\"sync\\\":0,\\\"errorstatus\\\":\\\"F\\\"}]\",\"responseId\":\"bajfalt-1772125188595-172-110\"}\n" +
        "2026-02-26 22:29:48.599 DEBUG :- [PushReceiver-9]  DND FLAG CHANGED TO ::Request{joinId='1101772125188599172', messageId='FALLBACK_RCS_SMS', messageIdHash='1833627551', responseId='bajfalt-1772125188595-172-110', responseIdHash='-777847914', enterpriseName='bajfalt', subEnterpriseName='bajfalt', enterpriseId='34595120', subEnterpriseId='216254', author='bajaj41', subAuthor='user_1', broadcastName='emi_reminder', broadcastNameHash='-2028883408', receivedSender='BAJAJF', requestReceivedTime='1772125188599', actualSubmitTime=' ', sender='BAJAJF', submitTime=' ', receivedSubmitDate='1772125188599', mobile='917838787657', priority='0', contentId='1', messageText='Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.', orginalMessageText='Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.', smsCount='null', bearer='NA', smscByteCount='null', smscId='0', smscName='NA', status='null', statusDesc='null', statusDescNum='null', siUrl='null', misDate='null', operatorId='0', operatorName='NA', circleId='0', circleName='NA', alert='1', countryCode='null', countryName='NA', operatorSeries='null', smsCredits='null', internationalFlag='false', source='0', accountId='0', groupAccountId='null', groupAccountName='null', templateId='null', language='en', psts=true, bufferid='null', freeField1='null', freeField2='null', specificFlag=false, gmtFlag=false, templateTimingFlag=false, sourcePort='', destinationPort='', dltTempId='34564', dltPeid='null', templateCategory='null', opencategoryFlag=false, consentId='', headers=null, smppMessageIds='', deliveryFlag='0', dlrtype='', domain='', path='', forward='', shorten='0', dynamic='', ios='', android='', fallback='', intFlag='0', lastUpdateTime='1772125188599', convertedMessage='null', directPushFlag='0', mUDH='NA', mISDisplaySender='BAJAJF', duplicateMsgFlag='', schedule='', dumpInMisOnly='', ivrvflag='', bsize='4', casterparam='', alertDNDFlag='', flag=false, dumpErrorCode='', soipEnabledMsisdnFlag=false, whiteListFlag=false, bsizeFlag=false, reqSavedDltPeId='null', templateAppid='null', useCloudBuffer=false, cloudTemplateChecked=false, cloudCircleChecked=false, cloudKeywordChecked=false, broadcastBuffer=false, dltHashId=, keyName=, omsisdn=null}\n" +
        "2026-02-26 22:29:48.599 DEBUG :- RequestProcessor:: TIME TAKEN20::1101772125188599172::0\n" +
        "2026-02-26 22:29:48.600 DEBUG :- BlockedMsisdnRedisClient::Going to check global blocked status 917838787657 is false\n" +
        "2026-02-26 22:29:48.602 DEBUG :- BlockedMsisdnRedisClient::Going to check blocked status 917838787657 is false\n" +
        "2026-02-26 22:29:48.603 DEBUG :- REDIS MNP::{}\n" +
        "2026-02-26 22:29:48.603 DEBUG :- MNP TIME TAKEN::1101772125188599172::1\n" +
        "2026-02-26 22:29:48.603 INFO  :- PEID MATCH:: APPID::bajfalt::REQ::null::SYSTEM::312321311231231\n" +
        "2026-02-26 22:29:48.603 DEBUG :- RequestProcessor::run::Request{joinId='1101772125188599172', messageId='FALLBACK_RCS_SMS', messageIdHash='1833627551', responseId='bajfalt-1772125188595-172-110', responseIdHash='-777847914', enterpriseName='bajfalt', subEnterpriseName='bajfalt', enterpriseId='34595120', subEnterpriseId='216254', author='bajaj41', subAuthor='user_1', broadcastName='emi_reminder', broadcastNameHash='-2028883408', receivedSender='BAJAJF', requestReceivedTime='1772125188599', actualSubmitTime=' ', sender='BAJAJF', submitTime=' ', receivedSubmitDate='1772125188599', mobile='917838787657', priority='0', contentId='1', messageText='Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.', orginalMessageText='Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.', smsCount='null', bearer='GSM', smscByteCount='null', smscId='0', smscName='NA', status='null', statusDesc='null', statusDescNum='null', siUrl='null', misDate='null', operatorId='5', operatorName='NA', circleId='5', circleName='NA', alert='1', countryCode='null', countryName='NA', operatorSeries='null', smsCredits='null', internationalFlag='false', source='0', accountId='0', groupAccountId='null', groupAccountName='null', templateId='null', language='en', psts=true, bufferid='null', freeField1='null', freeField2='null', specificFlag=false, gmtFlag=false, templateTimingFlag=false, sourcePort='', destinationPort='', dltTempId='34564', dltPeid='312321311231231', templateCategory='0', opencategoryFlag=true, consentId='null', headers=null, smppMessageIds='', deliveryFlag='0', dlrtype='', domain='', path='', forward='', shorten='0', dynamic='', ios='', android='', fallback='', intFlag='0', lastUpdateTime='1772125188599', convertedMessage='null', directPushFlag='0', mUDH='NA', mISDisplaySender='BAJAJF', duplicateMsgFlag='', schedule='', dumpInMisOnly='', ivrvflag='', bsize='4', casterparam='', alertDNDFlag='', flag=false, dumpErrorCode='', soipEnabledMsisdnFlag=false, whiteListFlag=false, bsizeFlag=false, reqSavedDltPeId='null', templateAppid='null', useCloudBuffer=false, cloudTemplateChecked=false, cloudCircleChecked=false, cloudKeywordChecked=false, broadcastBuffer=false, dltHashId=, keyName=, omsisdn=null}\n" +
        "2026-02-26 22:29:48.603 DEBUG :- RequestProcessor:: TIME TAKEN12::1101772125188599172::4\n" +
        "2026-02-26 22:29:48.604 DEBUG :- CommanUtilities.createGSMMessageSmsCount::Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.\n" +
        "2026-02-26 22:29:48.605 DEBUG :- RP::contenttypeoneSmscount::2\n" +
        "2026-02-26 22:29:48.605 DEBUG :- makeJsonForRedis::Request{joinId='1101772125188599172', messageId='FALLBACK_RCS_SMS', messageIdHash='1833627551', responseId='bajfalt-1772125188595-172-110', responseIdHash='-777847914', enterpriseName='bajfalt', subEnterpriseName='bajfalt', enterpriseId='34595120', subEnterpriseId='216254', author='bajaj41', subAuthor='user_1', broadcastName='emi_reminder', broadcastNameHash='-2028883408', receivedSender='BAJAJF', requestReceivedTime='1772125188599', actualSubmitTime=' ', sender='BAJAJF', submitTime=' ', receivedSubmitDate='1772125188599', mobile='917838787657', priority='0', contentId='1', messageText='Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.', orginalMessageText='Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.', smsCount='2', bearer='GSM', smscByteCount='null', smscId='0', smscName='NA', status='B', statusDesc='SUBMITED TO BUFFER MANAGER', statusDescNum='null', siUrl='NA', misDate='null', operatorId='5', operatorName='HUTCH', circleId='5', circleName='DEL', alert='1', countryCode='91', countryName='INDIA', operatorSeries='9178387', smsCredits='0.0', internationalFlag='false', source='0', accountId='0', groupAccountId='0', groupAccountName='NA', templateId='NA', language='en', psts=true, bufferid='null', freeField1='null', freeField2='null', specificFlag=false, gmtFlag=false, templateTimingFlag=false, sourcePort='', destinationPort='', dltTempId='34564', dltPeid='312321311231231', templateCategory='0', opencategoryFlag=true, consentId='null', headers=null, smppMessageIds='', deliveryFlag='0', dlrtype='', domain='', path='', forward='', shorten='0', dynamic='', ios='', android='', fallback='', intFlag='0', lastUpdateTime='1772125188599', convertedMessage='null', directPushFlag='0', mUDH='NA', mISDisplaySender='BAJAJF', duplicateMsgFlag='', schedule='', dumpInMisOnly='', ivrvflag='', bsize='4', casterparam='', alertDNDFlag='', flag=false, dumpErrorCode='', soipEnabledMsisdnFlag=false, whiteListFlag=false, bsizeFlag=false, reqSavedDltPeId='null', templateAppid='null', useCloudBuffer=false, cloudTemplateChecked=false, cloudCircleChecked=false, cloudKeywordChecked=false, broadcastBuffer=false, dltHashId=, keyName=, omsisdn=null}\n" +
        "2026-02-26 22:29:48.611 DEBUG :- makeJsonForRedis::JSON::{\"tmpl\":null,\"cspErrorDesc\":null,\"channel\":\"\",\"ios\":\"\",\"bSizeFlag\":false,\"smbl\":223,\"path\":\"\",\"shorten\":\"0\",\"vsms\":\"0\",\"sch\":\"\",\"if\":\"0\",\"casterparam\":\"\",\"ac\":\"44\",\"ad\":\"2026-02-26\",\"reqSavedDltPeId\":null,\"ae\":\"5\",\"af\":\"5\",\"rcsbotid\":\"bajajtrans\",\"dumpInMisOnly\":\"\",\"broadcastBuffer\":false,\"ag\":\"HUTCH\",\"rcstd\":\"sinch_sftp_test13\",\"ai\":\"0\",\"an\":\"0\",\"cloudTemplateChecked\":false,\"as\":\"BAJAJF\",\"cloudKeywordChecked\":false,\"rh\":\"-777847914\",\"domain\":\"\",\"SMS\":\"1\",\"jd\":\"1101772125188599172\",\"mUDH\":\"NA\",\"templateAppid\":null,\"rs\":\"bajfalt-1772125188595-172-110\",\"rt\":\"2026-02-26 22:29:48.599\",\"flag\":false,\"whiteListFlag\":false,\"RCS\":\"1\",\"nsi\":\"0\",\"omd\":\"FALLBACK_RCS_SMS\",\"direct\":\"0\",\"bsz\":\"4\",\"sc\":\"2\",\"omsisdn\":null,\"CHANNELS_IN_REQUEST_FLAG\":true,\"sd\":\"SUBMITED TO BUFFER MANAGER\",\"cloudCircleChecked\":false,\"omx\":\"Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.\",\"sn\":\"NA\",\"override\":false,\"soipOnlyFlag\":false,\"dpi\":\"312321311231231\",\"cspr\":null,\"ca\":\"INDIA\",\"sr\":\"0\",\"cc\":\"91\",\"a\":\"bajaj41\",\"b\":\"GSM\",\"c\":\"1\",\"sritimetaken\":null,\"d\":\"0\",\"dhi\":\"0\",\"e\":\"2026-02-26 22:29:48.608\",\"f\":\"bajfalt\",\"forward\":\"\",\"g\":\"216254\",\"h\":\"user_1\",\"i\":\"-2028883408\",\"j\":\"emi_reminder\",\"sprt\":\"\",\"cspErrorCode\":null,\"WHATSAPP\":\"0\",\"cn\":\"DEL\",\"k\":\"1\",\"l\":\"BAJAJF\",\"m\":\"917838787657\",\"dumpErrorCode\":\"\",\"n\":\"1\",\"o\":\"2026-02-26 22:29:48.599\",\"cr\":\"0.0\",\"tc\":\"0\",\"p\":\"0\",\"td\":\"NA\",\"asb\":\"2026-02-26 22:29:48.608\",\"q\":\"0\",\"r\":\"0\",\"s\":\"B\",\"t\":\"2026-02-26 22:29:48.608\",\"u\":\"NA\",\"v\":\"n\",\"w\":\"n\",\"schedulingErrorCode\":null,\"x\":\"9178387\",\"omxf\":false,\"y\":\"\",\"z\":true,\"shorteningParams\":\"[{\\\"button_var1\\\":\\\"Yes\\\",\\\"body_var1\\\":\\\"ABC\\\",\\\"body_var2\\\":\\\"credit card\\\",\\\"body_var3\\\":\\\"XX1234\\\",\\\"rcshvar\\\":\\\"cute-dog\\\",\\\"button_var2\\\":\\\"Yes\\\",\\\"body_var4\\\":\\\"50%\\\",\\\"body_var5\\\":\\\"body_var5\\\",\\\"title_var1\\\":\\\"Grab the offer\\\"}]\",\"vlr\":1,\"soipEnabledMsisdnFlag\":false,\"data\":\"\",\"schedulingDumpFlag\":null,\"f1\":\"2026-02-26 22:29:48.608\",\"f2\":\"0\",\"PRIORITY4\":\"\",\"dt\":\"\",\"cloud\":false,\"PRIORITY2\":\"SMS\",\"dopc\":true,\"PRIORITY3\":\"\",\"PRIORITY1\":\"RCS\",\"md\":\"FALLBACK_RCS_SMS\",\"wasender\":\"\",\"csry\":false,\"dynamic\":\"\",\"mh\":\"1833627551\",\"convertedMessage\":null,\"ed\":\"34595120\",\"ml\":\"en\",\"waflag\":false,\"errorstatus\":\"NONE\",\"spf\":false,\"en\":\"bajfalt\",\"mx\":\"Dear Customer this is Transactional  (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.\",\"misdisplaySender\":\"BAJAJF\",\"sync\":2,\"nsoio\":\"0\",\"soio\":false,\"fallback\":\"\",\"DTO\":\"[{\\\"channelId\\\":2,\\\"channelName\\\":\\\"RCS\\\",\\\"enterpriseId\\\":\\\"bajfalt\\\",\\\"ruleId\\\":\\\"01\\\",\\\"priority\\\":0,\\\"templateId\\\":\\\"ALL\\\",\\\"processed\\\":0,\\\"completed\\\":0,\\\"waittime\\\":60,\\\"sync\\\":0,\\\"errorstatus\\\":\\\"3\\\"},{\\\"channelId\\\":0,\\\"channelName\\\":\\\"SMS\\\",\\\"enterpriseId\\\":\\\"bajfalt\\\",\\\"ruleId\\\":\\\"11\\\",\\\"priority\\\":1,\\\"templateId\\\":\\\"ALL\\\",\\\"processed\\\":0,\\\"completed\\\":0,\\\"waittime\\\":60,\\\"sync\\\":0,\\\"errorstatus\\\":\\\"F\\\"}]\",\"lastUpdateTime\":\"1772125188599\",\"response_code\":null,\"code\":null,\"android\":\"\",\"alertDNDFlag\":\"\",\"platform\":true,\"cit\":0,\"duplicateMsgFlag\":\"\",\"sac\":true,\"dtm\":\"34564\",\"gh\":\"0\",\"dprt\":\"\",\"gi\":\"NA\",\"ivr\":\"\",\"gk\":0,\"keyName\":\"\",\"specific\":false,\"gt\":\"0\",\"soipflag\":false,\"mnp\":\"0\",\"omsgId\":\"\",\"ifr\":\"false\",\"dcid\":\"0\",\"dhsi\":\"\",\"CHANNELSMSFLAG\":true,\"tlive\":\"1200\",\"bsize\":\"4\"}\n" +
        "2026-02-26 22:29:48.611 INFO  :- SUBMITTED::bajfalt::1101772125188599172::bajfalt-1772125188595-172-110::FALLBACK_RCS_SMS\n" +
        "2026-02-26 22:29:48.612 INFO  :- RequestProcessor:: TIME TAKEN11::1101772125188599172::13";
    String value = LG.substring(
            LG.indexOf("\"rs\":\"") + 6,
            LG.indexOf(",", LG.indexOf("\"rs\":\"") + 6)
    );



}
catch(Exception e)
{
    System.out.println(e);
}
    }
}
