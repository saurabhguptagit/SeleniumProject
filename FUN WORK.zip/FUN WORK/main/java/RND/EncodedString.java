package RND;

import java.util.Base64;

/**
 * "acltest:acltest"
 * In above the first parameter is username and second one is pwd
 */
public class EncodedString {
    public static void main(String[] args) {


        float f1[],f2[];
        f1=new float[10];
        f2=f1;
        System.out.println(f2[0]);

        System.out.println(getEncodedString("autd32:autd32"));
        System.out.println("Forex card https://www.kotak.com/en/home.html is activated. Login to Net or Mobile banking to enable for ATM com contactless transaction. Kotak Bank");
    }

    public static String getEncodedString(String token) {
        String decodedToken = null;
        try {
            byte[] decoded = Base64.getEncoder().encode(token.getBytes());
            decodedToken = new String(decoded);
            System.out.println("Engage Request::encodedString " + decodedToken);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return decodedToken == null ? token : decodedToken ;
    }


}
