package RND;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TESTSWITCH {


    public static void main(String[] args) {
        String P1 = "RCS";
        String P2 = "WA";
        String P3 = "SMS";

        // Example usage
        handleMessageType(P1);
        handleMessageType(P2);
        handleMessageType(P3);
    }

    public static void handleMessageType(String messageType) {
        switch (messageType) {
            case "SMS":
                System.out.println("Handling SMS message...");
                // Add SMS-specific logic here
                break;
            case "WA":
                System.out.println("Handling WhatsApp message...");
                // Add WhatsApp-specific logic here
                break;
            case "RCS":
                System.out.println("Handling RCS message...");
                // Add RCS-specific logic here
                break;
            default:
                //System.out.println("No priority has been set : ");
                break;
        }
    }
    }


