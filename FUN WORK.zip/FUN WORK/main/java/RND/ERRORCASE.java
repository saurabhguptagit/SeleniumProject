package RND;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.json.simple.JSONObject;

import java.io.ByteArrayOutputStream;

public class ERRORCASE {
    static JSONObject jsonObject;
    public static  void main(String sdsdsdsd[])
    {
try {
    //pushlive_push_receiver
    //pushlive_rcs_receiver
    //pushlive_whatsapp_receiver
    CHECKSQREAMLOG("pushlive_push_receiver","12-06-2024");
    CHECKSQREAMLOG("pushlive_rcs_receiver","12-06-2024");
    CHECKSQREAMLOG("pushlive_whatsapp_receiver","12-06-2024");
}
catch(Exception e)
{
    System.out.println(e);
}
    }

    public static void CHECKSQREAMLOG( String FLE,String DTE) throws Exception {


        //TestBase object = new TestBase();
        Session session = null;
        ChannelExec channel = null;

        try {
            session = new JSch().getSession("qateam", "10.0.6.110", 22);
            session.setPassword("Sqream$q@123");
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            String filename="pushlive_whatsapp_receiver";


            channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand("cd " + "/gpfssqst/disk1/error_log" + "; ls -lrth  "+FLE+"_"+DTE+"*");

            Thread.sleep(5000);
            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
            channel.setOutputStream(responseStream);
            channel.connect();

            while (channel.isConnected()) {
                //System.out.println("I am inside");
            }

            String responseString = new String(responseStream.toByteArray());


           // System.out.println(responseString);
            String arr[]=responseString.split("\n");
            Boolean sqreamerror=false;
           for(int i=0;i<arr.length;i++)
           {
              // System.out.println(arr[i]);
               String filesize=arr[i].substring(27,28);
               if(filesize.contentEquals("0"))
               {
               }
               else {
                   sqreamerror=true;
                   break;}
           }

           if(sqreamerror)
           {
               System.out.println("There is an error in file check below list ");
               System.out.println(responseString);
           }else
           {
               System.out.println("There is NO error in Sqream file");
               System.out.println(responseString);

           }


        } catch (Exception e) {
            System.out.println(e);
           // return false;
        } finally {
            if (session != null) {
                session.disconnect();
            }
            if (channel != null) {
                channel.disconnect();
            }

        }
    }
}
