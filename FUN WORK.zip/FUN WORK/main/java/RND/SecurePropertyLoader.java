package RND;

import java.io.IOException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Secure Property Loader - Resolves environment variables from properties files
 * Supports both direct values and environment variable references (${ENV_VAR})
 * 
 * Usage: 
 *   SecurePropertyLoader loader = new SecurePropertyLoader();
 *   String password = loader.getProperty("Scheduling_DB_PASS");
 */
public class SecurePropertyLoader {
    private Properties properties;
    private static final Pattern ENV_VAR_PATTERN = Pattern.compile("\\$\\{([^}]+)\\}");

    public SecurePropertyLoader() {
        properties = new Properties();
        loadProperties();
    }

    private void loadProperties() {
        try {
            properties.load(Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("coreconfig.properties"));
        } catch (IOException e) {
            throw new RuntimeException("Failed to load coreconfig.properties", e);
        }
    }

    /**
     * Get property value with environment variable resolution
     * 
     * @param key Property key
     * @return Resolved property value
     * @throws RuntimeException if referenced environment variable is not set
     */
    public String getProperty(String key) {
        String value = properties.getProperty(key);
        
        if (value == null) {
            return null;
        }
        
        // Resolve environment variables ${VAR_NAME}
        return resolveEnvironmentVariables(value);
    }

    /**
     * Resolve environment variable references in the form ${VAR_NAME}
     * 
     * @param value Value potentially containing environment variable references
     * @return Resolved value
     * @throws RuntimeException if any referenced environment variable is not set
     */
    private String resolveEnvironmentVariables(String value) {
        Matcher matcher = ENV_VAR_PATTERN.matcher(value);
        StringBuffer sb = new StringBuffer();
        
        while (matcher.find()) {
            String envVarName = matcher.group(1);
            String envVarValue = System.getenv(envVarName);
            
            if (envVarValue == null) {
                throw new RuntimeException(
                    "\n❌ ERROR: Environment variable '" + envVarName + "' is NOT set!\n\n" +
                    "Property: " + value + "\n" +
                    "Solution: Set the environment variable before running tests:\n\n" +
                    "  Windows CMD:  setx " + envVarName + " \"<value>\"\n" +
                    "  Windows PS:   [Environment]::SetEnvironmentVariable(\"" + envVarName + "\", \"<value>\")\n" +
                    "  Linux/Mac:    export " + envVarName + "=<value>\n\n" +
                    "Or run: ./setup_env_windows.bat (Windows) or ./setup_env_linux.sh (Linux)\n"
                );
            }
            
            matcher.appendReplacement(sb, Matcher.quoteReplacement(envVarValue));
        }
        
        matcher.appendTail(sb);
        return sb.toString();
    }

    /**
     * Get all properties (including resolved values)
     * 
     * @return All properties as Map<String, String>
     */
    public Properties getAllProperties() {
        Properties resolved = new Properties();
        for (String key : properties.stringPropertyNames()) {
            resolved.setProperty(key, getProperty(key));
        }
        return resolved;
    }

    /**
     * Print all resolved properties (for debugging - DO NOT print in production!)
     */
    public void printProperties() {
        System.out.println("\n=== RESOLVED PROPERTIES ===");
        for (String key : properties.stringPropertyNames()) {
            String value = getProperty(key);
            // Mask sensitive values
            if (key.contains("PASS") || key.contains("password") || key.contains("token") || key.contains("key")) {
                System.out.println(key + " = " + maskValue(value));
            } else {
                System.out.println(key + " = " + value);
            }
        }
        System.out.println("===========================\n");
    }

    private String maskValue(String value) {
        if (value == null || value.length() < 4) {
            return "****";
        }
        return value.substring(0, 2) + "****" + value.substring(value.length() - 2);
    }
}
