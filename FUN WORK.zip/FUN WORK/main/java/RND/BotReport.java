package RND;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class BotReport {
    private String serverHost;
    private String logPath;
    private String aiAnalysis;
    private Map<String, String> additionalData;
    private Date timestamp;
    private boolean success;
    private String errorMessage;
    
    public BotReport(String serverHost, String logPath, String aiAnalysis, 
                     Map<String, String> additionalData, Date timestamp) {
        this.serverHost = serverHost;
        this.logPath = logPath;
        this.aiAnalysis = aiAnalysis;
        this.additionalData = additionalData;
        this.timestamp = timestamp;
        this.success = true;
    }
    
    public static BotReport empty() {
        BotReport report = new BotReport(null, null, "No data", new HashMap<>(), new Date());
        report.success = false;
        return report;
    }
    
    public static BotReport error(String message) {
        BotReport report = new BotReport(null, null, null, new HashMap<>(), new Date());
        report.success = false;
        report.errorMessage = message;
        return report;
    }
    
    public boolean hasCriticalIssues() {
        if (aiAnalysis == null) return false;
        String lower = aiAnalysis.toLowerCase();
        return lower.contains("critical") || 
               lower.contains("error") || 
               lower.contains("failed") ||
               lower.contains("security alert");
    }
    
    public String getSummary() {
        if (!success) {
            return "Analysis failed: " + errorMessage;
        }
        return "Analysis of " + logPath + " on " + serverHost;
    }
    
    public String getFullReport() {
        StringBuilder sb = new StringBuilder();
        sb.append(repeatString("=", 80)).append("\n");
        sb.append("BOT ANALYSIS REPORT\n");
        sb.append(repeatString("=", 80)).append("\n");
        sb.append("Server: ").append(serverHost).append("\n");
        sb.append("Log Path: ").append(logPath).append("\n");
        sb.append("Timestamp: ").append(timestamp).append("\n");
        sb.append("\n");
        sb.append("AI ANALYSIS:\n");
        sb.append(repeatString("-", 80)).append("\n");
        sb.append(aiAnalysis).append("\n");
        
        if (!additionalData.isEmpty()) {
            sb.append("\n");
            sb.append("SYSTEM METRICS:\n");
            sb.append(repeatString("=", 80)).append("\n");
            additionalData.forEach((key, value) -> {
                sb.append("\n").append(key.toUpperCase()).append(":\n");
                sb.append(value).append("\n");
            });
        }

        sb.append(repeatString("=", 80)).append("\n");
        return sb.toString();
    }
    private String repeatString(String str, int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append(str);
        }
        return sb.toString();
    }
    // Getters
    public Date getTimestamp() { return timestamp; }
    public String getAiAnalysis() { return aiAnalysis; }
    public boolean isSuccess() { return success; }
}