package RND;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class AIEngine {
    //private static final String API_KEY = System.getenv("ANTHROPIC_API_KEY");
    private static final String API_KEY = "sk-ant-api03-your-key-here";
    private static final String API_URL = "https://api.anthropic.com/v1/messages";
    private CloseableHttpClient httpClient;

    public AIEngine() {
        this.httpClient = HttpClients.createDefault();

        // **CHECK IF API KEY IS SET**
        if (API_KEY == null || API_KEY.isEmpty()) {
            System.err.println("⚠️  WARNING: ANTHROPIC_API_KEY environment variable is not set!");
            System.err.println("Please set it with: export ANTHROPIC_API_KEY='your-api-key'");
        } else {
            System.out.println("✅ API Key found: " + API_KEY.substring(0, 10) + "...");
        }
    }
    public String analyze(String logContent, String customPrompt) throws Exception {
        String prompt = customPrompt != null ? customPrompt : getDefaultPrompt();

        // Build JSON request
        JSONObject message = new JSONObject()
                .put("role", "user")
                .put("content", prompt + "\n\nLOG CONTENT:\n" + logContent);

        JSONObject requestBody = new JSONObject()
                .put("model", "claude-sonnet-4-20250514")
                .put("max_tokens", 4096)
                .put("messages", new JSONArray().put(message));

        System.out.println("📤 Sending request to Anthropic API...");

        // Create HTTP POST request
        HttpPost httpPost = new HttpPost("https://api.anthropic.com/v1/messages");
        httpPost.setHeader("Content-Type", "application/json");
        httpPost.setHeader("x-api-key", "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");
        httpPost.setHeader("anthropic-version", "2023-06-01");
        httpPost.setEntity(new StringEntity(requestBody.toString(), "UTF-8"));

        // Execute request
        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
            int statusCode = response.getStatusLine().getStatusCode();
            String responseBody = EntityUtils.toString(response.getEntity());

            System.out.println("📥 API Response Status: " + statusCode);

            // **SHOW RESPONSE FOR DEBUGGING**
            if (statusCode != 200) {
                System.err.println("❌ API Error Response:");
                System.err.println(responseBody);
                throw new Exception("API request failed with status " + statusCode + ": " + responseBody);
            }

            System.out.println("Response preview: " + responseBody.substring(0, Math.min(200, responseBody.length())) + "...");

            // Parse response
            JSONObject responseJson = new JSONObject(responseBody);

            // **CHECK IF CONTENT EXISTS**
            if (!responseJson.has("content")) {
                System.err.println("❌ Response missing 'content' field!");
                System.err.println("Full response: " + responseBody);
                throw new Exception("Invalid API response format: " + responseBody);
            }

            return responseJson.getJSONArray("content")
                    .getJSONObject(0)
                    .getString("text");
        }
    }

    private String getDefaultPrompt() {
        return "Analyze these Linux server logs and provide:\n" +
               "1. Summary of log activity\n" +
               "2. All ERROR and CRITICAL level messages\n" +
               "3. Security concerns (failed logins, unauthorized access attempts)\n" +
               "4. Performance issues (high CPU, memory warnings, disk space)\n" +
               "5. Unusual patterns or anomalies\n" +
               "6. Recommended actions\n\n" +
               "Format your response as:\n" +
               "## SUMMARY\n" +
               "## CRITICAL ISSUES\n" +
               "## WARNINGS\n" +
               "## SECURITY ALERTS\n" +
               "## PERFORMANCE METRICS\n" +
               "## RECOMMENDATIONS";
    }

    public void close() throws Exception {
        if (httpClient != null) {
            httpClient.close();
        }
    }
}