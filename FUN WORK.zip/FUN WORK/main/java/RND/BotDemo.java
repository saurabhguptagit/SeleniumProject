package RND;

import java.util.Arrays;
import java.util.List;

public class BotDemo {
    
    public static void main(String[] args) {
        
        // Example 1: One-time analysis of specific log file
        example1_SingleAnalysis();
        
        // Example 2: Continuous monitoring
      //  example2_ContinuousMonitoring();
        
        // Example 3: Multiple servers
      //  example3_MultipleServers();
        
        // Example 4: Custom analysis
       // example4_CustomAnalysis();
    }
    
    static void example1_SingleAnalysis() {
        System.out.println("\n=== Example 1: Single Log Analysis ===\n");
        
        // Create bot
        AILogBot bot = new AILogBot("LogAnalyzer-Bot-1");
        
        // Configure task


        BotTask task = new BotTask.Builder()
                .server("10.0.6.207")                           // Your server IP
                .port(22)                                           // SSH port
                .credentialsWithPassword("saurabhg", "saurabhg@123") // USERNAME and PASSWORD
                .logLocation("/Operations/MAINPUSH140/apache-tomcat-10.0.21-warouter/logs/common.log")                    // Log file path
                .build();

        System.out.println("Task created successfully!");
        System.out.println("Server: " + task.getServerHost());
        System.out.println("Username: " + task.getUsername());
        System.out.println("PASSWORD: " + task.getPassword());
        System.out.println("Log Path: " + task.getLogPath());
        // Bot executes autonomously
        BotReport report = bot.executeAnalysis(task);
        
        // Display results
        System.out.println(report.getFullReport());
    }
    
    static void example2_ContinuousMonitoring() {
        System.out.println("\n=== Example 2: Continuous Monitoring ===\n");
        
        AILogBot bot = new AILogBot("Monitor-Bot");
        
        BotTask task = new BotTask.Builder()
            .server("production-server.company.com")
            .credentials("monitoring", "/etc/ssh/monitoring_key")
            .logLocation("/var/log/application/app.log")
            .includeSystemHealth(true)
            .build();
        
        // Bot monitors every 5 minutes
        bot.startContinuousMonitoring(task, 5);
        
        // Run for 1 hour then stop
        try {
            Thread.sleep(3600000);
            bot.stopMonitoring();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    static void example3_MultipleServers() {
        System.out.println("\n=== Example 3: Multiple Servers ===\n");
        
        List<BotTask> tasks = Arrays.asList(
            new BotTask.Builder()
                .server("web-server-1.com")
                .credentials("bot", "/keys/web1.pem")
                .logLocation("/var/log/nginx/error.log")
                .build(),
                
            new BotTask.Builder()
                .server("db-server-1.com")
                .credentials("bot", "/keys/db1.pem")
                .logLocation("/var/log/mysql/error.log")
                .build(),
                
            new BotTask.Builder()
                .server("app-server-1.com")
                .credentials("bot", "/keys/app1.pem")
                .logLocation("/var/log/tomcat/catalina.out")
                .build()
        );
        
        // Create bot fleet
        tasks.forEach(task -> {
            AILogBot bot = new AILogBot("Bot-" + task.getServerHost());
            new Thread(() -> {
                BotReport report = bot.executeAnalysis(task);
                System.out.println(report.getFullReport());
            }).start();
        });
    }
    
    static void example4_CustomAnalysis() {
        System.out.println("\n=== Example 4: Custom Security Analysis ===\n");
        
        AILogBot bot = new AILogBot("Security-Bot");
        
        String customPrompt = "Perform a security-focused analysis of these authentication logs:\n" +
                "1. Identify all failed login attempts\n" +
                "2. Detect brute force attack patterns\n" +
                "3. List successful logins from unusual IP addresses\n" +
                "4. Check for privilege escalation attempts\n" +
                "5. Flag any suspicious user activity\n" +
                "            \n" +
                "Provide severity ratings (LOW/MEDIUM/HIGH/CRITICAL) for each finding.";
        
        BotTask task = new BotTask.Builder()
            .server("10.0.6.207")
            .credentials("saurabhg", "saurabhg@123")
            .logLocation("/Operations/MAINPUSH140/apache-tomcat-10.0.21-router/logs/common.log")
            .customPrompt(customPrompt)
            .build();
        
        BotReport report = bot.executeAnalysis(task);
        System.out.println(report.getFullReport());
    }
}