package RND;

import java.io.FileInputStream;
import java.io.IOException;

public class learningjava {

    public static void main(String[] args) throws IOException {

String temp="PUSH_RECEIVER_12_1_13";
String splt []=temp.split("_");
System.out.println("Current hour "+splt[4]);
System.out.println("Hi {#var#}, \n" +
        "\n" +
        "Your MTD performance stands at:\n" +
        "1. Logins of {#var#}Cr ~ {#var#} (Count)\n" +
        "2. Weighted avg ROI at {#var#}%\n" +
        "3. With an average ticket size of {#var#} Cr.\n" +
        "4. And, Monthly productivity at {#var#} Cr. -Nido Home Finance Limited");
int previoushour=Integer.parseInt(splt[4])-1;

System.out.println("Previous hour "+previoushour);
String tblename=splt [0]+"_"+splt [1]+"_"+splt [2]+"_"+splt [3]+"_"+previoushour;
        System.out.println("Previous hour table name "+tblename);

        System.out.println("{\"auth\":\"bajaj22\",\"language\":\"en\",\"subauth\":\"user_1\",\"ffrq\":\"1260\",\"rtype\":\"Single\",\"routing\":\"RCS\",\"shorten\":\"FALSE\",\"alert\":\"1\",\"brd\":\"emi_reminder\",\"body_var1\":\"ABC\",\"body_var2\":\"credit card\",\"body_var3\":\"XX1234\",\"subappid\":\"bajfalt\",\"body_var4\":\"50%\",\"rcshvar\":https://www.google.com/search?gs_ssp=eJzj4tTP1TcwykipyjFg9OIozsjMS85IzAMARUwGwg&q=shinchan&rlz=1C1GCEA_enIN1154IN1154&oq=sinch&gs_lcrp=EgZjaHJvbWUqEQgBEC4YChgLGNQCGLEDGIAEMgYIABBFGEEyEQgBEC4YChgLGNQCGLEDGIAEMgYIAhBFGDwyBggDEEUYPDIGCAQQRRg8MgYIBRBFGEEyBggGEEUYQTIGCAcQRRg80gEIMzAyM2owajeoAgiwAgHxBfD2rHvL2WXC&sourceid=chrome&ie=UTF-8#vhid=FaH7a5aGI9halM&vssid=_enkUaYvtLuWfseMP1ZHY0A4_73,\"body_var5\":\"body_var5\",\"pass\":\"bajfalt31\",\"rcsbotid\":\"bajajtrans\",\"rcstd\":\"sinch_sftp_test1\",\"msgid\":\"absc346dneo3dmfe9\",\"userId\":\"bajfalt\",\"intflag\":\"false\",\"contenttype\":\"3\",\"tlive\":\"1200\",\"button_var1\":\"Yes\",\"appid\":\"bajfalt\",\"bsize\":\"4\",\"button_var2\":\"Yes\",\"to\":\"917838787657\",\"title_var1\":\"Grab the offer\"}");

        FileInputStream st=new FileInputStream("E:\\IdeaProjects\\TestMaven\\src\\main\\java\\RND\\data.txt");

    }



}