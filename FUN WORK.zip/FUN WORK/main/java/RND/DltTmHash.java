package RND;

import org.apache.commons.lang3.StringUtils;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DltTmHash {

//sinch tmid --->120210000043

    private static String peid="213123121231";//"" 54444444444433
    private  static String tmid="120210000043";

    public static String getHash() {
        try {
            String tm1="1302157294286523005";
            String tm2="";//"1302157294286523006";
            String tm3="1302157294286523007";//"1302157294286523007";

            String input="";
            if(StringUtils.isNotEmpty(tm1)) {
                input = peid + "," + tm1;
            }
            if(StringUtils.isNotEmpty(tm2)) {

                if(StringUtils.isEmpty(tm1))
                {
                    input = peid + "," + tm2;
                }else {
                    input = input + "," + tm2;
                }
            }


            if(StringUtils.isNotEmpty(tm3)) {

                if(StringUtils.isEmpty(tm2) && StringUtils.isEmpty(tm1))
                {
                    input = peid + "," + tm3;
                }else {
                    input = input + "," + tm3;
                }
            }

            if (StringUtils.isNotEmpty(input)) {
                System.out.println("this is the case when TM1  ,TM2, TM3 are PRESENT with respective values as TM1 = "+tm1+" TM2= "+tm2+" TM3= "+tm3);
                input = input + "," + tmid;
                System.out.println("Hash will be generated on base of "+input);
                return getHash(input);
            }
        } catch (Exception e) {
        }
        try {
            System.out.println("this is the case when TM1 ,TM2, TM3 are blank");

            String input = new StringBuilder(peid).append(",").append(tmid).toString();
            System.out.println("Hash will be generated on base of "+input);
            return getHash(input);
        } catch (Exception e) {
        }
        return null;
    }

    public static byte[] getSHA(String input) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    public static String toHexString(byte[] hash) {
        BigInteger number = new BigInteger(1, hash);
        StringBuilder hexString = new StringBuilder(number.toString(16));
        while (hexString.length() < 64) {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }

    public static String convertByteToHexadecimal(byte[] byteArray) {
        String hex = "";
        for (byte i : byteArray) {
            hex += String.format("%02X", i);
        }
        return hex;
    }

    static String  getHash(String input) {
        String hash = "";
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] valbyte = messageDigest.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder(2 * valbyte.length);
            for (byte b : valbyte) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            hash = hexString.toString();
        } catch (Exception e) {
        }
        return hash;
    }


    public static void main(String[] arg) throws NoSuchAlgorithmException {


        String val3=getHash();
        System.out.println(val3);

    }

}
