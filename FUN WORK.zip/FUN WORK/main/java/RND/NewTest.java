package RND;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class NewTest {

    public static String getMD5(String key) {
        String digest = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(key.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder(hash.length + 10);
            for (byte b : hash) {
                sb.append(String.format("%02x", b & 0xff));
            }
            digest = sb.toString();
        } catch (UnsupportedEncodingException ex) {
        } catch (NoSuchAlgorithmException ex) {
        } catch (Exception ex) {
        }
        return digest;
    }
public static void main(String asa[])


{
    System.out.println(getMD5("semaalt"));




    try {
        LocalDateTime S = LocalDateTime.now().plusMinutes(5);
        DateTimeFormatter PP = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
        String Schedule = S.format(PP);

        LocalDateTime E = LocalDateTime.now().plusMinutes(10);

        String Expire = E.format(PP);

        System.out.println(" Scheduled time is  "+Schedule);
        System.out.println(" Expired time is  "+Expire);

        int Schedulemonth=Integer.parseInt(Schedule.substring(4,6));
       // System.out.println("Month is"+Schedulemonth);

        int Scheduleday=Integer.parseInt(Schedule.substring(6,8));

        //System.out.println("Date is-->"+Scheduleday);

        int ScheduleHour=Integer.parseInt(Schedule.substring(8,10));

       // System.out.println("Hour is-->"+ScheduleHour);
        String Pushlivetablename="PUSH_RECEIVER_"+Scheduleday+"_"+Schedulemonth+"_"+ScheduleHour;

        String  ph[]=new String[10];
        ph[1]="9838301908";
        System.out.println(" HHHHHHHH  "+ ph[1]);
    }
    catch(Exception e)
    {
        System.out.println(e);
    }
}
}