package RND;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;

public class XML_OPERATIONS_RND
{
    public static void main(String sas[])
    {
       // REMOVE_NODE_ICICI("messageTxt","ICICI.xml");
        //ADD_NODE_ICICI("messageTxt","TEST MSG","ICICI.xml");

        //ADD_ATTRIBUTE_ICICI("ATT","12","PPP.xml");
        //REMOVE_ATTRIBUTE_ICICI("ATT","ICICI.xml");

      // setXML_ICICI("functionname", "TESTUserID007", "TESTPassd007", "TESTUserID242244", "TESTSENDER45345", "TESTTO", "XMAS", "1", "TESTSELFID534535", "TESTINTFLAG534545", "1", "TESTLanguage", "ICICI.xml", "54666");

        READTEMPXML();
    }


public static  void readresponse()
{

}
    public static void READTEMPXML() {
        try {


            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + "PPP.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.parse(filepath);

           // Document doc = docBuilder.parse(filepath(xml.getBytes("UTF-8")));



                Node code = doc.getElementsByTagName("CODE").item(0);
               System.out.println(code.getTextContent());







            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory
                    .newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            // System.out.println("Done");

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void setXML_ICICI(String functionname, String UserID, String Passd, String APPID, String SENDER, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String finlename, String MSG_ID) {
        try {

            String SCTYPE = "";

           /* if (TO.contentEquals("BLK") || TO.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE_ICICI("msisdn", finlename);
            }*/

            if (MSG.contentEquals("BLK") || MSG.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("messageTxt", finlename);

            }
           /* if (Contenttype.contentEquals("BLK")) {

            } else if (Contenttype.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("content-type", finlename);
            } else {

                double ctype = Double.parseDouble(Contenttype);
                int ictype = (int) (Math.round(ctype * 100) / 100);
                SCTYPE = String.valueOf(ictype);
            }*/

            if (INTFLAG.contentEquals("BLK")) {
                INTFLAG = "";
            }
            if (UserID.contentEquals("BLK")) {
                UserID = "";
            } else if (UserID.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE_ICICI("ClientCode", finlename);
            }

           /* if (UserID.contentEquals("BLK")) {
                UserID = "";
            } else if (UserID.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("userid", finlename);
            }  */
            if (Passd.contentEquals("BLK")) {
                Passd = "";
            } else if (Passd.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE_ICICI("pin", finlename);
            }


            if (SENDER.contentEquals("BLK")) {
                SENDER = "";
            } else if (SENDER.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("fromAddress", finlename);
            }

            String AALERT = "";
            if (ALERT.contentEquals("BLK")) {
                AALERT = "";
            } else if (ALERT.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("alert", finlename);
            } else {

                double ALERTtype = Double.parseDouble(ALERT);
                int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
                AALERT = String.valueOf(iALERTtype);
            }


            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            double random = Math.random();

            double x = random * 1000000;

            int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
            if (!MSG_ID.contentEquals("BLK")) {
                MSGID = Integer.parseInt(MSG_ID);
            }
            if (functionname.contains("MESSAGEID_TAGMISS")) {
                REMOVE_NODE_ICICI("messageID", finlename);
            }

            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + finlename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);




            if (!functionname.contains("MESSAGEID_TAGMISS")) {
                Node msgid = doc.getElementsByTagName("messageID").item(0);
                msgid.setTextContent(String.valueOf(MSGID));

            }


            if (!SENDER.contentEquals("MISS")) {
                Node FROM = doc.getElementsByTagName("fromAddress").item(0);
                FROM.setTextContent(SENDER);
            }

            if (!UserID.contentEquals("MISS")) {
                System.out.println("set userid"+ UserID);
                Node request = doc.getElementsByTagName("request").item(0);
                System.out.println("-->");
                System.out.println("attribute tag"+request.getNodeName());
                ((Element) request).setAttribute("ClientCode", UserID);

            }
            if (!Passd.contentEquals("MISS")) {
                System.out.println("set passwd"+ Passd);

                Node request = doc.getElementsByTagName("request").item(0);
                System.out.println("-->");
                System.out.println("attribute tag"+request.getNodeName());
                ((Element) request).setAttribute("pin", Passd);

            }

           /* if (!APPID.contentEquals("MISS")) {


                REMOVE_ATTRIBUTE_ICICI("ClientCode","ICICI.xml");
                ADD_ATTRIBUTE_ICICI("ClientCode",UserID,"ICICI.xml");
            }*/

           /* Node SUBAPP_ID = doc.getElementsByTagName("subappid").item(0);
            SUBAPP_ID.setTextContent(APPID);
            if (!Contenttype.contentEquals("MISS")) {
                Node CTYPE = doc.getElementsByTagName("content-type").item(0);
                CTYPE.setTextContent(SCTYPE);
            }
*/
            if (!ALERT.contentEquals("MISS")) {
                Node alert = doc.getElementsByTagName("alert").item(0);
                alert.setTextContent(ALERT);
            }

            if (!MSG.contentEquals("MISS")) {
                Node msg = doc.getElementsByTagName("messageTxt").item(0);
                msg.setTextContent(MSG);
            }


            Node Intflag = doc.getElementsByTagName("intflag").item(0);
            Intflag.setTextContent(INTFLAG);

           /* int lenth = doc.getElementsByTagName("detail").getLength();
            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);
                if (MSG.contentEquals("MISS")) {
                    //do nothing
                } else if (MSG.contentEquals("BLK")) {
                    //do nothing
                } else {
                    MULTISMS.getAttributes().item(2).setTextContent(MSG);
                }
                MULTISMS.getAttributes().item(1).setTextContent(Language);
            } */

            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory
                    .newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            // System.out.println("Done");

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void REMOVE_NODE_ICICI(String NodeTagname, String FILENAME) {
        String temvalue = "";
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + FILENAME;//XmlLangaugeAPIListenerNegative.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);



            Node publishData=doc.getElementsByTagName("publishData").item(0);

            System.out.println(publishData.getNodeName());
            temvalue = doc.getElementsByTagName(NodeTagname).item(0).getTextContent();

            System.out.println("Node-->"+NodeTagname+" value-->"+temvalue);
            System.out.println("To bedeleted node-->"+doc.getElementsByTagName(NodeTagname).item(0).getNodeName());

            System.out.println("To bedeleted node2-->"+doc.getElementsByTagName(NodeTagname).item(0));

            publishData.removeChild(doc.getElementsByTagName(NodeTagname).item(0));

            //publishData.removeChild(doc.getElementsByTagName(NodeTagname).item(0));

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);


        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void ADD_NODE_ICICI(String NodeTagname, String Nodevalue, String FILENAME) {
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + FILENAME;//XmlLangaugeAPIListenerNegative.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            // Get the root element
            Element name = doc.createElement(NodeTagname);
            Node publishData=doc.getElementsByTagName("publishData").item(0);
            publishData.appendChild(name);
            name.setTextContent(Nodevalue);

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void REMOVE_ATTRIBUTE_ICICI(String attributename, String filename) {
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + filename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);


            Node request = doc.getElementsByTagName("request").item(0);
            System.out.println("-->");
            request.getAttributes().removeNamedItem(attributename);



            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);


        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void ADD_ATTRIBUTE_ICICI(String attributename, String value, String filename) {
        try {

            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + filename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

           /* int lenth = doc.getElementsByTagName("detail").getLength();
            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);
                ((Element) MULTISMS).setAttribute(attributename, value);
            }*/



            Node request = doc.getElementsByTagName("request").item(0);
            System.out.println("-->");
            System.out.println("attribute tag"+request.getNodeName());
            ((Element) request).setAttribute(attributename, value);

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);


        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
















}