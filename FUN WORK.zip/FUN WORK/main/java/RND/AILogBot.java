package RND;

import com.jcraft.jsch.*;
import java.io.*;
import java.util.*;

public class AILogBot {
    private String botName;
    private SSHConnection sshConnection;
    private AIEngine aiEngine;
    private boolean isRunning;

    public AILogBot(String botName) {
        this.botName = botName;
        this.sshConnection = new SSHConnection();
        this.aiEngine = new AIEngine();
        this.isRunning = false;
    }

    /**
     * Bot autonomously logs in and analyzes logs
     */
    public BotReport executeAnalysis(BotTask task) {
        log("🤖 Bot starting analysis task...--->");
System.out.println(task.getServerHost());
        System.out.println(task.getUsername());
        System.out.println(task.getPassword());
        System.out.println(task.getPort());

        try {
            // Step 1: Bot logs into server
            log("📡 Logging into server: " + task.getServerHost());
            sshConnection.connectWithPassword(
                task.getServerHost(),
                task.getUsername(),
                task.getPassword(),
                task.getPort()
            );


            log("✅ Successfully connected!");

            // Step 2: Bot navigates to log location
            log("📂 Accessing log location: " + task.getLogPath());
            String logContent = sshConnection.readFile(task.getLogPath());

            if (logContent == null || logContent.isEmpty()) {
                log("⚠️ No log content found at " + task.getLogPath());
                return BotReport.empty();
            }

            log("📊 Retrieved " + logContent.split("\n").length + " log lines");

            // Step 3: Bot analyzes with AI
            log("🧠 AI analysis in progress...");
            String aiAnalysis = aiEngine.analyze(logContent, task.getAnalysisPrompt());

            // Step 4: Bot performs additional checks if needed
            Map<String, String> additionalData = new HashMap<>();
            if (task.isCheckSystemHealth()) {
                log("💊 Checking system health...");
                additionalData.put("disk_usage", sshConnection.executeCommand("df -h"));
                additionalData.put("memory", sshConnection.executeCommand("free -h"));
                additionalData.put("processes", sshConnection.executeCommand("ps aux --sort=-%cpu | head -10"));
            }

            // Step 5: Bot disconnects
            sshConnection.disconnect();
            log("🔌 Disconnected from server");

            // Step 6: Bot compiles report
            BotReport report = new BotReport(
                task.getServerHost(),
                task.getLogPath(),
                aiAnalysis,
                additionalData,
                new Date()
            );

            log("✅ Bot analysis completed successfully!");
            return report;

        } catch (Exception e) {
            log("❌ Bot encountered error: " + e.getMessage());
            e.printStackTrace();
            return BotReport.error(e.getMessage());
        }
    }

    /**
     * Bot runs continuous monitoring
     */
    public void startContinuousMonitoring(BotTask task, long intervalMinutes) {
        isRunning = true;
        log("🚀 Bot starting continuous monitoring (interval: " + intervalMinutes + " min)");
        
        new Thread(() -> {
            while (isRunning) {
                try {
                    BotReport report = executeAnalysis(task);
                    
                    // Bot decides if alert is needed
                    if (report.hasCriticalIssues()) {
                        sendAlert(report);
                    }
                    
                    // Save report
                    saveReport(report);
                    
                    // Wait for next cycle
                    Thread.sleep(intervalMinutes * 60 * 1000);
                    
                } catch (Exception e) {
                    log("❌ Monitoring error: " + e.getMessage());
                }
            }
        }).start();
    }
    
    public void stopMonitoring() {
        isRunning = false;
        log("🛑 Bot stopped monitoring");
    }
    
    private void log(String message) {
        System.out.println("[" + botName + "] " + new Date() + " - " + message);
    }
    
    private void sendAlert(BotReport report) {
        // Implement alerting (email, Slack, etc.)
        System.out.println("🚨 ALERT: " + report.getSummary());
    }
    
    private void saveReport(BotReport report) {
        // Save to database or file
        System.out.println("💾 Report saved: " + report.getTimestamp());
    }
}