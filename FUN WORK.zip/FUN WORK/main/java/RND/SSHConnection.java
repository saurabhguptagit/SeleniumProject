package RND;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class SSHConnection {
    private Session session;
    private static final int TIMEOUT = 30000;
    
    public void connect(String host, String username, String keyPath, int port) 
            throws JSchException {
        JSch jsch = new JSch();
        
        // Add SSH key
        jsch.addIdentity(keyPath);
        
        // Create session
        session = jsch.getSession(username, host, port);
        
        // Configure
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        config.put("PreferredAuthentications", "publickey");
        session.setConfig(config);
        session.setTimeout(TIMEOUT);
        
        // Connect
        session.connect();
    }
    
    public void connectWithPassword(String host, String username, String password, int port) 
            throws JSchException {
        JSch jsch = new JSch();
        session = jsch.getSession(username, host, port);
        session.setPassword(password);
        
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        session.setTimeout(TIMEOUT);
        
        session.connect();
    }
    
    public String readFile(String filePath) throws JSchException, IOException {
        return executeCommand("cat " + filePath);
    }
    
    public String readLastLines(String filePath, int lines) throws JSchException, IOException {
        return executeCommand("tail -n " + lines + " " + filePath);
    }
    
    public String readLinesInTimeRange(String filePath, String startTime, String endTime) 
            throws JSchException, IOException {
        String command = String.format(
            "awk '/%s/,/%s/' %s", 
            startTime, endTime, filePath
        );
        return executeCommand(command);
    }
    
    public String executeCommand(String command) throws JSchException, IOException {
        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        channel.setCommand(command);
        
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ByteArrayOutputStream errorStream = new ByteArrayOutputStream();
        
        channel.setOutputStream(outputStream);
        channel.setErrStream(errorStream);
        
        channel.connect();
        
        // Wait for command to complete
        while (!channel.isClosed()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        channel.disconnect();
        
        String error = errorStream.toString();
        if (!error.isEmpty()) {
            System.err.println("Command stderr: " + error);
        }
        
        return outputStream.toString();
    }
    
    public boolean fileExists(String filePath) throws JSchException, IOException {
        String result = executeCommand("test -f " + filePath + " && echo 'exists' || echo 'not found'");
        return result.trim().equals("exists");
    }
    
    public List<String> listLogFiles(String directory) throws JSchException, IOException {
        String result = executeCommand("find " + directory + " -name '*.log' -type f");
        return Arrays.asList(result.split("\n"));
    }
    
    public void disconnect() {
        if (session != null && session.isConnected()) {
            session.disconnect();
        }
    }
}