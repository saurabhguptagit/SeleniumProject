package RND;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class EncrypterV2 {

	private final String characterEncoding = "UTF-8";
	private final String cipherTransformation = "AES/CBC/PKCS5Padding";
	private final String aesEncryptionAlgorithm = "AES";
	private final Base64 base64 = new Base64();

	public byte[] decrypt(byte[] cipherText, byte[] key, byte[] initialVector)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(cipherTransformation);
		SecretKeySpec secretKeySpecy = new SecretKeySpec(key, aesEncryptionAlgorithm);
		IvParameterSpec ivParameterSpec = new IvParameterSpec(initialVector);
		cipher.init(Cipher.DECRYPT_MODE, secretKeySpecy, ivParameterSpec);
		cipherText = cipher.doFinal(cipherText);
		return cipherText;
	}

	public byte[] encrypt(byte[] plainText, byte[] key, byte[] initialVector)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(cipherTransformation);
		SecretKeySpec secretKeySpec = new SecretKeySpec(key, aesEncryptionAlgorithm);
		IvParameterSpec ivParameterSpec = new IvParameterSpec(initialVector);
		cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
		plainText = cipher.doFinal(plainText);
		return plainText;
	}

	private byte[] getIVKeyBytes(String key) throws UnsupportedEncodingException {
		byte[] keyBytes = new byte[16];
		byte[] parameterKeyBytes = key.getBytes(characterEncoding);
		System.arraycopy(parameterKeyBytes, 0, keyBytes, 0, Math.min(parameterKeyBytes.length, keyBytes.length));
		return keyBytes;
	}

	public String encrypt(String plainText, String key)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		byte[] plainTextbytes = plainText.getBytes(characterEncoding);
		byte[] keyBytes = getIVKeyBytes(key);
		return base64.encodeToString(encrypt(plainTextbytes, keyBytes, keyBytes));
	}

	public String decrypt(String encryptedText, String key) throws KeyException, GeneralSecurityException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {
		byte[] cipheredBytes = new Base64().decode(encryptedText);
		byte[] keyBytes = getIVKeyBytes(key);
		return new String(decrypt(cipheredBytes, keyBytes, keyBytes), characterEncoding);
	}

	public static void main(String[] arg) {
		//String input = "{\"pass\":\"autd32\",\"language\":\"hi\",\"userId\":\"autd32\",\"intflag\":\"FALSE\",\"contenttype\":\"1\",\"alert\":\"1\",\"brd\":\"broadcastname\",\"appid\":\"autd32\",\"selfid\":\"TRUE\",\"bsize\":\"1\",\"alertdnd\":\"1\",\"messages\":[{\"msg\":\"THIS IS DAR TEST AUTOMATION CASE32\",\"from\":\"autd32\",\"language\":\"en\",\"id\":\"0\",\"to\":\"919560237024\"}],\"subappid\":\"autd32\",\"to\":\"919560237024\"}";
		String input = "{\"pass\":\"brigenpro13\",\"language\":\"en\",\"userId\":\"brigenpro\",\"intflag\":\"FALSE\",\"contenttype\":\"1\",\"alert\":\"0\",\"brd\":\"broadcastname\",\"appid\":\"brigenpro\",\"selfid\":\"TRUE\",\"bsize\":\"1\",\"messages\":[{\"msg\":\"Premium 2 & 3 BHKs from 86.5L at Brigade Horizon, Mysore Rd. Free modular kitchen, few units left, excellent connectivity. Call 08046474042 now.\",\"from\":\"202127\",\"language\":\"en\",\"id\":\"0\",\"to\":\"8809949589\"}],\"subappid\":\"brigenpro\"}";

		String key = "brigenpro120115766";//""testdlt301291009";

		try {
			String encrypt = new EncrypterV2().encrypt(input, key);
			System.out.println(encrypt);
			System.out.println("");
			System.out.println(new EncrypterV2().decrypt(encrypt, key));

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

