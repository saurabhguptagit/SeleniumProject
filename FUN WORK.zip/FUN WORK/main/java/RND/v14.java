package RND; /**
 * 
 */
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * 
 */
class V14 {
	/* Private variable declaration */ 
	private static final String SALTVALUE = "ab1223234cdefg"; 
	/* Encryption Method */ 
	public static String encrypt(String strToEncrypt,String key) {
		try { 
			/* Declare a byte array. */ 
			byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; 
			IvParameterSpec ivspec = new IvParameterSpec(iv); 
			/* Create factory for secret keys. */ 
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256"); 
			/* PBEKeySpec class implements KeySpec interface. */ 
			KeySpec spec = new PBEKeySpec(key.toCharArray(), SALTVALUE.getBytes(), 20, 256);
			SecretKey tmp = factory.generateSecret(spec); 
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES"); 
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding"); 
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec); 
			/* Retruns encrypted value. */ 
			return Base64.getEncoder()
					.encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8))); 
		} 
		catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException e) {
			System.out.println("Error while encryption the json");
		} 
		return null;
	} 
	/* Decryption Method */ 
	public static String decrypt(String strToDecrypt,String key) {
		try{
			/* Declare a byte array. */ 
			byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; 
			IvParameterSpec ivspec = new IvParameterSpec(iv); 
			/* Create factory for secret keys. */ 
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256"); 
			/* PBEKeySpec class implements KeySpec interface. */ 
			KeySpec spec = new PBEKeySpec(key.toCharArray(), SALTVALUE.getBytes(), 20, 256);
			SecretKey tmp = factory.generateSecret(spec); 
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES"); 
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING"); 
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec); 
			/* Retruns decrypted value. */ 
			return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt))); 
		} 
		catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException e){
			System.out.println("Error while encryption the json");
		} 
		return null;
	}

	public static void main (String arg[]) {
		String input = "{\n" +
				"\"appid\":\"cntdlt\",\n" +
				"\"userId\":\"cntdlt\",\n" +
				"\"alertdnd\":\"0\",\n" +
				"\"pass\":\"cntdlt\",\n" +
				"\"contenttype\":\"1\",\n" +
				"\"from\":\"cntdlt\",\n" +
				"\"to\":\"9612323233\",\n" +
				"\"alert\":\"1\",\n" +
				"\"selfid\":\"true\",\n" +
				//"\"msgid\":\"123\",\n" +
				//"\"intflag\":\"false\",\n" +
				"\"text\":\"This is to test country codeINT234\",\n" +
				//"\"dtm\":\"1007055219711593958\",\n" +
				//"\"dpi\":\"110100001341\",\n" +
				"\"keyname1\":\"AngelOne\",\n" +
				"\"keyname2\":\"Campaign001\",\n" +
				"\"keyname3\":\"Mumbai\",\n" +
				"\"keyname4\":\"Trade\",\n" +
				"\"keyname5\":\"Customer\",\n" +
				"\"keyname6\":\"Premium\",\n" +
				"\"keyname7\":\"Mobile\",\n" +
				"\"keyname8\":\"SMS\",\n" +
				"\"keyname9\":\"Test\",\n" +
				"\"keyname10\":\"API\",\n" +
				//"\"country_code\":\"9\"\n" +
				"}";  //968809876876598
		String key = "testdlt301291009";
		//"dltHashId":"3D65d26391942624febeaeb7d35dcbf21cddf4636441ff20891dc60b4e9c30e21b",
		//String key = "axispdalt100001341";

		/*


              String input = "{\n" +
				"\"appid\":\"axsaltuat\",\n" +
				"\"userId\":\"axsaltuat\",\n" +
				"\"alertdnd\":\"0\",\n" +
				"\"pass\":\"axis_20\",\n" +
				"\"contenttype\":\"1\",\n" +
				"\"from\":\"AXISBK\",\n" +
				"\"to\":\"+7838787657\",\n" +
				"\"alert\":\"1\",\n" +
				"\"selfid\":\"true\",\n" +
				//"\"msgid\":\"123\",\n" +
				//"\"intflag\":\"true\",\n" +
				"\"text\":\"Thank You for showing interest. Our representative will contact you shortly.\",\n" +
				//"\"dtm\":\"1007055219711593958\",\n" +
				//"\"dpi\":\"110100001341\",\n" +
				"\"keyname1\":\"AngelOne\",\n" +
				"\"keyname2\":\"Campaign001\",\n" +
				"\"keyname3\":\"Mumbai\",\n" +
				"\"keyname4\":\"Trade\",\n" +
				"\"keyname5\":\"Customer\",\n" +
				"\"keyname6\":\"Premium\",\n" +
				"\"keyname7\":\"Mobile\",\n" +
				"\"keyname8\":\"SMS\",\n" +
				"\"keyname9\":\"Test\",\n" +
				"\"keyname10\":\"API\",\n" +
				"\"country_code\":\"91\"\n" +
				"}";  //968809876876598
		*/
		//String key = "testdlt301291009";
		//"dltHashId":"3D65d26391942624febeaeb7d35dcbf21cddf4636441ff20891dc60b4e9c30e21b",
		//String key = "axispdalt100001341";


		try {
			String encrypt=encrypt(input, key);
			System.out.println("encrypted string:::"+encrypt);
		
			
			System.out.println("decrypted string:::"+decrypt(encrypt, key));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}