package RND; /**
 * 
 */
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * 
 */

//v14 Encrypted  file.
public class TestEncryptionV14NEW {
	/* Private variable declaration */ 
	private static final String SALTVALUE = "ab1223234cdefg"; 
	/* Encryption Method */ 
	public static String encrypt(String strToEncrypt,String key) {
		try { 
			/* Declare a byte array. */ 
			byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; 
			IvParameterSpec ivspec = new IvParameterSpec(iv); 
			/* Create factory for secret keys. */ 
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256"); 
			/* PBEKeySpec class implements KeySpec interface. */ 
			KeySpec spec = new PBEKeySpec(key.toCharArray(), SALTVALUE.getBytes(), 65520, 256);
			SecretKey tmp = factory.generateSecret(spec); 
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES"); 
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding"); 
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec); 
			/* Retruns encrypted value. */ 
			return Base64.getEncoder() 
					.encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8))); 
		} 
		catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException e) {
			System.out.println("Error while encryption the json");
		} 
		return null;
	} 
	/* Decryption Method */ 
	public static String decrypt(String strToDecrypt,String key) {
		try{
			/* Declare a byte array. */ 
			byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; 
			IvParameterSpec ivspec = new IvParameterSpec(iv); 
			/* Create factory for secret keys. */ 
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256"); 
			/* PBEKeySpec class implements KeySpec interface. */ 
			KeySpec spec = new PBEKeySpec(key.toCharArray(), SALTVALUE.getBytes(), 20, 256);
			SecretKey tmp = factory.generateSecret(spec); 
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES"); 
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING"); 
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec); 
			/* Retruns decrypted value. */ 
			return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt))); 
		} 
		catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException e){
			System.out.println("Error while encryption the json");
		} 
		return null;
	}

	public static void main (String arg[]) {

		String ddd="cFcTWEq3EeHJPV1iald3q6wEK6MMB8bcuJkbBrNqtBc3qlJN4+Yd7J88G4PfxfY/nMREhQQ7e7ukO3/TcxtkchRsW0IA57W46HQBn9IIk6C3spDv4PdT7JRHTV/gZN6Xgs0VwcjvR5dzfZE5xEDnGMP/BvcR87moZ3MX6DGSngyrRH2AE3jwbAFm01zScBccXZcBlgkWBRuTt3pRyglM/f+aWcKjPl4Pj50BYDmfHwoKyNfZwSbAybTtkVuvEmfG2xe2Dz878OnRYx/56AZCotzSiNKms7Vo+LHAhIzZRNduJAiRAGGNrplY76a6CqBzdEW0JYHN4GzfLTji4UAkpXdJ1XXQThXY/M39fnVVT/1gUA6QQ2TT92lT5o2dC77TT+9RpJK0fVgsewGC9WTtobbiBB0cpBd+1HbpArdYmzyLcMYz46P56E7GloDT1aAo";
		String input = "{\n" +
				"\"appid\":\"axisaltuat\",\n" +
				"\"userId\":\"axisaltuat\",\n" +
				"\"pass\":\"axis_20\",\n" +
				"\"contenttype\":\"1\",\n" +
				"\"from\":\"AXISBK\",\n" +
				"\"to\":\"+917838787657\",\n" +
				"\"alert\":\"1\",\n" +
				"\"selfid\":\"false\",\n" +
				"\"text\":\"Thank You for showing interest. Our representative will contact you shortly.\",\n" +
				"\"dtm\":\"1007055219711593958\",\n" +
				"\"dpi\":\"110100001341\"\n" +
				"}";
		String key = "axispdalt100001341";
		try {
			String encrypt=encrypt(input, key);
			System.out.println("encrypted string:::"+encrypt);


			System.out.println("decrypted string:::"+decrypt(encrypt, key));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}