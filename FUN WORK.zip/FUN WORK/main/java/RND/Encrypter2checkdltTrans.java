package RND;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.*;

public class Encrypter2checkdltTrans {

	private final String characterEncoding = "UTF-8";
	private final String cipherTransformation = "AES/CBC/PKCS5Padding";
	private final String aesEncryptionAlgorithm = "AES";
	private final Base64 base64 = new Base64();

	public byte[] decrypt(byte[] cipherText, byte[] key, byte[] initialVector)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(cipherTransformation);
		SecretKeySpec secretKeySpecy = new SecretKeySpec(key, aesEncryptionAlgorithm);
		IvParameterSpec ivParameterSpec = new IvParameterSpec(initialVector);
		cipher.init(Cipher.DECRYPT_MODE, secretKeySpecy, ivParameterSpec);
		cipherText = cipher.doFinal(cipherText);
		return cipherText;
	}

	public byte[] encrypt(byte[] plainText, byte[] key, byte[] initialVector)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(cipherTransformation);
		SecretKeySpec secretKeySpec = new SecretKeySpec(key, aesEncryptionAlgorithm);
		IvParameterSpec ivParameterSpec = new IvParameterSpec(initialVector);
		cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
		plainText = cipher.doFinal(plainText);
		return plainText;
	}

	private byte[] getIVKeyBytes(String key) throws UnsupportedEncodingException {
		byte[] keyBytes = new byte[16];
		byte[] parameterKeyBytes = key.getBytes(characterEncoding);
		System.arraycopy(parameterKeyBytes, 0, keyBytes, 0, Math.min(parameterKeyBytes.length, keyBytes.length));
		return keyBytes;
	}

	public String encrypt(String plainText, String key, String ivKey)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		byte[] plainTextbytes = plainText.getBytes(characterEncoding);
		byte[] keyBytes = getIVKeyBytes(ivKey);
		return base64.encodeToString(encrypt(plainTextbytes, key.getBytes("UTF-8"), keyBytes));
	}

	public String decrypt(String encryptedText, String key, String ivKey) throws KeyException, GeneralSecurityException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {
		byte[] cipheredBytes = new Base64().decode(encryptedText);
		byte[] keyBytes = getIVKeyBytes(ivKey);
		return new String(decrypt(cipheredBytes, key.getBytes("UTF-8"), keyBytes), characterEncoding);
	}

	public static void main(String[] arg) {
		String input = "{\n" +
				"  \"appid\": \"rcsalr\",\n" +
				"  \"userId\": \"rcsalr\",\n" +
				"  \"pass\": \"rcsalr\",\n" +
				"  \"contenttype\": \"1\",\n" +
				"  \"selfid\": \"true\",\n" +
				"  \"intflag\": \"false\",\n" +
				"  \"alert\": \"1\",\n" +
				"  \"dpi\": \"123456666\",\n" +
				"  \"msg\": \"SAM, This is to test the RCS ALERT MESSAGE on http://google.com\",\n" +
				"  \"messages\": [\n" +
				"    {\n" +
				"      \"id\": \"1\",\n" +
				"      \"to\": \"918588836715\",\n" +
				"      \"from\": \"DEMOAW\",\n" +
				"      \"language\": \"en\",\n" +
				"      \"dtm\": \"89898989898989\"\n" +
				"    }\n" +
				"  ]\n" +
				"}";
		String key = "0000000000000000";
		String ivkey = "0000000000000000";

		try {
			String encrypt = new Encrypter2checkdltTrans().encrypt(input, key, ivkey);
			System.out.println(encrypt);
			System.out.println("");
			System.out.println(new Encrypter2checkdltTrans().decrypt(encrypt, key, ivkey));

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}