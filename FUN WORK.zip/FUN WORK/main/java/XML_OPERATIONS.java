import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;

public class XML_OPERATIONS

{


public static void REMOVELANGUAGE_ATTRIBUTE() {
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            // Get the root element
            Node push = doc.getFirstChild();

            int lenth = doc.getElementsByTagName("detail").getLength();
            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);


                MULTISMS.getAttributes().removeNamedItem("language");

            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void ADDLANGUAGE_ATTRIBUTE() {
        try {

            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            // Get the root element
            Node push = doc.getFirstChild();

            int lenth = doc.getElementsByTagName("detail").getLength();
            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);

                ((Element) MULTISMS).setAttribute("language", "hi");


            }
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);
        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public static void SetXMLSMSListener(String functionname, String UserID, String Passd, String APPID, String SENDER, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String finlename, String MSG_ID) {
        try {

            String SCTYPE = "";

            if (TO.contentEquals("BLK") || TO.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE("msisdn", finlename);
            }

            if (MSG.contentEquals("BLK") || MSG.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE("msg", finlename);

            }
            if (Contenttype.contentEquals("BLK")) {

            } else if (Contenttype.contentEquals("MISS")) {
                REMOVE_NODE("content-type", finlename);
            } else {

                double ctype = Double.parseDouble(Contenttype);
                int ictype = (int) (Math.round(ctype * 100) / 100);
                SCTYPE = String.valueOf(ictype);
            }

            if (INTFLAG.contentEquals("BLK")) {
                INTFLAG = "";
            }
            if (APPID.contentEquals("BLK")) {
                APPID = "";
            } else if (APPID.contentEquals("MISS")) {
                REMOVE_NODE("appid", finlename);
            }

            if (UserID.contentEquals("BLK")) {
                UserID = "";
            } else if (UserID.contentEquals("MISS")) {
                REMOVE_NODE("userid", finlename);
            }
            if (Passd.contentEquals("BLK")) {
                Passd = "";
            } else if (Passd.contentEquals("MISS")) {
                REMOVE_NODE("pass", finlename);
            }


            if (SENDER.contentEquals("BLK")) {
                SENDER = "";
            } else if (SENDER.contentEquals("MISS")) {
                REMOVE_NODE("from", finlename);
            }

            String AALERT = "";
            if (ALERT.contentEquals("BLK")) {
                AALERT = "";
            } else if (ALERT.contentEquals("MISS")) {
                REMOVE_NODE("alert", finlename);
            } else {

                double ALERTtype = Double.parseDouble(ALERT);
                int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
                AALERT = String.valueOf(iALERTtype);
            }


            if (Language.contentEquals("BLK")) {
                Language = "";
            }


            double random = Math.random();

            double x = random * 1000000;

            int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
            if (!MSG_ID.contentEquals("BLK")) {
                MSGID = Integer.parseInt(MSG_ID);
            }
            if (functionname.contains("MESSAGEID_TAGMISS")) {
                REMOVE_NODE("msgid", finlename);
            }

            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + finlename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            // Get the root element
            Node push = doc.getFirstChild();

            if (!functionname.contains("MESSAGEID_TAGMISS")) {
                Node msgid = doc.getElementsByTagName("msgid").item(0);
                msgid.setTextContent(String.valueOf(MSGID));

            }

            if (!SENDER.contentEquals("MISS")) {
                Node FROM = doc.getElementsByTagName("from").item(0);
                FROM.setTextContent(SENDER);
            }


            if (!UserID.contentEquals("MISS")) {

                Node USERID = doc.getElementsByTagName("userid").item(0);
                USERID.setTextContent(UserID);
            }

            if (!Passd.contentEquals("MISS")) {
                Node PASSWD = doc.getElementsByTagName("pass").item(0);
                PASSWD.setTextContent(Passd);
            }

            if (!APPID.contentEquals("MISS")) {

                Node APP_ID = doc.getElementsByTagName("appid").item(0);
                APP_ID.setTextContent(APPID);
            }

            Node SUBAPP_ID = doc.getElementsByTagName("subappid").item(0);
            SUBAPP_ID.setTextContent(APPID);
            if (!Contenttype.contentEquals("MISS")) {
                Node CTYPE = doc.getElementsByTagName("content-type").item(0);
                CTYPE.setTextContent(SCTYPE);
            }

            if (!ALERT.contentEquals("MISS")) {
                Node ALERTn = doc.getElementsByTagName("alert").item(0);
                ALERTn.setTextContent(AALERT);
            }


            Node Intflag = doc.getElementsByTagName("intflag").item(0);
            Intflag.setTextContent(INTFLAG);

            Node msgid = doc.getElementsByTagName("language").item(0);
            msgid.setTextContent(Language);


            if (!MSG.contentEquals("MISS")) {
                Node msg = doc.getElementsByTagName("msg").item(0);
                msg.setTextContent(MSG);
            }
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory
                    .newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            // System.out.println("Done");

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void SetXMLSMSListenerforRCS(String functionname, String UserID, String Passd, String APPID, String SENDER, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String finlename, String MSG_ID,String SHORT) {
        try {

            String SCTYPE = "";

            if (TO.contentEquals("BLK") || TO.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE("msisdn", finlename);
            }

            if (MSG.contentEquals("BLK") || MSG.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE("msg", finlename);

            }
            if (Contenttype.contentEquals("BLK")) {

            } else if (Contenttype.contentEquals("MISS")) {
                REMOVE_NODE("content-type", finlename);
            } else {

                double ctype = Double.parseDouble(Contenttype);
                int ictype = (int) (Math.round(ctype * 100) / 100);
                SCTYPE = String.valueOf(ictype);
            }

            if (INTFLAG.contentEquals("BLK")) {
                INTFLAG = "";
            }
            if (APPID.contentEquals("BLK")) {
                APPID = "";
            } else if (APPID.contentEquals("MISS")) {
                REMOVE_NODE("appid", finlename);
            }

            if (UserID.contentEquals("BLK")) {
                UserID = "";
            } else if (UserID.contentEquals("MISS")) {
                REMOVE_NODE("userid", finlename);
            }
            if (Passd.contentEquals("BLK")) {
                Passd = "";
            } else if (Passd.contentEquals("MISS")) {
                REMOVE_NODE("pass", finlename);
            }


            if (SENDER.contentEquals("BLK")) {
                SENDER = "";
            } else if (SENDER.contentEquals("MISS")) {
                REMOVE_NODE("from", finlename);
            }

            String AALERT = "";
            if (ALERT.contentEquals("BLK")) {
                AALERT = "";
            } else if (ALERT.contentEquals("MISS")) {
                REMOVE_NODE("alert", finlename);
            } else {

                double ALERTtype = Double.parseDouble(ALERT);
                int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
                AALERT = String.valueOf(iALERTtype);
            }


            if (Language.contentEquals("BLK")) {
                Language = "";
            }


            double random = Math.random();

            double x = random * 1000000;

            int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
            if (!MSG_ID.contentEquals("BLK")) {
                MSGID = Integer.parseInt(MSG_ID);
            }
            if (functionname.contains("MESSAGEID_TAGMISS")) {
                REMOVE_NODE("msgid", finlename);
            }

            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + finlename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            // Get the root element
            Node push = doc.getFirstChild();

            if (!functionname.contains("MESSAGEID_TAGMISS")) {
                Node msgid = doc.getElementsByTagName("msgid").item(0);
                msgid.setTextContent(String.valueOf(MSGID));

            }

            if (!SENDER.contentEquals("MISS")) {
                Node FROM = doc.getElementsByTagName("from").item(0);
                FROM.setTextContent(SENDER);
            }


            if (!UserID.contentEquals("MISS")) {

                Node USERID = doc.getElementsByTagName("userid").item(0);
                USERID.setTextContent(UserID);
            }

            if (!Passd.contentEquals("MISS")) {
                Node PASSWD = doc.getElementsByTagName("pass").item(0);
                PASSWD.setTextContent(Passd);
            }

            if (!APPID.contentEquals("MISS")) {

                Node APP_ID = doc.getElementsByTagName("appid").item(0);
                APP_ID.setTextContent(APPID);
            }

            Node SUBAPP_ID = doc.getElementsByTagName("subappid").item(0);
            SUBAPP_ID.setTextContent(APPID);
            if (!Contenttype.contentEquals("MISS")) {
                Node CTYPE = doc.getElementsByTagName("content-type").item(0);
                CTYPE.setTextContent(SCTYPE);
            }

            if (!ALERT.contentEquals("MISS")) {
                Node ALERTn = doc.getElementsByTagName("alert").item(0);
                ALERTn.setTextContent(AALERT);
            }
            String ASHORT = "";
            double SHORTtype = Double.parseDouble(SHORT);
            int iSHORTtype = (int) (Math.round(SHORTtype * 100) / 100);
            ASHORT = String.valueOf(iSHORTtype);

            Node SHORTFLAG = doc.getElementsByTagName("shorten").item(0);
            SHORTFLAG.setTextContent(ASHORT);

            Node Intflag = doc.getElementsByTagName("intflag").item(0);
            Intflag.setTextContent(INTFLAG);

            Node msgid = doc.getElementsByTagName("language").item(0);
            msgid.setTextContent(Language);


            if (!MSG.contentEquals("MISS")) {
                Node msg = doc.getElementsByTagName("msg").item(0);
                msg.setTextContent(MSG);
            }
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory
                    .newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            // System.out.println("Done");

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public static void setXML(String functionname, String UserID, String Passd, String APPID, String SENDER, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String finlename, String MSG_ID) {
        try {

            String SCTYPE = "";

            if (TO.contentEquals("BLK") || TO.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE("msisdn", finlename);
            }

            if (MSG.contentEquals("BLK") || MSG.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE("msg", finlename);

            }
            if (Contenttype.contentEquals("BLK")) {

            } else if (Contenttype.contentEquals("MISS")) {
                REMOVE_NODE("content-type", finlename);
            } else {

                double ctype = Double.parseDouble(Contenttype);
                int ictype = (int) (Math.round(ctype * 100) / 100);
                SCTYPE = String.valueOf(ictype);
            }

            if (INTFLAG.contentEquals("BLK")) {
                INTFLAG = "";
            }
            if (APPID.contentEquals("BLK")) {
                APPID = "";
            } else if (APPID.contentEquals("MISS")) {
                REMOVE_NODE("appid", finlename);
            }

            if (UserID.contentEquals("BLK")) {
                UserID = "";
            } else if (UserID.contentEquals("MISS")) {
                REMOVE_NODE("userid", finlename);
            }
            if (Passd.contentEquals("BLK")) {
                Passd = "";
            } else if (Passd.contentEquals("MISS")) {
                REMOVE_NODE("pass", finlename);
            }


            if (SENDER.contentEquals("BLK")) {
                SENDER = "";
            } else if (SENDER.contentEquals("MISS")) {
                REMOVE_NODE("from", finlename);
            }

            String AALERT = "";
            if (ALERT.contentEquals("BLK")) {
                AALERT = "";
            } else if (ALERT.contentEquals("MISS")) {
                REMOVE_NODE("alert", finlename);
            } else {

                double ALERTtype = Double.parseDouble(ALERT);
                int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
                AALERT = String.valueOf(iALERTtype);
            }


            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            double random = Math.random();

            double x = random * 1000000;

            int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
            if (!MSG_ID.contentEquals("BLK")) {
                MSGID = Integer.parseInt(MSG_ID);
            }
            if (functionname.contains("MESSAGEID_TAGMISS")) {
                REMOVE_NODE("msgid", finlename);
            }

            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + finlename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            // Get the root element
            Node push = doc.getFirstChild();

            if (!functionname.contains("MESSAGEID_TAGMISS")) {
                Node msgid = doc.getElementsByTagName("msgid").item(0);
                msgid.setTextContent(String.valueOf(MSGID));

            }

            if (!SENDER.contentEquals("MISS")) {
                Node FROM = doc.getElementsByTagName("from").item(0);
                FROM.setTextContent(SENDER);
            }


            if (!UserID.contentEquals("MISS")) {

                Node USERID = doc.getElementsByTagName("userid").item(0);
                USERID.setTextContent(UserID);
            }

            if (!Passd.contentEquals("MISS")) {
                Node PASSWD = doc.getElementsByTagName("pass").item(0);
                PASSWD.setTextContent(Passd);
            }

            if (!APPID.contentEquals("MISS")) {

                Node APP_ID = doc.getElementsByTagName("appid").item(0);
                APP_ID.setTextContent(APPID);
            }

            Node SUBAPP_ID = doc.getElementsByTagName("subappid").item(0);
            SUBAPP_ID.setTextContent(APPID);
            if (!Contenttype.contentEquals("MISS")) {
                Node CTYPE = doc.getElementsByTagName("content-type").item(0);
                CTYPE.setTextContent(SCTYPE);
            }

            if (!ALERT.contentEquals("MISS")) {
                Node ALERTn = doc.getElementsByTagName("alert").item(0);
                ALERTn.setTextContent(AALERT);
            }


            Node Intflag = doc.getElementsByTagName("intflag").item(0);
            System.out.println("The intflag is "+INTFLAG);
            Intflag.setTextContent(INTFLAG);

            int lenth = doc.getElementsByTagName("detail").getLength();

            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);
                if (MSG.contentEquals("MISS")) {
                    //do nothing
                } else if (MSG.contentEquals("BLK")) {
                    //do nothing
                } else {
                    MULTISMS.getAttributes().item(2).setTextContent(MSG);
                }
                MULTISMS.getAttributes().item(1).setTextContent(Language);
               // MULTISMS.getAttributes().item(3).setTextContent(TO);
            }

            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory
                    .newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            // System.out.println("Done");

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void setXMLLANGUAGEAPIFORRCSANDWA(String functionname, String UserID, String Passd, String APPID, String SENDER, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String finlename, String MSG_ID,String shorten) {
        try {

            String SCTYPE = "";





                double ctype = Double.parseDouble(Contenttype);
                int ictype = (int) (Math.round(ctype * 100) / 100);
                SCTYPE = String.valueOf(ictype);

            String ShortTYPE = "";





            double shorttype = Double.parseDouble(shorten);
            int ishorttype = (int) (Math.round(shorttype * 100) / 100);
            ShortTYPE = String.valueOf(ishorttype);








            String AALERT = "";


                double ALERTtype = Double.parseDouble(ALERT);
                int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
                AALERT = String.valueOf(iALERTtype);



            double random = Math.random();

            double x = random * 1000000;

            int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99

               // MSGID = Integer.parseInt(MSGID);



            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XMLLANGUAGE/" + finlename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            // Get the root element
            Node push = doc.getFirstChild();

            if (!functionname.contains("MESSAGEID_TAGMISS")) {
                Node msgid = doc.getElementsByTagName("msgid").item(0);
                msgid.setTextContent(String.valueOf(MSGID));

            }

            if (!SENDER.contentEquals("MISS")) {
                Node FROM = doc.getElementsByTagName("from").item(0);
                FROM.setTextContent(SENDER);
            }


            if (!UserID.contentEquals("MISS")) {

                Node USERID = doc.getElementsByTagName("userid").item(0);
                USERID.setTextContent(UserID);
            }

            if (!Passd.contentEquals("MISS")) {
                Node PASSWD = doc.getElementsByTagName("pass").item(0);
                PASSWD.setTextContent(Passd);
            }

            if (!APPID.contentEquals("MISS")) {

                Node APP_ID = doc.getElementsByTagName("appid").item(0);
                APP_ID.setTextContent(APPID);
            }

            Node SHORT = doc.getElementsByTagName("shorten").item(0);
            SHORT.setTextContent(ShortTYPE);

            Node SUBAPP_ID = doc.getElementsByTagName("subappid").item(0);
            SUBAPP_ID.setTextContent(APPID);
            if (!Contenttype.contentEquals("MISS")) {
                Node CTYPE = doc.getElementsByTagName("content-type").item(0);
                CTYPE.setTextContent(SCTYPE);
            }

            if (!ALERT.contentEquals("MISS")) {
                Node ALERTn = doc.getElementsByTagName("alert").item(0);
                ALERTn.setTextContent(AALERT);
            }


            Node Intflag = doc.getElementsByTagName("intflag").item(0);
            System.out.println("The intflag is "+INTFLAG);
            Intflag.setTextContent(INTFLAG);

            int lenth = doc.getElementsByTagName("detail").getLength();

            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);
                if (MSG.contentEquals("MISS")) {
                    //do nothing
                } else if (MSG.contentEquals("BLK")) {
                    //do nothing
                } else {
                    MULTISMS.getAttributes().item(2).setTextContent(MSG);
                }
                MULTISMS.getAttributes().item(1).setTextContent(Language);
                // MULTISMS.getAttributes().item(3).setTextContent(TO);
            }

            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory
                    .newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            // System.out.println("Done");

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void REMOVE_NODE(String NodeTagname, String FILENAME) {
        String temvalue = "";
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + FILENAME;//XmlLangaugeAPIListenerNegative.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);


            Node push = doc.getFirstChild();
            temvalue = doc.getElementsByTagName(NodeTagname).item(0).getTextContent();
            System.out.println(temvalue);
            push.removeChild(doc.getElementsByTagName(NodeTagname).item(0));

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);


        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void ADD_NODE(String NodeTagname, String Nodevalue, String FILENAME) {
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + FILENAME;//XmlLangaugeAPIListenerNegative.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            // Get the root element
            Element name = doc.createElement(NodeTagname);
            Node push = doc.getFirstChild();
            push.appendChild(name);
            name.setTextContent(Nodevalue);

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void REMOVE_ATTRIBUTE(String attributename, String filename) {
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + filename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            int lenth = doc.getElementsByTagName("detail").getLength();
            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);
                MULTISMS.getAttributes().removeNamedItem(attributename);
            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);


        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void ADD_ATTRIBUTE(String attributename, String value, String filename) {
        try {

            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + filename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            int lenth = doc.getElementsByTagName("detail").getLength();
            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);
                ((Element) MULTISMS).setAttribute(attributename, value);
            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);


        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }







    public static void setXML_ICICI(String functionname, String UserID, String Passd, String APPID, String SENDER, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String finlename, String MSG_ID) {
        try {

            String SCTYPE = "";

           /* if (TO.contentEquals("BLK") || TO.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE_ICICI("msisdn", finlename);
            }*/

            if (MSG.contentEquals("BLK") || MSG.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("messageTxt", finlename);

            }
           /* if (Contenttype.contentEquals("BLK")) {

            } else if (Contenttype.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("content-type", finlename);
            } else {

                double ctype = Double.parseDouble(Contenttype);
                int ictype = (int) (Math.round(ctype * 100) / 100);
                SCTYPE = String.valueOf(ictype);
            }*/

            if (INTFLAG.contentEquals("BLK")) {
                INTFLAG = "";
            }
            if (UserID.contentEquals("BLK")) {
                UserID = "";
            } else if (UserID.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE_ICICI("ClientCode", finlename);
            }

           /* if (UserID.contentEquals("BLK")) {
                UserID = "";
            } else if (UserID.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("userid", finlename);
            }  */
            if (Passd.contentEquals("BLK")) {
                Passd = "";
            } else if (Passd.contentEquals("MISS")) {
                REMOVE_ATTRIBUTE_ICICI("pin", finlename);
            }


            if (SENDER.contentEquals("BLK")) {
                SENDER = "";
            } else if (SENDER.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("fromAddress", finlename);
            }

            String AALERT = "";
            if (ALERT.contentEquals("BLK")) {
                AALERT = "";
            } else if (ALERT.contentEquals("MISS")) {
                REMOVE_NODE_ICICI("alert", finlename);
            } else {

                double ALERTtype = Double.parseDouble(ALERT);
                int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
                AALERT = String.valueOf(iALERTtype);
            }


            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            double random = Math.random();

            double x = random * 1000000;

            int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
            if (!MSG_ID.contentEquals("BLK")) {
                MSGID = Integer.parseInt(MSG_ID);
            }
            if (functionname.contains("MESSAGEID_TAGMISS")) {
                REMOVE_NODE_ICICI("messageID", finlename);
            }

            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + finlename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);




            if (!functionname.contains("MESSAGEID_TAGMISS")) {
                Node msgid = doc.getElementsByTagName("messageID").item(0);
                msgid.setTextContent(String.valueOf(MSGID));

            }


            if (!SENDER.contentEquals("MISS")) {
                Node FROM = doc.getElementsByTagName("fromAddress").item(0);
                FROM.setTextContent(SENDER);
            }

            if (!UserID.contentEquals("MISS")) {
                System.out.println("set userid"+ UserID);
                Node request = doc.getElementsByTagName("request").item(0);
                System.out.println("-->");
                System.out.println("attribute tag"+request.getNodeName());
                ((Element) request).setAttribute("ClientCode", UserID);

            }
            if (!Passd.contentEquals("MISS")) {
                System.out.println("set passwd"+ Passd);

                Node request = doc.getElementsByTagName("request").item(0);
                System.out.println("-->");
                System.out.println("attribute tag"+request.getNodeName());
                ((Element) request).setAttribute("pin", Passd);

            }
            if (!ALERT.contentEquals("MISS")) {
                System.out.println("ICICI ALERT VALUE "+AALERT);
                Node alert = doc.getElementsByTagName("alert").item(0);
                alert.setTextContent(AALERT);
            }
           /* if (!APPID.contentEquals("MISS")) {


                REMOVE_ATTRIBUTE_ICICI("ClientCode","ICICI.xml");
                ADD_ATTRIBUTE_ICICI("ClientCode",UserID,"ICICI.xml");
            }*/

           /* Node SUBAPP_ID = doc.getElementsByTagName("subappid").item(0);
            SUBAPP_ID.setTextContent(APPID);
            if (!Contenttype.contentEquals("MISS")) {
                Node CTYPE = doc.getElementsByTagName("content-type").item(0);
                CTYPE.setTextContent(SCTYPE);
            }
*/


            if (!MSG.contentEquals("MISS")) {
                Node msg = doc.getElementsByTagName("messageTxt").item(0);
                msg.setTextContent(MSG);
            }


            Node Intflag = doc.getElementsByTagName("intflag").item(0);
            Intflag.setTextContent(INTFLAG);

           /* int lenth = doc.getElementsByTagName("detail").getLength();
            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);
                if (MSG.contentEquals("MISS")) {
                    //do nothing
                } else if (MSG.contentEquals("BLK")) {
                    //do nothing
                } else {
                    MULTISMS.getAttributes().item(2).setTextContent(MSG);
                }
                MULTISMS.getAttributes().item(1).setTextContent(Language);
            } */

            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory
                    .newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            // System.out.println("Done");

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void REMOVE_NODE_ICICI(String NodeTagname, String FILENAME) {
        String temvalue = "";
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + FILENAME;//XmlLangaugeAPIListenerNegative.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

//test

            Node publishData=doc.getElementsByTagName("publishData").item(0);

            System.out.println(publishData.getNodeName());
            temvalue = doc.getElementsByTagName(NodeTagname).item(0).getTextContent();

            System.out.println("Node-->"+NodeTagname+" value-->"+temvalue);
            System.out.println("To bedeleted node-->"+doc.getElementsByTagName(NodeTagname).item(0).getNodeName());

            System.out.println("To bedeleted node2-->"+doc.getElementsByTagName(NodeTagname).item(0));

            publishData.removeChild(doc.getElementsByTagName(NodeTagname).item(0));

            //publishData.removeChild(doc.getElementsByTagName(NodeTagname).item(0));

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);


        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void ADD_NODE_ICICI(String NodeTagname, String Nodevalue, String FILENAME) {
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + FILENAME;//XmlLangaugeAPIListenerNegative.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

            // Get the root element
            Element name = doc.createElement(NodeTagname);
            Node publishData=doc.getElementsByTagName("publishData").item(0);
            publishData.appendChild(name);
            name.setTextContent(Nodevalue);

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void REMOVE_ATTRIBUTE_ICICI(String attributename, String filename) {
        try {
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + filename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);


            Node request = doc.getElementsByTagName("request").item(0);
            System.out.println("-->");
            request.getAttributes().removeNamedItem(attributename);



            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);


        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void ADD_ATTRIBUTE_ICICI(String attributename, String value, String filename) {
        try {

            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + filename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);

           /* int lenth = doc.getElementsByTagName("detail").getLength();
            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);
                ((Element) MULTISMS).setAttribute(attributename, value);
            }*/



            Node request = doc.getElementsByTagName("request").item(0);
            System.out.println("-->");
            System.out.println("attribute tag"+request.getNodeName());
            ((Element) request).setAttribute(attributename, value);

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);


        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }








    public static void SetMULTISMSXMLListener(String functionname, String UserID, String Passd, String APPID, String SENDER, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String filename,String MSG_ID) {
        try {
            String SCTYPE="";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);
            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);
            double random = Math.random();

            double x = random * 1000000;

            int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
            if (!MSG_ID.contentEquals("BLK")) {
                MSGID = Integer.parseInt(MSG_ID);
            }
            if (functionname.contains("MESSAGEID_TAGMISS")) {
                REMOVE_NODE("msgid", filename);
            }
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + filename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);


            // Get the root element
            Node push = doc.getFirstChild();
            Node FROM = doc.getElementsByTagName("from").item(0);
            FROM.setTextContent(SENDER);
            Node USERID = doc.getElementsByTagName("userid").item(0);
            USERID.setTextContent(UserID);
            Node PASSWD = doc.getElementsByTagName("pass").item(0);
            PASSWD.setTextContent(Passd);
            Node APP_ID = doc.getElementsByTagName("appid").item(0);
            APP_ID.setTextContent(APPID);
            Node SUBAPP_ID = doc.getElementsByTagName("subappid").item(0);
            SUBAPP_ID.setTextContent(APPID);
            Node CTYPE = doc.getElementsByTagName("content-type").item(0);
            CTYPE.setTextContent(SCTYPE);
            Node ALERTn = doc.getElementsByTagName("alert").item(0);
            ALERTn.setTextContent(AALERT);
            Node Intflag = doc.getElementsByTagName("intflag").item(0);
            Intflag.setTextContent(INTFLAG);
            if (!functionname.contains("MESSAGEID_TAGMISS")) {
                Node msgid = doc.getElementsByTagName("msgid").item(0);
                msgid.setTextContent(String.valueOf(MSGID));

            }

            int lenth = doc.getElementsByTagName("detail").getLength();

            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(0);
//                MULTISMS.getAttributes().item(3).setTextContent(TO);
                MULTISMS.getAttributes().item(2).setTextContent(MSG);
                MULTISMS.getAttributes().item(1).setTextContent(Language);
            }
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory
                    .newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            // System.out.println("Done");

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void SetMULTISMSXMLListenerRCS(String functionname, String UserID, String Passd, String APPID, String SENDER, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String filename,String MSG_ID,String Short) {
        try {
            String SCTYPE="";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);
            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);
            double random = Math.random();

            double x = random * 1000000;

            int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
            if (!MSG_ID.contentEquals("BLK")) {
                MSGID = Integer.parseInt(MSG_ID);
            }
            if (functionname.contains("MESSAGEID_TAGMISS")) {
                REMOVE_NODE("msgid", filename);
            }
            String filepath = System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/" + filename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);


            // Get the root element
            Node push = doc.getFirstChild();
            Node FROM = doc.getElementsByTagName("from").item(0);
            FROM.setTextContent(SENDER);
            Node USERID = doc.getElementsByTagName("userid").item(0);
            USERID.setTextContent(UserID);
            Node PASSWD = doc.getElementsByTagName("pass").item(0);
            PASSWD.setTextContent(Passd);
            Node APP_ID = doc.getElementsByTagName("appid").item(0);
            APP_ID.setTextContent(APPID);
            Node SUBAPP_ID = doc.getElementsByTagName("subappid").item(0);
            SUBAPP_ID.setTextContent(APPID);
            Node CTYPE = doc.getElementsByTagName("content-type").item(0);
            CTYPE.setTextContent(SCTYPE);
            Node ALERTn = doc.getElementsByTagName("alert").item(0);
            ALERTn.setTextContent(AALERT);
            Node Intflag = doc.getElementsByTagName("intflag").item(0);
            Intflag.setTextContent(INTFLAG);
            if (!functionname.contains("MESSAGEID_TAGMISS")) {
                Node msgid = doc.getElementsByTagName("msgid").item(0);
                msgid.setTextContent(String.valueOf(MSGID));

            }

            int lenth = doc.getElementsByTagName("detail").getLength();

            for (int i = 0; i < lenth; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(0);
//                MULTISMS.getAttributes().item(3).setTextContent(TO);
                MULTISMS.getAttributes().item(2).setTextContent(MSG);
                MULTISMS.getAttributes().item(1).setTextContent(Language);
                MULTISMS.getAttributes().item(4).setTextContent(Short);
            }
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory
                    .newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            // System.out.println("Done");

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void setXMLSMSLISTENERFORRCSANDWA(String functionname, String UserID, String Passd, String APPID,
                                                    String SENDER, String TO, String MSG, String ALERT, String SELFID,
                                                    String INTFLAG, String Contenttype, String Language, String finlename,
                                                    String MSG_ID, String shorten) {
        try {
            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);
            String ShortTYPE = "";
            double shorttype = Double.parseDouble(shorten);
            int ishorttype = (int) (Math.round(shorttype * 100) / 100);
            ShortTYPE = String.valueOf(ishorttype);
            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            double random = Math.random();
            int MSGID = (int) (random * 1000000) + 100;
            if (!MSG_ID.equalsIgnoreCase("BLK") && !MSG_ID.equalsIgnoreCase("MISS") && !MSG_ID.trim().isEmpty()) {
                try {
                    MSGID = Integer.parseInt(MSG_ID);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid MSG_ID, using random value.");
                }
            }

            String filepath = System.getProperty("user.dir")
                    + "/src/main/resources/Util/XML_REPOSITORY/XMLSMSLISTENER/"
                    + finlename;
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);


            if (!functionname.contains("MESSAGEID_TAGMISS")) {
                Node msgid = doc.getElementsByTagName("msgid").item(0);
                msgid.setTextContent(String.valueOf(MSGID));
            }
            if (!SENDER.equalsIgnoreCase("MISS")) {
                Node FROM = doc.getElementsByTagName("from").item(0);
                FROM.setTextContent(SENDER);
            }
            if (!UserID.equalsIgnoreCase("MISS")) {
                Node USERID = doc.getElementsByTagName("userid").item(0);
                USERID.setTextContent(UserID);
            }

            if (!Passd.equalsIgnoreCase("MISS")) {
                Node PASSWD = doc.getElementsByTagName("pass").item(0);
                PASSWD.setTextContent(Passd);
            }

            if (!APPID.equalsIgnoreCase("MISS")) {
                Node APP_ID = doc.getElementsByTagName("appid").item(0);
                APP_ID.setTextContent(APPID);
            }

            Node SUBAPP_ID = doc.getElementsByTagName("subappid").item(0);
            SUBAPP_ID.setTextContent(APPID);

            Node SHORT = doc.getElementsByTagName("shorten").item(0);
            SHORT.setTextContent(ShortTYPE);
            if (!Contenttype.equalsIgnoreCase("MISS")) {
                Node CTYPE = doc.getElementsByTagName("content-type").item(0);
                CTYPE.setTextContent(SCTYPE);
            }

            if (!ALERT.equalsIgnoreCase("MISS")) {
                Node ALERTn = doc.getElementsByTagName("alert").item(0);
                ALERTn.setTextContent(AALERT);
            }

            Node Intflag = doc.getElementsByTagName("intflag").item(0);
            System.out.println("The intflag is " + INTFLAG);
            Intflag.setTextContent(INTFLAG);
            int length = doc.getElementsByTagName("detail").getLength();
            for (int i = 0; i < length; i++) {
                Node MULTISMS = doc.getElementsByTagName("detail").item(i);

                if (!MSG.equalsIgnoreCase("MISS") && !MSG.equalsIgnoreCase("BLK")) {
                    MULTISMS.getAttributes().item(2).setTextContent(MSG);
                }
                MULTISMS.getAttributes().item(1).setTextContent(Language);

                if (!TO.equalsIgnoreCase("MISS") && !TO.equalsIgnoreCase("BLK")) {
                    if (MULTISMS.getAttributes().getLength() > 3) {
                        MULTISMS.getAttributes().item(3).setTextContent(TO);
                    }
                }
            }

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);
            System.out.println("XML updated successfully for RCS/WA SMS Listener file: " + finlename);
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



}