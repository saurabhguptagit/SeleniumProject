import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.sun.jdi.Value;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.testng.Assert;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class LinuxLogReader extends TestBase {

    static JSONObject jsonObject;

    //Below method is used to fetch the Redis JSON printed from the log only when request is submitted to SMSC
    //This function is internally called and not being directly called from test layer
    public static JSONObject GETREDISJSON(String LG) {


        int ind = LG.indexOf("JEDIS MIS REQUEST::");
        String temp2 = LG.substring(ind + 19);

        int JSon = temp2.indexOf("\"}");
        System.out.println("<font color=\"brown\"><b>This is the final JSON sent to Redis to SMSC ---></b></font> " + temp2.substring(0, JSon + 2)+"}");

        jsonObject = (JSONObject) JSONValue.parse(temp2.substring(0, JSon + 2)+"}");


        return jsonObject;
    }



    public static JSONObject GETDLRJSON(String ldata) {


       // int ind = ldata.indexOf("DEBUG :- {");
        int ind = ldata.indexOf("DEBUG :- {\"uid\"");
        String temp2 = ldata.substring(ind + 9);

        int JSon = temp2.indexOf("\"}");
        System.out.println("<font color=\"brown\"><b>This is the DLR JSON ---></b></font> " + temp2.substring(0, JSon + 2));

        jsonObject = (JSONObject) JSONValue.parse(temp2.substring(0, JSon + 2));
        System.out.println("Below is the DLR JSON");
        System.out.println(jsonObject);

        return jsonObject;
    }
    public static boolean CheckMNPLOG(String responseid, String UNAME, String PASS, String HOSTNAME, boolean CHECKMSG, String MSGTEXT, String loglocation, String logfilename) throws Exception {
        TestBase ob = new TestBase();
        double a = Double.parseDouble(ob.GetProperty("port"));
        int port = (int) (Math.round(a * 100) / 100);

        boolean MNPRESULT = false;

        String responseString = RUNLINUXCOMMANDANDGETSTRING(responseid, UNAME, PASS, HOSTNAME, loglocation,logfilename);

        // System.out.println(responseString);//INVALID MSISDN
        if (responseString.contains(responseid) && responseString.contains("INFO  :- ::MNP LOG::MNP number found")) {

            System.out.println("<font color=\"brown\"><b>MNP FUNCTION IS WORKING</b></font>");

            MNPRESULT = true;

        } else {
            System.out.println("MNP FUNCTION DID NOT WORK AS EXPECTED");
            MNPRESULT = false;
        }


        return MNPRESULT;
    }


//Generic function to check log for expected string patterns
    private static boolean CHECKLOGFORGENERALVALIDATION(String expectedSearchString, String username, String password,
                                                        String host, int port, String responseID, boolean CHECKMSG, String MSGTEXT, String LOGLOCATION, String logfilename, 
                                                        String testName, String logPrefix, boolean wrapSearchStringWithJsonFormat, boolean printDebugLog) throws Exception {

        String responseString = RUNLINUXCOMMANDANDGETSTRING(responseID, username, password, host, LOGLOCATION, logfilename);

        if (printDebugLog) {
            System.out.println(logPrefix + "--->");
            System.out.println(responseString);
        }

        String searchString = wrapSearchStringWithJsonFormat ? "\"sd\":\"" + expectedSearchString + "\"" : expectedSearchString;
        
        if (responseString.contains(responseID) && responseString.contains(searchString)) {
            System.out.println("<font color=\"brown\"><b>" + testName + " IS PASSED</b></font>");
            return true;
        } else {
            System.out.println(testName + " IS FAILED");
            return false;
        }
    }

    private static boolean CHECKPREPAIDBALANCE(String username, String password,
                                               String host, int port, String responseID, boolean CHECKMSG, String MSGTEXT, String LOGLOCATION, String logfilename) throws Exception {
        return CHECKLOGFORGENERALVALIDATION("Insufficient Credits", username, password, host, port, responseID, CHECKMSG, MSGTEXT, LOGLOCATION, logfilename, 
                                           "PREPAID BALANCE TEST", "", true, false);
    }

    private static boolean CHECKLOGFORERRORMESSAGES(String ERRORMESSAGE, String username, String password,
                                                    String host, int port, String responseID, boolean CHECKMSG, String MSGTEXT, String LOGLOCATION, String logfilename) throws Exception {
        return CHECKLOGFORGENERALVALIDATION(ERRORMESSAGE, username, password, host, port, responseID, CHECKMSG, MSGTEXT, LOGLOCATION, logfilename, 
                                           "ERROR CASE PASSED FOR " + ERRORMESSAGE, "ERROR LOG", true, false);
    }

    private static boolean CHECKLOGFORDLRMESSAGES(String ERRORMESSAGE, String username, String password,
                                                    String host, int port, String responseID, boolean CHECKMSG, String MSGTEXT, String LOGLOCATION, String logfilename) throws Exception {
        return CHECKLOGFORGENERALVALIDATION(ERRORMESSAGE, username, password, host, port, responseID, CHECKMSG, MSGTEXT, LOGLOCATION, logfilename, 
                                           "DLR INFO PRINTED IN LOG FOR " + responseID, "DLR LOG", false, true);
    }

    private static boolean CHECKDLTTEMPLATENOTFOUND(String username, String password,
                                                    String host, int port, String responseID, boolean CHECKMSG, String MSGTEXT, String LOGLOCATION, String logfilename) throws Exception {
        return CHECKLOGFORGENERALVALIDATION("DLT TEMPID NOT FOUND", username, password, host, port, responseID, CHECKMSG, MSGTEXT, LOGLOCATION, logfilename, 
                                           "DLT TEMPLATE NOT FOUND TEST", "", true, false);
    }
//Below function is used to check the log if the response id is successfuly submitted to SMSC or not
//test
    public static boolean CheckSMSCLOG(String responseid, String UNAME, String PASS, String HOSTNAME, boolean CHECKMSG, String MSGTEXT, String loglocation, String logfilename) throws Exception {
        if (responseid.startsWith("-")) {
            return false;
        } else {

            boolean SMSCRESULT = false;
            try {

                String responseString = RUNLINUXCOMMANDANDGETSTRING(responseid, UNAME, PASS, HOSTNAME, loglocation, logfilename);

                if (responseString.contains(responseid) && responseString.contains("SUBMITTED TO SMSC")) {

                    System.out.println("<font color=\"brown\"><b>Request is successfully sent to SMSC</b></font>");

                    String ExpectedOMX = MSGTEXT;


                    if (CHECKMSG) {
                        JSONObject jsonObject = GETREDISJSON(responseString);
                        String ActualOMX = String.valueOf(jsonObject.get("omx"));
                        System.out.println("<b>Template used </b> " + jsonObject.get("td"));

                        if (ActualOMX.contentEquals(ExpectedOMX)) {
                            System.out.println("<font color=\"brown\"><b>Original MSG text matching</b></font>");
                            SMSCRESULT = true;
                        } else {
                            System.out.println("Original MSG text NOT matching");
                            SMSCRESULT = false;
                        }
                    } else {
                        System.out.println("Original MSG text  matching NOT needed");
                        SMSCRESULT = true;
                    }


                } else {
                    System.out.println("FAILED  to sent to  SMSC ");
                    SMSCRESULT = false;
                }
            }catch (Exception e) {

            }finally {
                return SMSCRESULT;
            }




        }
    }


    public static boolean Check98LOG(String responseid, String UNAME, String PASS, String HOSTNAME, boolean CHECKMSG, String MSGTEXT, String loglocation, String logfilename) throws Exception {
        if (responseid.startsWith("-")) {
            return false;
        } else {

            boolean SMSCRESULT = false;

            String responseString = RUNLINUXCOMMANDANDGETSTRING(responseid, UNAME, PASS, HOSTNAME, loglocation,logfilename);

            if (responseString.contains(responseid) ) {

                System.out.println("<font color=\"brown\"><b>Request is successfully Recieved on 98</b></font>");

                SMSCRESULT = true;
            } else {
                System.out.println("<font color=\"brown\"><b>Request has not been   Recieved on 98</b></font>");
                SMSCRESULT = false;
            }
            System.out.println("98 log "+responseString);
            return SMSCRESULT;
        }
    }




//Below is the generic function returns entire log after greping a responseid
    //this is being enternally used by code.
    public static String RUNLINUXCOMMANDANDGETSTRING(String responseid, String UNAME, String PASS, String HOSTNAME, String loglocation , String logfilename) throws Exception {
        TestBase ob = new TestBase();
        double a = Double.parseDouble(ob.GetProperty("port"));
        int port = (int) (Math.round(a * 100) / 100);

        String responseString = "";
        Session session = null;
        ChannelExec channel = null;

        try {
            //old was 1000
            // Thread.sleep(1000);
            session = new JSch().getSession(UNAME, HOSTNAME, port);
            session.setPassword(PASS);

            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            channel = (ChannelExec) session.openChannel("exec");

          //NEW CHANGE1-->
            // ((ChannelExec) channel).setCommand("sudo -S -p");
           // ((ChannelExec) channel).setCommand(PASS);
            //((ChannelExec) channel).setCommand("echo " + PASS + " | sudo -S su - && sudo su");
            //END CHANGE1

           //NEW CHANGE2-->
            channel.setCommand("cd " + loglocation + " grep -A 10 " + responseid + "  "+logfilename+";");
          //  channel.setCommand("cd " + loglocation + " && grep -A 10 " + responseid + " " + logfilename);
            System.out.println("LOGDATADLRQUERY-->" + "cd " + loglocation + " grep -A 10 " + responseid + "  "+logfilename+";");
            //END CHANGE2

            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
            channel.setOutputStream(responseStream);
            channel.connect();
//NEW CHANGE 3-->
          /*  while (channel.isConnected()) {


            }  */

            while (!channel.isClosed()) {
                Thread.sleep(200);
            }
//END CHANGE3

            responseString = new String(responseStream.toByteArray());


        } finally {
            if (session != null) {
                session.disconnect();
            }
            if (channel != null) {
                channel.disconnect();
            }

        }
        return responseString;
    }




   /* public static String RUNLINUXCOMMANDANDGETSTRING_RCS(String responseid, String UNAME, String PASS, String HOSTNAME, String loglocation , String logfilename) throws Exception {
        TestBase ob = new TestBase();
        double a = Double.parseDouble(ob.GetProperty("port"));
        int port = (int) (Math.round(a * 100) / 100);

        String responseString = "";
        Session session = null;
        ChannelExec channel = null;

        try {
            //old was 1000
            // Thread.sleep(1000);
            session = new JSch().getSession(UNAME, HOSTNAME, port);
            session.setPassword(PASS);

            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            channel = (ChannelExec) session.openChannel("exec");
            //old was 15000
            // Thread.sleep(2000);

            ((ChannelExec) channel).setCommand("sudo -S -p");
            ((ChannelExec) channel).setCommand(PASS);
            // Thread.sleep(100);

            channel.setCommand("cd " + loglocation + " grep -C 15 " + responseid + "  "+logfilename+";");
            //old was 10000
            //Thread.sleep(1000);
            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
            channel.setOutputStream(responseStream);
            channel.connect();

            while (channel.isConnected()) {


            }//old was 4000
            //// Thread.sleep(1000);

            responseString = new String(responseStream.toByteArray());
            //old was 2000
            // Thread.sleep(1000);


        } finally {
            if (session != null) {
                session.disconnect();
            }
            if (channel != null) {
                channel.disconnect();
            }

        }
        return responseString;
    }  */

    public static String RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(String responseid, String UNAME, String PASS, String HOSTNAME, String loglocation , String logfilename) throws Exception {
        TestBase ob = new TestBase();
        double a = Double.parseDouble(ob.GetProperty("port"));
        int port = (int) (Math.round(a * 100) / 100);

        String responseString = "";
        Session session = null;
        ChannelExec channel = null;

        try {
            //old was 1000
            // Thread.sleep(1000);
            session = new JSch().getSession(UNAME, HOSTNAME, port);
            session.setPassword(PASS);

            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            channel = (ChannelExec) session.openChannel("exec");
            //old was 15000
            // Thread.sleep(2000);

            ((ChannelExec) channel).setCommand("sudo -S -p");
            ((ChannelExec) channel).setCommand(PASS);
            // Thread.sleep(100);

            channel.setCommand("cd " + loglocation + " grep -A 10 " + responseid + "  "+logfilename+";");
            //old was 10000
            //Thread.sleep(1000);
            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
            channel.setOutputStream(responseStream);
            channel.connect();

            while (channel.isConnected()) {


            }//old was 4000
            //// Thread.sleep(1000);

            responseString = new String(responseStream.toByteArray());
            //old was 2000
            // Thread.sleep(1000);


        } finally {
            if (session != null) {
                session.disconnect();
            }
            if (channel != null) {
                channel.disconnect();
            }

        }
        return responseString;
    }


// This function is used to get the entire Redis JSON on the test layer for reporting purpose

    public static JSONObject GETSMSCJSONLOG(String responseid, String UNAME, String PASS, String HOSTNAME, boolean CHECKMSG, String MSGTEXT, String loglocation, String logfilename) throws Exception {
        String responseString = RUNLINUXCOMMANDANDGETSTRING(responseid, UNAME, PASS, HOSTNAME, loglocation,logfilename);


        if (responseString.contains(responseid) && responseString.contains("SUBMITTED TO SMSC")) {

            System.out.println("<font color=\"brown\"><b>Request is successfully sent to SMSC</b></font>");
            jsonObject = GETREDISJSON(responseString);

        } else {
            System.out.println("FAILED  to sent to  SMSC ");
            jsonObject = (JSONObject) JSONValue.parse("{\n" +
                    "  \"sn\": \"NOT SUBMITTED TO SMSC\"\n" +
                    "}");
        }


        return jsonObject;
    }


    public static String GET_RESPONSEID_FROM_PROCESSORLOG(String messageid, String UNAME, String PASS, String HOSTNAME,  String loglocation, String logfilename) throws Exception {
        String responseString = RUNLINUXCOMMANDANDGETSTRING(messageid, UNAME, PASS, HOSTNAME, loglocation,logfilename);

        System.out.println("COMPLETE DATA"+responseString);
        String value="";
        if (responseString.contains(messageid) && responseString.contains("SUBMITED TO BUFFER MANAGER")) {

            //System.out.println("<font color=\"brown\"><b>Request is successfully sent to BUFFER MANAGER</b></font>");



                 value = responseString.substring(
                        responseString.indexOf("\"rs\":\"") + 6,
                        responseString.indexOf(",", responseString.indexOf("\"rs\":\"") + 6));
//System.out.println("TEMPDTA"+value);
        } else {
            value="NODATA";
            System.out.println("<font color=\"brown\"><b>Request is NOT successfully sent to BUFFER MANAGER</b></font>");

        }


        return value;
    }

    public static JSONObject GETDLRJSONLOG(String responseid, String UNAME, String PASS, String HOSTNAME, boolean CHECKMSG, String MSGTEXT, String loglocation, String logfilename) throws Exception {
        String responseString = RUNLINUXCOMMANDANDGETSTRING(responseid, UNAME, PASS, HOSTNAME, loglocation,logfilename);


        if (responseString.contains(responseid)) {

            System.out.println("<font color=\"brown\"><b>DLR for Request is successfull</b></font>");
            jsonObject = GETDLRJSON(responseString);

        } else {
            System.out.println("DLR NOT RECIEVED");
            jsonObject = (JSONObject) JSONValue.parse("{\n" +
                    "  \"sn\": \"DLR NOT RECIEVED\"\n" +
                    "}");
        }


        return jsonObject;
    }

    public static boolean CheckPrepaidbalance(String responseid, String UNAME, String PASS, String HOSTNAME, boolean CHECKMSG, String MSGTEXT, String loglocation, String logfilename) throws Exception {
        TestBase ob = new TestBase();
        double a = Double.parseDouble(ob.GetProperty("port"));
        int port = (int) (Math.round(a * 100) / 100);
        boolean recieverresult = false;
        boolean SMSCRESULT = false;

        SMSCRESULT = LinuxLogReader.CHECKPREPAIDBALANCE(UNAME, PASS, HOSTNAME, port, responseid, CHECKMSG, MSGTEXT, loglocation,logfilename);
        return SMSCRESULT;
        //Assert.assertTrue(SMSCRESULT, "Prepaid balance insufficent test for  The responseID " + responseid + "  FAILED");
    }

    public static boolean CheckLOGERRORMESSAGE(String ERRMSG, String responseid, String UNAME, String PASS, String HOSTNAME, boolean CHECKMSG, String MSGTEXT, String loglocation ,String logfilename) throws Exception {
        TestBase ob = new TestBase();
        double a = Double.parseDouble(ob.GetProperty("port"));
        int port = (int) (Math.round(a * 100) / 100);
        //  boolean recieverresult=false;
        boolean SMSCRESULT = false;

        SMSCRESULT = LinuxLogReader.CHECKLOGFORERRORMESSAGES(ERRMSG, UNAME, PASS, HOSTNAME, port, responseid, CHECKMSG, MSGTEXT, loglocation,logfilename);
        return SMSCRESULT;

    }
    public static boolean CheckDLRLOGMESSAGE(String ERRMSG, String responseid, String UNAME, String PASS, String HOSTNAME, boolean CHECKMSG, String MSGTEXT, String loglocation ,String logfilename) throws Exception {
        TestBase ob = new TestBase();
        double a = Double.parseDouble(ob.GetProperty("port"));
        int port = (int) (Math.round(a * 100) / 100);
        //  boolean recieverresult=false;
        boolean SMSCRESULT = false;

        SMSCRESULT = LinuxLogReader.CHECKLOGFORDLRMESSAGES(ERRMSG, UNAME, PASS, HOSTNAME, port, responseid, CHECKMSG, MSGTEXT, loglocation,logfilename);
        return SMSCRESULT;

    }

    public static void CheckDlttemplatenotfound(String responseid, String UNAME, String PASS, String HOSTNAME, boolean CHECKMSG, String MSGTEXT, String loglocation ,String logfilename) throws Exception {
        TestBase ob = new TestBase();
        double a = Double.parseDouble(ob.GetProperty("port"));
        int port = (int) (Math.round(a * 100) / 100);
        boolean recieverresult = false;
        boolean SMSCRESULT = false;

        SMSCRESULT = LinuxLogReader.CHECKDLTTEMPLATENOTFOUND(UNAME, PASS, HOSTNAME, port, responseid, CHECKMSG, MSGTEXT, loglocation,logfilename);
        Assert.assertTrue(SMSCRESULT, "DLT template not found test for  The responseID " + responseid + "  FAILED");
    }

//This function is used to check if DLR csv is generated after API hit or not.
    public static boolean CHECKDLRCSV() throws Exception {
        TestBase object = new TestBase();
        Session session = null;
        ChannelExec channel = null;

        try {
            session = new JSch().getSession(object.GetProperty("UsernameCON"), object.GetProperty("hostnameCON"), 22);
            session.setPassword(object.GetProperty("PasswordCON"));
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();


            channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand("cd " + object.GetProperty("DLRCSVlocation") + "; ls -lrth");
            Thread.sleep(5000);
            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
            channel.setOutputStream(responseStream);
            channel.connect();

            while (channel.isConnected()) {
                //System.out.println("I am inside");
            }

            String responseString = new String(responseStream.toByteArray());
            //System.out.println(responseString);
            LocalDateTime X = LocalDateTime.now();
            DateTimeFormatter PP = DateTimeFormatter.ofPattern("d-M-yyyy");
            String XX = X.format(PP);
            System.out.println("push_dlr-" + XX);
            String[] lines = responseString.split("\\r?\\n");
            String ActualCSVfilename = lines[lines.length - 1];
            System.out.println("The last CSV file name present is " + ActualCSVfilename);

            if (ActualCSVfilename.contains("push_dlr-" + XX)) {
                Date date = new Date();
                SimpleDateFormat Expecteddatetime = new SimpleDateFormat("MMM dd HH:mm");
                String stringDate = Expecteddatetime.format(date);
                Date Expecteddtime = new SimpleDateFormat("MMM dd HH:mm").parse(stringDate);
                System.out.println("Expectedtime-->" + Expecteddtime);

                Date date2 = new Date();
                SimpleDateFormat Expecteddatetime2 = new SimpleDateFormat("MMM dd");
                String stringDate2 = Expecteddatetime2.format(date2);
                //System.out.println("temp-->"+ActualCSVfilename.substring(34,40));
                //System.out.println("Index of : is -->"+ActualCSVfilename.indexOf(':'));
                int timesplit = ActualCSVfilename.indexOf(':');
                String tm = stringDate2 + "" + ActualCSVfilename.substring(timesplit - 3, timesplit + 3);
                System.out.println("Time is-->" + tm);
                Date Actualtime = new SimpleDateFormat("MMM dd HH:mm").parse(tm);
                System.out.println("Actualtime-->" + Actualtime);

                long diff = (Expecteddtime.getTime() - Actualtime.getTime());
                long diffSeconds = diff / 1000;

                System.out.println("Diffrence of time is " + diffSeconds + " Seconds");

                if (diffSeconds <= 240) {
                    return true;
                } else {
                    return false;
                }

            } else {
                return false;
            }


        } catch (Exception e) {
            System.out.println(e);
            return false;
        } finally {
            if (session != null) {
                session.disconnect();
            }
            if (channel != null) {
                channel.disconnect();
            }

        }


    }
//this function is used to check if the consumer csv is generated after API hit or not
    //this function return true if there is csv present with + - 60 seconds file time
    public static boolean CHECKCONSUMERCSV() throws Exception {


        TestBase object = new TestBase();
        Session session = null;
        ChannelExec channel = null;

        try {
            session = new JSch().getSession(object.GetProperty("UsernameCON"), object.GetProperty("hostnameCON"), 22);
            session.setPassword(object.GetProperty("PasswordCON"));
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();


            channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand("cd " + object.GetProperty("RecieverCSVlocation") + "; ls -lrth");

            Thread.sleep(5000);
            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
            channel.setOutputStream(responseStream);
            channel.connect();

            while (channel.isConnected()) {
                //System.out.println("I am inside");
            }

            String responseString = new String(responseStream.toByteArray());


            System.out.println(responseString);
            LocalDateTime X = LocalDateTime.now();
            DateTimeFormatter PP = DateTimeFormatter.ofPattern("d-M-yyyy");
            String XX = X.format(PP);
            System.out.println("push_receiver-" + XX);
            String ee = "push_receiver-" + XX;
            int index = responseString.indexOf("push_receiver-" + XX);
            String Actualcsvfile = responseString.substring(index - 14);

//Dec 30 13:41 push_receiver-30-12-2021-13.csv
            System.out.println("This is actual file name -->" + Actualcsvfile);

            if (Actualcsvfile.contains(ee)) {
                System.out.println("Current date" + ee + " file is present");


                String tm = Actualcsvfile.substring(8, 13);
                System.out.println("Time is-->" + tm);
                Date Actualtime = new SimpleDateFormat("HH:mm").parse(tm);
                System.out.println("Actualtime-->" + Actualtime.getTime());
                //This section calculates expecteddatetime

                Date date = new Date();
                SimpleDateFormat Expecteddatetime = new SimpleDateFormat("HH:mm");
                String stringDate = Expecteddatetime.format(date);
                Date Expecteddtime = new SimpleDateFormat("HH:mm").parse(stringDate);
                System.out.println("Expectedtime-->" + Expecteddtime);


                long diff = (Expecteddtime.getTime() - Actualtime.getTime());
                long diffSeconds = diff / 1000;
                //   long diffMinutes = diff / (60 * 1000);
                // long diffHours = diff / (60 * 60 * 1000);
                System.out.println("Diffrence of time is " + diffSeconds + " Seconds");

                if (diffSeconds <= 60) {
                    return true;
                } else {
                    return false;
                }

            } else {
                return false;
            }


        } catch (Exception e) {
            System.out.println(e);
            return false;
        } finally {
            if (session != null) {
                session.disconnect();
            }
            if (channel != null) {
                channel.disconnect();
            }

        }


    }



    public static boolean CHECKSQREAMLOG() throws Exception {


        TestBase object = new TestBase();
        Session session = null;
        ChannelExec channel = null;

        try {
            session = new JSch().getSession(object.GetProperty("UsernameCON"), object.GetProperty("hostnameCON"), 22);
            session.setPassword(object.GetProperty("PasswordCON"));
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();


            channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand("cd " + object.GetProperty("RecieverCSVlocation") + "; ls -lrth");

            Thread.sleep(5000);
            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
            channel.setOutputStream(responseStream);
            channel.connect();

            while (channel.isConnected()) {
                //System.out.println("I am inside");
            }

            String responseString = new String(responseStream.toByteArray());


            System.out.println(responseString);
            LocalDateTime X = LocalDateTime.now();
            DateTimeFormatter PP = DateTimeFormatter.ofPattern("d-M-yyyy");
            String XX = X.format(PP);
            System.out.println("push_receiver-" + XX);
            String ee = "push_receiver-" + XX;
            int index = responseString.indexOf("push_receiver-" + XX);
            String Actualcsvfile = responseString.substring(index - 14);

//Dec 30 13:41 push_receiver-30-12-2021-13.csv
            System.out.println("This is actual file name -->" + Actualcsvfile);

            if (Actualcsvfile.contains(ee)) {
                System.out.println("Current date" + ee + " file is present");


                String tm = Actualcsvfile.substring(8, 13);
                System.out.println("Time is-->" + tm);
                Date Actualtime = new SimpleDateFormat("HH:mm").parse(tm);
                System.out.println("Actualtime-->" + Actualtime.getTime());
                //This section calculates expecteddatetime

                Date date = new Date();
                SimpleDateFormat Expecteddatetime = new SimpleDateFormat("HH:mm");
                String stringDate = Expecteddatetime.format(date);
                Date Expecteddtime = new SimpleDateFormat("HH:mm").parse(stringDate);
                System.out.println("Expectedtime-->" + Expecteddtime);


                long diff = (Expecteddtime.getTime() - Actualtime.getTime());
                long diffSeconds = diff / 1000;
                //   long diffMinutes = diff / (60 * 1000);
                // long diffHours = diff / (60 * 60 * 1000);
                System.out.println("Diffrence of time is " + diffSeconds + " Seconds");

                if (diffSeconds <= 60) {
                    return true;
                } else {
                    return false;
                }

            } else {
                return false;
            }


        } catch (Exception e) {
            System.out.println(e);
            return false;
        } finally {
            if (session != null) {
                session.disconnect();
            }
            if (channel != null) {
                channel.disconnect();
            }

        }


    }

    public static String CHECKSQREAMLOG( String FLE,String DTE) throws Exception {


        //TestBase object = new TestBase();
        Session session = null;
        ChannelExec channel = null;

        try {
            session = new JSch().getSession("qateam", "10.0.6.110", 22);
            session.setPassword("Sqream$q@123");
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            String filename="pushlive_whatsapp_receiver";


            channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand("cd " + "/gpfssqst/disk1/error_log" + "; ls -lrth  "+FLE+"_"+DTE+"*");

            Thread.sleep(5000);
            ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
            channel.setOutputStream(responseStream);
            channel.connect();

            while (channel.isConnected()) {
                //System.out.println("I am inside");
            }

            String responseString = new String(responseStream.toByteArray());
return responseString;




        } catch (Exception e) {
            System.out.println(e);
             return e.toString();
        } finally {
            if (session != null) {
                session.disconnect();
            }
            if (channel != null) {
                channel.disconnect();
            }

        }
    }


    public static boolean checkComponentLog(
            String responseid,
            String UNAME,
            String PASS,
            String HOSTNAME,boolean CHECKMSG, String MSGTEXT,
            String loglocation,
            String logfilename
    ) throws Exception {

        if (responseid == null || responseid.startsWith("-")) {
            return false;
        }

        String responseString = RUNLINUXCOMMANDANDGETSTRING(
                responseid, UNAME, PASS, HOSTNAME, loglocation, logfilename
        );

        System.out.println("Log text: " + responseString);

        boolean result = responseString != null && responseString.contains(responseid);

        System.out.println(result
                ? "Request received"
                : "Request NOT received");

        return result;
    }

    public static boolean CheckcommondhsiLOG(String responseid, String dlthashid, String UNAME, String PASS,
                                             String HOSTNAME, boolean CHECKMSG, String MSGTEXT,
                                             String loglocation, String logfilename) throws Exception {

        System.out.println("dlthashid passed in API: " + dlthashid);

        if (responseid.startsWith("-")) {
            return false;
        } else {

            String responseString = RUNLINUXCOMMANDANDGETSTRINGSUDO(
                    responseid, UNAME, PASS, HOSTNAME, loglocation, logfilename);
            System.out.println("Data" + responseString);

            // ✅ Print Expected
            // System.out.println("Expected DLT Hash ID on listener 187: " + dlthashid);

            if (responseString.contains(dlthashid)) {
                System.out.println("DLT HASHID FOUND" +dlthashid );
                System.out.println("Status: MATCHED");
                return true;

            } else {
                System.out.println("DLT HASHID NOT FOUND" +dlthashid );
                return false;
            }
        }
    }

    public static String RUNLINUXCOMMANDANDGETSTRINGSUDO(String responseid, String UNAME, String PASS,
                                                         String HOSTNAME, String loglocation,
                                                         String logfilename) throws Exception {

        TestBase ob = new TestBase();
        int port = Integer.parseInt(ob.GetProperty("port"));

        String responseString = "";
        Session session = null;
        ChannelExec channel = null;

        try {
            session = new JSch().getSession(UNAME, HOSTNAME, port);
            session.setPassword(PASS);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();

            channel = (ChannelExec) session.openChannel("exec");
            String safeLogLocation = loglocation.replace(";", "").trim();

            String command = "sudo -S grep -F '" + responseid + "' "
                    + safeLogLocation + "/" + logfilename;

            System.out.println("Executing: " + command);

            channel.setCommand(command);

            InputStream in = channel.getInputStream();
            OutputStream out = channel.getOutputStream();

            channel.connect();

            // send sudo password
            out.write((PASS + "\n").getBytes());
            out.flush();

            StringBuilder output = new StringBuilder();
            byte[] tmp = new byte[1024];

            while (true) {

                while (in.available() > 0) {
                    int i = in.read(tmp, 0, 1024);
                    if (i < 0) break;
                    output.append(new String(tmp, 0, i));
                }

                if (channel.isClosed()) {
                    if (in.available() > 0) continue;
                    break;
                }

                Thread.sleep(200);
            }

            responseString = output.toString();
            System.out.println("FINAL OUTPUT:\n" + responseString);

        } finally {
            if (channel != null) channel.disconnect();
            if (session != null) session.disconnect();
        }

        return responseString;
    }


}