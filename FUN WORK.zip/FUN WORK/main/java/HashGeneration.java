import org.bouncycastle.util.encoders.Hex;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class HashGeneration {
	public static void main(String[] arg) {
//test
		String userid = "samv3";
		String pwd = "samv3";
		String time = "123456789";
		String salt = "1234567890123456";
		String input = userid + pwd + time;
		char[] tempArray = input.toCharArray();
		Arrays.sort(tempArray);
		input = new String(tempArray);
		try {
			System.out.println(new HashGeneration().getSHA512SecurePassword(input, salt.getBytes("UTF-8")));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// String userInfoString="test@##@12345";
		// String[] userInfoArray = userInfoString.split("@##@");
		// System.out.println("LENGTH::"+userInfoArray.length);
		// System.out.println("LENGTH::"+userInfoArray[0]);
		// System.out.println("LENGTH::"+userInfoArray[1]);

	}

	public String getSHA512SecurePassword(String passwordToHash, byte[] salt) {
		String generatedPassword = null;
		// Hex hex = new Hex();
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			md.update(salt);
			byte[] bytes = md.digest(passwordToHash.getBytes());
			generatedPassword = new String(Hex.encode(bytes));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return generatedPassword;
	}
}
