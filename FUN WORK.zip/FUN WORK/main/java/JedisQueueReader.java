import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import redis.clients.jedis.Jedis;

import java.util.Iterator;
import java.util.List;

public class JedisQueueReader {
    public static String GetRedisdata(String redis_server_ip,String redis_server_user,String redis_server_pass,String redis_server_host,String redis_server_port,String redis_host_pass, String QNAME)
    {
        String sshHost = redis_server_ip;  // SSH server address
        String sshUser = redis_server_user;    // SSH username
        String sshPassword = redis_server_pass;  // SSH password
        int sshPort = 22;
        //  redis-18539.rediscluster-prod.aclmobile.com"// SSH port
        String redisHost = redis_server_host;         // Redis host (inside the SSH tunnel)
        int redisPort = Integer.parseInt(redis_server_port);                   // Redis port
        String redisPassword = redis_host_pass; // Redis password
        String queueName = QNAME;//"RCS_NOT__+919838301908";   // Redis Queue name
        Session session=null;
        String qvalue=null;
        // Set up SSH tunnel using JSch
        try {
            // Initialize JSch session
            JSch jsch = new JSch();
            session = jsch.getSession(sshUser, sshHost, sshPort);
            session.setPassword(sshPassword);
            session.setConfig("TCPKeepAlive", "true");
            session.setConfig("KeepAliveInterval", "60");  // Keep-alive interval (in seconds)
            session.setConfig("ServerAliveInterval", "60"); // Send keep-alive messages every 60 seconds
            session.setConfig("ServerAliveCountMax", "3"); // Max attempts before disconnect
            // Set up the session configuration to disable strict host key checking
            session.setConfig("StrictHostKeyChecking", "no");
            System.out.println("Establishing SSH tunnel...");
            // Establish the SSH session
            session.connect();

            // Set up port forwarding (local port 6379 -> remote redis port)
            int localPort = 6379;  // Local port to forward to
            System.out.println("SSH Tunnel established. Forwarding port...");
            session.setPortForwardingL(localPort, redisHost, redisPort);

            System.out.println("SSH tunnel established, forwarding local port " + localPort + " to remote Redis server.");

            // Connect to Redis via Jedis through the SSH tunnel
            Jedis jedis = new Jedis("localhost", localPort,5000);
            jedis.auth(redisPassword);  // Authenticate to Redis if necessary

            System.out.println("Connected to Redis.");
            String keyType = jedis.type(queueName);
            System.out.println("Key type: " + keyType);
            qvalue=  jedis.get(queueName);
            System.out.println("Received data: " + qvalue);
            // Read data from Redis queue
           /* while (true) {
                List<String> messages = jedis.brpop(10, queueName);  // Blocks until a message is available
                if (messages != null && !messages.isEmpty()) {
                    String message = messages.get(1); // The message is the second element in the list
                    System.out.println("Received message: " + message);
                }
            }*/
        } catch ( Exception e) {
            e.printStackTrace();
        }
        finally {
            session.disconnect();


        }
        return qvalue;
    }

    public static String Getcredenceredisdata(String responseid) {
        String credencedata="";
        String sshHost = "10.0.6.141";  // SSH server address
        String sshUser = "saurabhg";    // SSH username
        String sshPassword = "saurabhg@321";  // SSH password
        int sshPort = 22;
        //  redis-18539.rediscluster-prod.aclmobile.com"// SSH port
        String redisHost = "redis-18539.rediscluster-prod.aclmobile.com";         // Redis host (inside the SSH tunnel)
        int redisPort = 18539;                   // Redis port
        String redisPassword = "aclindia"; // Redis password
        String queueName = "THIRDPARTY_SEC_RETRY_QUEUE";//RCS_NOT_CAPABLE_+919838301908";   // Redis Queue name
        Session session=null;
        // Set up SSH tunnel using JSch
        try {
            // Initialize JSch session
            JSch jsch = new JSch();
            session = jsch.getSession(sshUser, sshHost, sshPort);
            session.setPassword(sshPassword);
            session.setConfig("TCPKeepAlive", "true");
            session.setConfig("KeepAliveInterval", "60");  // Keep-alive interval (in seconds)
            session.setConfig("ServerAliveInterval", "60"); // Send keep-alive messages every 60 seconds
            session.setConfig("ServerAliveCountMax", "3"); // Max attempts before disconnect
            // Set up the session configuration to disable strict host key checking
            session.setConfig("StrictHostKeyChecking", "no");
            System.out.println("Establishing SSH tunnel...");
            // Establish the SSH session
            session.connect();

            // Set up port forwarding (local port 6379 -> remote redis port)
            int localPort = 6379;  // Local port to forward to
            System.out.println("SSH Tunnel established. Forwarding port...");
            session.setPortForwardingL(localPort, redisHost, redisPort);

            System.out.println("SSH tunnel established, forwarding local port " + localPort + " to remote Redis server.");

            // Connect to Redis via Jedis through the SSH tunnel
            Jedis jedis = new Jedis("localhost", localPort,5000);
            jedis.auth(redisPassword);  // Authenticate to Redis if necessary

            System.out.println("Connected to Redis.");
            String keyType = jedis.type(queueName);
            System.out.println("Key type: " + keyType);
            // String qvalue=  jedis.get("testauto");
            // System.out.println("Received data: " + qvalue);

            // Read data from Redis queue list
            long Qlenth= jedis.llen(queueName);
            if(Qlenth<1000) {
                List<String> messages = jedis.lrange(queueName,0,-1);

                // List<String> messages = jedis.brpop(10, "LST");
                System.out.println("Data in Q is "+Qlenth);
                Iterator it=messages.listIterator();

                while (it.hasNext()) {
                    // Blocks until a message is available
                    if (messages != null && !messages.isEmpty()) {

                        String message = (String) it.next();
                       // System.out.println("Received redis data: " + message);
                        if(message.contains(responseid)) {
                            System.out.println("Received redis data: " + message);
                            credencedata=(String)message;
                            break;

                        }
                    }
                }

            } else {
                System.out.println("List size is very big "+Qlenth);
            }

        } catch ( Exception e) {
            e.printStackTrace();
        }
        finally {
            session.disconnect();
         return credencedata;

        }
    }


    public static void  LPUSH_bajajunified_redisdata(String data) {
       // String s1="'"+data+"'";
        String s1=data;
String ffff="{\"auth\":\"bajaj41\",\"language\":\"en\",\"subauth\":\"user_1\",\"ffrq\":\"30\",\"rtype\":\"Fallback\",\"routing\":\"RCS-SMS\",\"shorten\":\"FALSE\",\"alert\":\"1\",\"brd\":\"emi_reminder\",\"body_var1\":\"ABC\",\"body_var2\":\"credit card\",\"body_var3\":\"XX1234\",\"subappid\":\"bajfalt\",\"from\":\"BAJAJF\",\"body_var4\":\"50%\",\"rcshvar\":\"cute-dog\",\"text\":\"Dear Customer this is Transactional (Name: {#var#}; Customer ID: {#var#} ), Bill for {#var#} A/c has been generated. Pay this Bill of Rs {#var#}/- Online within the Due Date {#var#} to avail 1% additional rebate.\",\"body_var5\":\"body_var5\",\"dtm\":\"34564\",\"peid\":\"123456\",\"pass\":\"bajfalt31\",\"rcsbotid\":\"bajajtrans\",\"rcstd\":\"sinch_sftp_test13\",\"msgid\":\"BAJA_FALL_RCS_SMS\",\"userId\":\"bajfalt\",\"intflag\":\"false\",\"contenttype\":\"1\",\"tlive\":\"1200\",\"button_var1\":\"Yes\",\"appid\":\"bajfalt\",\"bsize\":\"4\",\"button_var2\":\"Yes\",\"to\":\"917838787657\",\"title_var1\":\"Grab the offer\"}";
        String credencedata="";
        String sshHost = "10.0.6.141";  // SSH server address
        String sshUser = "saurabhg";    // SSH username
        String sshPassword = "saurabhg@321";  // SSH password
        int sshPort = 22;
        //  redis-18539.rediscluster-prod.aclmobile.com"// SSH port
        String redisHost = "redis-18539.rediscluster-prod.aclmobile.com";         // Redis host (inside the SSH tunnel)
        int redisPort = 18539;                   // Redis port
        String redisPassword
                = "aclindia"; // Redis password
        String queueName = "bajajunified";//RCS_NOT_CAPABLE_+919838301908";   // Redis Queue name
        Session session=null;
        // Set up SSH tunnel using JSch
        try {
            // Initialize JSch session
            JSch jsch = new JSch();
            session = jsch.getSession(sshUser, sshHost, sshPort);
            session.setPassword(sshPassword);
            session.setConfig("TCPKeepAlive", "true");
            session.setConfig("KeepAliveInterval", "60");  // Keep-alive interval (in seconds)
            session.setConfig("ServerAliveInterval", "60"); // Send keep-alive messages every 60 seconds
            session.setConfig("ServerAliveCountMax", "3"); // Max attempts before disconnect
            // Set up the session configuration to disable strict host key checking
            session.setConfig("StrictHostKeyChecking", "no");
            System.out.println("Establishing SSH tunnel...");
            // Establish the SSH session
            session.connect();

            // Set up port forwarding (local port 6379 -> remote redis port)
            int localPort = 6379;  // Local port to forward to
            System.out.println("SSH Tunnel established. Forwarding port...");
            session.setPortForwardingL(localPort, redisHost, redisPort);

            System.out.println("SSH tunnel established, forwarding local port " + localPort + " to remote Redis server.");

            // Connect to Redis via Jedis through the SSH tunnel
            Jedis jedis = new Jedis("localhost", localPort,5000);
            jedis.auth(redisPassword);  // Authenticate to Redis if necessary

            System.out.println("Connected to Redis.");
           // String keyType = jedis.type(queueName);
            //System.out.println("Key type: " + keyType);

           System.out.println("RPUSH "+queueName+ " " +s1);

                jedis.rpush(queueName,s1);
                System.out.println("The redis length is "+jedis.llen(queueName));
                List<String> messages = jedis.lrange(queueName,0,-1);
                System.out.println("The redis data  is "+messages);

                // List<String> messages = jedis.brpop(10, "LST");

        } catch ( Exception e) {
            e.printStackTrace();
        }
        finally {
            session.disconnect();
            //return credencedata;

        }
    }
    public static void main(String[] args) {

       // LPUSH_bajajunified_redisdata();

        }
}