
import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
public class JSONENCYPTER{
    //test
    private final String characterEncoding = "UTF-8";
    private final String cipherTransformation = "AES/CBC/PKCS5Padding";
    private final String aesEncryptionAlgorithm = "AES";
    private final Base64 base64 = new Base64();

    public byte[] decrypt(byte[] cipherText, byte[] key, byte[] initialVector)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(cipherTransformation);
        SecretKeySpec secretKeySpecy = new SecretKeySpec(key, aesEncryptionAlgorithm);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(initialVector);
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpecy, ivParameterSpec);
        cipherText = cipher.doFinal(cipherText);
        return cipherText;
    }

    public byte[] encrypt(byte[] plainText, byte[] key, byte[] initialVector)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(cipherTransformation);
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, aesEncryptionAlgorithm);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(initialVector);
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
        plainText = cipher.doFinal(plainText);
        return plainText;
    }


    public String encrypt(String plainText, String key, String ivKey)
            throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        byte[] plainTextbytes = plainText.getBytes(characterEncoding);
        byte[] keyBytes = getIVKeyBytes(ivKey);
        return base64.encodeToString(encrypt(plainTextbytes, key.getBytes("UTF-8"), keyBytes));
    }

    public String decrypt(String encryptedText, String key, String ivKey) throws KeyException, GeneralSecurityException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {
        byte[] cipheredBytes = new Base64().decode(encryptedText);
        byte[] keyBytes = getIVKeyBytes(ivKey);
        return new String(decrypt(cipheredBytes, key.getBytes("UTF-8"), keyBytes), characterEncoding);
    }

    private byte[] getIVKeyBytes(String key) throws UnsupportedEncodingException {
        byte[] keyBytes = new byte[16];
        byte[] parameterKeyBytes = key.getBytes(characterEncoding);
        System.arraycopy(parameterKeyBytes, 0, keyBytes, 0, Math.min(parameterKeyBytes.length, keyBytes.length));
        return keyBytes;
    }

    public String encrypt(String plainText, String key)
            throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        byte[] plainTextbytes = plainText.getBytes(characterEncoding);
        byte[] keyBytes = getIVKeyBytes(key);
        return base64.encodeToString(encrypt(plainTextbytes, keyBytes, keyBytes));
    }

    public String decrypt(String encryptedText, String key) throws KeyException, GeneralSecurityException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {
        byte[] cipheredBytes = new Base64().decode(encryptedText);
        byte[] keyBytes = getIVKeyBytes(key);
        return new String(decrypt(cipheredBytes, keyBytes, keyBytes), characterEncoding);
    }

    public static String readFileAsString(String file)throws Exception
    {
        return new String(Files.readAllBytes(Paths.get(file)));
    }

// Below function basically reads JSON data from String jsonDataInFile and converts the JSON into encrypted form and
// places that encrypted json at location defined in String propertyname


    public static void TestJSONENCRYPTION(String filename, String APIname, String KEYCODE,String APPID) throws Exception {
        //APIname like V2 V5 V9 ETC
        String jsonDataInFile = System.getProperty("user.dir") +"/"+"src/main/resources/Util/JSON_REPOSITORY_"+APIname+"/"+filename;

        String input12=readFileAsString(jsonDataInFile);


       // String key = "testdlt301291009";
        String key = KEYCODE;


        try {
            FileReader reader = new FileReader(jsonDataInFile);
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
            String encrypt = new JSONENCYPTER().encrypt(input12, key);
            System.out.println("After encrption data-->" +encrypt);

            try {
                // read the json file
                String propertyname="encrptedjsonpath"+APIname;
                FileReader reader2 = new FileReader(new TestBase().GetProperty(propertyname));
                JSONParser jsonParser2 = new JSONParser();
                JSONObject jsonObject2 = (JSONObject) jsonParser2.parse(reader2);

                jsonObject2.put("encryptedData",encrypt);
                jsonObject2.put("appid",APPID);
                // System.out.println(jsonObject2);

                FileWriter writer = new FileWriter(new TestBase().GetProperty(propertyname));
                writer.write(jsonObject2.toString());

                reader2.close();
                writer.close();


            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (ParseException ex) {
                ex.printStackTrace();
            } catch (NullPointerException ex) {
                ex.printStackTrace();
            }
            //---->
            reader.close();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }



// Below function basically reads JSON data from String jsonDataInFile and converts the JSON into encrypted form and
// places that encrypted json at location defined in String propertyname
//This is used for V3
    public static void TestJSONENCRYPTION_TOKEN(String filename, String APIname, String KEYCODE,String APPID,String ivkey) throws Exception {
        //APIname like V3 V6 V12 ETC
        String jsonDataInFile = System.getProperty("user.dir") +"/"+"src/main/resources/Util/JSON_REPOSITORY_"+APIname+"/"+filename;

        String input12=readFileAsString(jsonDataInFile);



        String key = KEYCODE;

        String nounce=ivkey;

        try {
            FileReader reader = new FileReader(jsonDataInFile);
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
            String encrypt = new JSONENCYPTER().encrypt(input12, key,nounce);
            System.out.println("After encrption data-->" +encrypt);
//            String decrypt = new JSONENCYPTER().decrypt(encrypt, key,nounce);
//            System.out.println("After Decrpytion data-->" +decrypt);


            try {
                // read the json file
                String propertyname="encrptedjsonpath"+APIname;

                FileReader reader2 = new FileReader(new TestBase().GetProperty(propertyname));
                JSONParser jsonParser2 = new JSONParser();
                JSONObject jsonObject2 = (JSONObject) jsonParser2.parse(reader2);

                jsonObject2.put("encryptedData",encrypt);
                jsonObject2.put("appid",APPID);
                jsonObject2.put("nounce",nounce);
                // System.out.println(jsonObject2);

                FileWriter writer = new FileWriter(new TestBase().GetProperty(propertyname));
                writer.write(jsonObject2.toString());

                reader2.close();
                writer.close();


            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (ParseException ex) {
                ex.printStackTrace();
            } catch (NullPointerException ex) {
                ex.printStackTrace();
            }
            //---->
            reader.close();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}

