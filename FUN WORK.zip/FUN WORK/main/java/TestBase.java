import com.opencsv.CSVWriter;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestBase {
    public static Properties prop;

    // TestBase ob1 = new TestBase();
    public TestBase() {
        try {
            prop = new Properties();
            FileInputStream ip = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources/coreconfig.properties");
            prop.load(ip);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String GetProperty(String propname) {
        return prop.getProperty(propname);
    }

    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_Open_Template_V1(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY, String dtm, String dpi, String tc) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V9") || REPOSITORY.contentEquals("JSON_REPOSITORY_V1"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                //   System.out.println("This is mobile no from excel sheet "+ph[1]);
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("dtm", dtm);
                jsonObject.put("dpi", dpi);
                jsonObject.put("tc", tc);
                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }
                if (dtm.contentEquals("BLK")) {
                    jsonObject.put("dtm", "");
                } else {
                    jsonObject.put("dtm", dtm);
                }
                if (dpi.contentEquals("BLK")) {
                    jsonObject.put("dpi", "");
                } else {
                    jsonObject.put("dpi", dpi);
                }
                if (tc.contentEquals("BLK")) {
                    jsonObject.put("tc", "");
                } else {
                    jsonObject.put("tc", tc);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE(String msgtext, int contenttype, String JSONTYPE, String REPOSITORY, String Language) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V9") || REPOSITORY.contentEquals("JSON_REPOSITORY_V1"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);

                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));

                jsonObject.put("text", msgtext);
                jsonObject.put("contenttype", String.valueOf(contenttype));
                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else if (JSONTYPE.contentEquals("Messages") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V2") || REPOSITORY.contentEquals("JSON_REPOSITORY_V4"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                //System.out.println("before update "+jsonObject);

                jsonObject.put("contenttype", String.valueOf(contenttype));
                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }
                //  System.out.println("after update "+jsonObject);

                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {
                    // System.out.println("jsonarray -->[" +i+"]--> "+ jray.get(i));
                    JSONObject smallobject = (JSONObject) jray.get(i);
                    smallobject.put("msg", msgtext);
                }
                //System.out.println("after update "+jsonObject);

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                reader.close();
                writer.close();
            } else if (JSONTYPE.contentEquals("msg") && (REPOSITORY.contentEquals("JSON_REPOSITORY_v5") || REPOSITORY.contentEquals("JSON_REPOSITORY_V7"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);

                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));

                jsonObject.put("msg", msgtext);
                jsonObject.put("contenttype", String.valueOf(contenttype));
                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_V4V2(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY) {
        try {
            String ph[] = to.split("X");
            to = ph[1];
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V4") || REPOSITORY.contentEquals("JSON_REPOSITORY_V2"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);

                // jsonObject.put("to", "7838787657");
                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {
                    // System.out.println("jsonarray -->[" +i+"]--> "+ jray.get(i));
                    JSONObject smallobjecttext = (JSONObject) jray.get(i);
                    smallobjecttext.put("msg", msgtext);
                    JSONObject smallobjectFROM = (JSONObject) jray.get(i);
                    smallobjectFROM.put("from", from);

                    JSONObject smallobjectTO = (JSONObject) jray.get(i);

                    smallobjectTO.put("to", to);

                    JSONObject smallobjectLANGUAGE = (JSONObject) jray.get(i);


                    if (Language.contentEquals("BLK")) {
                        smallobjectLANGUAGE.put("language", "");
                    } else {
                        smallobjectLANGUAGE.put("language", Language);
                    }
                }
                double random = Math.random();

                double x = random * 1000000;

                int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
//MSGID ADDED DYNAMICALLY
                jsonObject.put("msgid", MSGID);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                // jsonObject.put("auth", APPID);
                //jsonObject.put("subauth",APPID);


                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_V1(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY,String shortening) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V9") || REPOSITORY.contentEquals("JSON_REPOSITORY_V1"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("This is mobile no from excel sheet "+ph[1]);
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }
                //SHORTENING RELATED TWEAK DONE BY SAURABH 16JUL2026 11:07 AM

                if(shortening.contentEquals("NO") )
                {

                }else {

                    String Ss = "";
                    try {
                        double stype = Double.parseDouble(shortening);
                        int istype = (int) (Math.round(stype * 100) / 100);
                        Ss = String.valueOf(istype);
                        jsonObject.put("s", Ss);
                    } catch (NumberFormatException e) {
                        Ss = "";
                    }

                    if (Language.contentEquals("BLK")) {
                        Language = "";
                    }
                }
                // END OF SHORTENING RELATED TWEAK DONE BY SAURABH 16JUL2026 11:07 AM

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void SETMSGTEXTANDCONTENTTYPE_SBISINGLE(String functionname, String username, String password, String feedid, String mobile, String messages, String jobname, String SHORT , String REPOSITORY) {
        try {
            // read the json file
            if (REPOSITORY.contentEquals("JSON_REPOSITORY_SBI_SINGLE")) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = mobile.split("X");
                mobile = ph[1];
                // System.out.println("This is mobile no from excel sheet "+ph[1]);
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("feedid", feedid);
                jsonObject.put("username", username);
                jsonObject.put("password", password);
                jsonObject.put("jobname", jobname);
                jsonObject.put("mobile", mobile);
                jsonObject.put("messages", messages);
                jsonObject.put("short", SHORT);


                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void SETMSGTEXTANDCONTENTTYPE_V1_FOR_RCS(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String shorting, String JSONTYPE, String REPOSITORY) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V9") || REPOSITORY.contentEquals("JSON_REPOSITORY_V1"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/RCS/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("This is mobile no from excel sheet "+ph[1]);
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                if(!shorting.contentEquals("3"))
                {
                    jsonObject.put("s", shorting);
                }


                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/RCS/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void SETMSGTEXTANDCONTENTTYPE_V1_FOR_WA(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String shorting, String JSONTYPE, String REPOSITORY) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V9") || REPOSITORY.contentEquals("JSON_REPOSITORY_V1"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/WA/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("This is mobile no from excel sheet "+ph[1]);
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                if(!shorting.contentEquals("3"))
                {
                    jsonObject.put("s", shorting);
                }



                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/WA/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_Open_Template_V9(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY, String dtm, String dpi, String tc) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V9") || REPOSITORY.contentEquals("JSON_REPOSITORY_V1"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);

                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }
                if (dtm.contentEquals("BLK")) {
                    jsonObject.put("dtm", "");
                } else {
                    jsonObject.put("dtm", dtm);
                }
                if (dpi.contentEquals("BLK")) {
                    jsonObject.put("dpi", "");
                } else {
                    jsonObject.put("dpi", dpi);
                }
                if (tc.contentEquals("BLK")) {
                    jsonObject.put("tc", "");
                } else {
                    jsonObject.put("tc", tc);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_Open_Template_V4V2(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY, String dtm, String dpi, String tc) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V4") || REPOSITORY.contentEquals("JSON_REPOSITORY_V2"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);

                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);

                jsonObject.put("to", "7838787657");
                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {
                    // System.out.println("jsonarray -->[" +i+"]--> "+ jray.get(i));
                    JSONObject smallobjecttext = (JSONObject) jray.get(i);
                    smallobjecttext.put("msg", msgtext);
                    JSONObject smallobjectFROM = (JSONObject) jray.get(i);
                    smallobjectFROM.put("from", from);

                    JSONObject smallobjectDTM = (JSONObject) jray.get(i);
                    smallobjectDTM.put("dtm", dtm);

                    JSONObject smallobjectDPI = (JSONObject) jray.get(i);
                    smallobjectDPI.put("dpi", dpi);

                    JSONObject smallobjectLANGUAGE = (JSONObject) jray.get(i);
                    //smallobjectLANGUAGE.put("from",from);

                    if (Language.contentEquals("BLK")) {
                        smallobjectLANGUAGE.put("language", "");
                    } else {
                        smallobjectLANGUAGE.put("language", Language);
                    }
                }
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                if (dtm.contentEquals("BLK")) {
                    jsonObject.put("dtm", "");
                } else {
                    jsonObject.put("dtm", dtm);
                }
                if (dpi.contentEquals("BLK")) {
                    jsonObject.put("dpi", "");
                } else {
                    jsonObject.put("dpi", dpi);
                }
                if (tc.contentEquals("BLK")) {
                    jsonObject.put("tc", "");
                } else {
                    jsonObject.put("tc", tc);
                }


                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");
                writer.write(jsonObject.toString());

                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_V9(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V9") || REPOSITORY.contentEquals("JSON_REPOSITORY_V1"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static String SCHEDULE = "";
    public static String EXPIRE = "";
    public static String CURRENT_TIME = "";


    //Below function is used to calculate and return the Live table names
    public static Map Scheduling_calculateandsetlivetablename() {
        String Pushlivetablename = "";
        String DLRlivetablename = "";
        String ShortURLBEEtablename = "";

        Map<String, String> LIVETABLE = new HashMap<>();

        try {


            int Schedulemonth = Integer.parseInt(SCHEDULE.substring(4, 6));
            System.out.println("Month is" + Schedulemonth);

            int Scheduleday = Integer.parseInt(SCHEDULE.substring(6, 8));

            System.out.println("Date is-->" + Scheduleday);

            int ScheduleHour = Integer.parseInt(SCHEDULE.substring(8, 10));

            System.out.println("Hour is-->" + ScheduleHour);
            Pushlivetablename = "PUSH_RECEIVER_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            DLRlivetablename = "PUSH_DLR_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            ShortURLBEEtablename = "shorturl_bee_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            System.out.println(Pushlivetablename);
            System.out.println(DLRlivetablename);
            System.out.println(ShortURLBEEtablename);

            LIVETABLE.put("PUSHTABLENAME", Pushlivetablename);
            LIVETABLE.put("DLRTABLENAME", DLRlivetablename);
            LIVETABLE.put("SHORTSTAGE_BEE_TABLE", ShortURLBEEtablename);

        } catch (Exception e) {
            System.out.println("This is exception caught while Table name calculation -->" + e);
        }
        return LIVETABLE;
    }


    public static Map Normal_calculateandsetlivetablename() {
        String Pushlivetablename = "";
        String DLRlivetablename = "";
        String ShortURLBEEtablename = "";
        String RCSRECIEVERTABLENAME = "";
        String RCSDLRTABLENAME = "";
        String WARECIEVERTABLENAME = "";
        String WADLRTABLENAME = "";

        Map<String, String> LIVETABLE = new HashMap<>();

        try {


            int Schedulemonth = Integer.parseInt(CURRENT_TIME.substring(4, 6));
            System.out.println("Month is" + Schedulemonth);

            int Scheduleday = Integer.parseInt(CURRENT_TIME.substring(6, 8));

            System.out.println("Date is-->" + Scheduleday);

            int ScheduleHour = Integer.parseInt(CURRENT_TIME.substring(8, 10));

            System.out.println("Hour is-->" + ScheduleHour);
            Pushlivetablename = "PUSH_RECEIVER_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            DLRlivetablename = "PUSH_DLR_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            ShortURLBEEtablename = "shorturl_bee_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            RCSRECIEVERTABLENAME = "RCS_RECEIVER_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            RCSDLRTABLENAME = "RCS_DLR_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            WARECIEVERTABLENAME = "WHATSAPP_RECEIVER_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            WADLRTABLENAME = "WHATSAPP_DLR_" + Scheduleday + "_" + Schedulemonth + "_" + ScheduleHour;
            System.out.println(Pushlivetablename);
            System.out.println(DLRlivetablename);
            System.out.println(ShortURLBEEtablename);

            System.out.println(RCSRECIEVERTABLENAME);
            System.out.println(RCSDLRTABLENAME);
            System.out.println(WARECIEVERTABLENAME);
            System.out.println(WADLRTABLENAME);

            LIVETABLE.put("PUSHTABLENAME", Pushlivetablename);
            LIVETABLE.put("DLRTABLENAME", DLRlivetablename);
            LIVETABLE.put("SHORTSTAGE_BEE_TABLE", ShortURLBEEtablename);

            LIVETABLE.put("RCSRECIEVERTABLENAME", RCSRECIEVERTABLENAME);
            LIVETABLE.put("RCSDLRTABLENAME", RCSDLRTABLENAME);
            LIVETABLE.put("WARECIEVERTABLENAME", WARECIEVERTABLENAME);
            LIVETABLE.put("WADLRTABLENAME", WADLRTABLENAME);


        } catch (Exception e) {
            System.out.println("This is exception caught while Table name calculation -->" + e);
        }
        return LIVETABLE;
    }

    public static void setcurrenttime() {
        try {
            LocalDateTime S = LocalDateTime.now();
            DateTimeFormatter PP = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
            CURRENT_TIME = S.format(PP);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void SETSCHEDULINGPARAMETERS(int Duration, String JSONTYPE, String REPOSITORY) {

        try {
            LocalDateTime S = LocalDateTime.now().plusMinutes(Duration);
            DateTimeFormatter PP = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
            SCHEDULE = S.format(PP);

            LocalDateTime E = LocalDateTime.now().plusMinutes(Duration + 5);

            EXPIRE = E.format(PP);

            System.out.println(" Scheduled time is  " + SCHEDULE);
            System.out.println(" Expired time is  " + EXPIRE);


        } catch (Exception e) {
            System.out.println(e);
        }


        try {
            // read the json file
            if (JSONTYPE.contentEquals("text")) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/SCH.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);


                jsonObject.put("schedule", SCHEDULE);
                jsonObject.put("expire", EXPIRE);
                System.out.println("after update " + jsonObject);
                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/SCH.json");
                writer.write(jsonObject.toString());


                reader.close();
                writer.close();
            } else if (JSONTYPE.contentEquals("Messages")) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/SCH.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);


                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {

                    JSONObject smallobject = (JSONObject) jray.get(i);
                    smallobject.put("schedule", SCHEDULE);
                    smallobject.put("expire", EXPIRE);
                }
                System.out.println("after update " + jsonObject);

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/SCH.json");
                writer.write(jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_Open_Template_V8(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY, String dtm, String dpi, String tc) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V8") || REPOSITORY.contentEquals("JSON_REPOSITORY_V1"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("dtm", dtm);
                jsonObject.put("dpi", dpi);
                jsonObject.put("tc", tc);
                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }
                if (dtm.contentEquals("BLK")) {
                    jsonObject.put("dtm", "");
                } else {
                    jsonObject.put("dtm", dtm);
                }
                if (dpi.contentEquals("BLK")) {
                    jsonObject.put("dpi", "");
                } else {
                    jsonObject.put("dpi", dpi);
                }
                if (tc.contentEquals("BLK")) {
                    jsonObject.put("tc", "");
                } else {
                    jsonObject.put("tc", tc);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_V8(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V8") || REPOSITORY.contentEquals("JSON_REPOSITORY_V1"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer
    public static void SETMSGTEXTANDCONTENTTYPE_V3(String functionaname, String userid, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V3") || REPOSITORY.contentEquals("JSON_REPOSITORY_V6"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                String ph[] = to.split("X");
                to = ph[1];
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {
                    // System.out.println("jsonarray -->[" +i+"]--> "+ jray.get(i));
                    JSONObject smallobjecttext = (JSONObject) jray.get(i);
                    smallobjecttext.put("msg", msgtext);
                    JSONObject smallobjectFROM = (JSONObject) jray.get(i);
                    smallobjectFROM.put("from", from);
                    JSONObject smallobjectto = (JSONObject) jray.get(i);
                    smallobjectFROM.put("to", to);

                    JSONObject smallobjectLANGUAGE = (JSONObject) jray.get(i);

                    if (Language.contentEquals("BLK")) {
                        smallobjectLANGUAGE.put("language", "");
                    } else {
                        smallobjectLANGUAGE.put("language", Language);
                    }
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_Open_Template_V3(String functionaname, String userid, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY, String dtm, String dpi, String tc) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V3") || REPOSITORY.contentEquals("JSON_REPOSITORY_V6"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {
                    // System.out.println("jsonarray -->[" +i+"]--> "+ jray.get(i));
                    JSONObject smallobjecttext = (JSONObject) jray.get(i);
                    smallobjecttext.put("msg", msgtext);
                    JSONObject smallobjectFROM = (JSONObject) jray.get(i);
                    smallobjectFROM.put("from", from);
                    JSONObject smallobjectto = (JSONObject) jray.get(i);
                    smallobjectFROM.put("to", to);

                    JSONObject smallobjectLANGUAGE = (JSONObject) jray.get(i);
                    JSONObject smallobjectdpi = (JSONObject) jray.get(i);
                    JSONObject smallobjectdtm = (JSONObject) jray.get(i);
                    JSONObject smallobjecttc = (JSONObject) jray.get(i);
                    if (Language.contentEquals("BLK")) {
                        smallobjectLANGUAGE.put("language", "");
                    } else {
                        smallobjectLANGUAGE.put("language", Language);
                    }
                    if (dtm.contentEquals("BLK")) {
                        smallobjectdtm.put("dtm", "");
                    } else {
                        smallobjectdtm.put("dtm", dtm);
                    }
                    if (dpi.contentEquals("BLK")) {
                        smallobjectdpi.put("dpi", "");
                    } else {
                        smallobjectdpi.put("dpi", dpi);
                    }
                    if (tc.contentEquals("BLK")) {
                        smallobjecttc.put("tc", "");
                    } else {
                        smallobjecttc.put("tc", tc);
                    }
                }
                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_V5V7(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY) {


        try {
            // read the json file
            if (JSONTYPE.contentEquals("msg") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V5") || REPOSITORY.contentEquals("JSON_REPOSITORY_V7"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);

                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                double random = Math.random();
                double x = random * 1000000;
                int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
                String ph[] = to.split("X");
                to = ph[1];
//MSGID ADDED DYNAMICALLY

                jsonObject.put("msgid", MSGID);
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("pass", pass);

                jsonObject.put("msg", msgtext);
                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {
                    // System.out.println("jsonarray -->[" +i+"]--> "+ jray.get(i));
                    JSONObject smallobjectto = (JSONObject) jray.get(i);
                    smallobjectto.put("to", to);
                    JSONObject smallobjectFROM = (JSONObject) jray.get(i);
                    smallobjectFROM.put("from", from);

                    JSONObject smallobjectLANGUAGE = (JSONObject) jray.get(i);
                    smallobjectLANGUAGE.put("from", from);

                    if (Language.contentEquals("BLK")) {
                        smallobjectLANGUAGE.put("language", "");
                    } else {
                        smallobjectLANGUAGE.put("language", Language);
                    }
                }
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);


                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Below functions are used to dynamically construct the JSONs on based of data supplied in excel sheet from data provided in the test layer

    public static void SETMSGTEXTANDCONTENTTYPE_Open_Template_V5V7(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY, String dtm, String dpi, String tc) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("msg") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V5") || REPOSITORY.contentEquals("JSON_REPOSITORY_V7"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("pass", pass);
                jsonObject.put("msg", msgtext);

                jsonObject.put("to", to);
                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {
                    // System.out.println("jsonarray -->[" +i+"]--> "+ jray.get(i));
                    JSONObject smallobjecttext = (JSONObject) jray.get(i);
                    smallobjecttext.put("to", "7838787657");
                    JSONObject smallobjectFROM = (JSONObject) jray.get(i);
                    smallobjectFROM.put("from", from);

                    JSONObject smallobjectLANGUAGE = (JSONObject) jray.get(i);
                    smallobjectLANGUAGE.put("from", from);

                    if (Language.contentEquals("BLK")) {
                        smallobjectLANGUAGE.put("language", "");
                    } else {
                        smallobjectLANGUAGE.put("language", Language);
                    }
                }
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                if (dtm.contentEquals("BLK")) {
                    jsonObject.put("dtm", "");
                } else {
                    jsonObject.put("dtm", dtm);
                }
                if (dpi.contentEquals("BLK")) {
                    jsonObject.put("dpi", "");
                } else {
                    jsonObject.put("dpi", dpi);
                }
                if (tc.contentEquals("BLK")) {
                    jsonObject.put("tc", "");
                } else {
                    jsonObject.put("tc", tc);
                }


                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");
                writer.write(jsonObject.toString());

                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void SETMSGTEXTANDCONTENTTYPE_Open_Template_V12(String functionaname, String userid, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY, String dtm, String dpi, String tc) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V12"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("dtm", dtm);
                jsonObject.put("dpi", dpi);
                jsonObject.put("tc", tc);
                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }
                if (dtm.contentEquals("BLK")) {
                    jsonObject.put("dtm", "");
                } else {
                    jsonObject.put("dtm", dtm);
                }
                if (dpi.contentEquals("BLK")) {
                    jsonObject.put("dpi", "");
                } else {
                    jsonObject.put("dpi", dpi);
                }
                if (tc.contentEquals("BLK")) {
                    jsonObject.put("tc", "");
                } else {
                    jsonObject.put("tc", tc);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/OpenTemplate.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void SETMSGTEXTANDCONTENTTYPE_V12(String functionaname, String userid, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String REPOSITORY) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V12"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[] = to.split("X");
                to = ph[1];
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
//                jsonObject.put("from", from);
//                jsonObject.put("to", "7838787657");
//                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("auth", APPID);
                jsonObject.put("subauth", APPID);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {
                    // System.out.println("jsonarray -->[" +i+"]--> "+ jray.get(i));
                    JSONObject smallobjecttext = (JSONObject) jray.get(i);
                    smallobjecttext.put("msg", msgtext);
                    JSONObject smallobjectFROM = (JSONObject) jray.get(i);
                    smallobjectFROM.put("from", from);

                    JSONObject smallobjectTO = (JSONObject) jray.get(i);
                    smallobjectTO.put("to", to);

                    JSONObject smallobjectLANGUAGE = (JSONObject) jray.get(i);


                    if (Language.contentEquals("BLK")) {
                        smallobjectLANGUAGE.put("language", "");
                    } else {
                        smallobjectLANGUAGE.put("language", Language);
                    }
                }
                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void writeDataLineToCSV(String responseid) {
        // first create file object for file placed at location
        // specified by filepath
        //
        File file = new File(System.getProperty("user.dir") + "/src/main/resources/Util/ResponseID.csv");
        try {
            // create FileWriter object with file as parameter
            FileWriter outputfile = new FileWriter(file, true);

            // create CSVWriter object filewriter object as parameter
            CSVWriter writer = new CSVWriter(outputfile);

            // adding header to csv
            // String[] header = { "ResponseID"};
            // writer.writeNext(header);

            // add data to csv
            String[] data1 = {responseid};
            writer.writeNext(data1);

            // closing writer connection
            writer.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    //test


    public static void handleMessageType1(String messageType, String responseid) throws Exception {
        try {
        Properties prop1;
        prop1 = new Properties();
       
            
            FileInputStream ip = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources/coreconfig.properties");
            prop1.load(ip);


            switch (messageType) {
                case "SMS":
                    System.out.println("Handling SMS message...");
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check SMS Router/b>");

                    // Add SMS-specific logic here
                    boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, prop1.getProperty("Username207"), prop1.getProperty("Password207"), prop1.getProperty("hostname207"), false, "MSG", prop1.getProperty("commonloglocation207"), prop1.getProperty("rcvrlogfileName"));
                    if (SMSCRESULT) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>Request reached at SMS Router</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>Request did not reach at SMS Router</b>");

                    }

                    break;

                case "RCS":
                    System.out.println("Handling RCS message...");
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check RCS Router/b>");

                    // Add WhatsApp-specific logic here
                    boolean LISTNERPROCESSORSERVERRESULT_RCS = LinuxLogReader.checkComponentLog(responseid, prop1.getProperty("Username85"), prop1.getProperty("Password85"), prop1.getProperty("hostname85"), false, "dummy", prop1.getProperty("rcsloglocation"), prop1.getProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT_RCS) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>Request reached at RCS Router</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>Request did not reach at RCS Router</b>");

                    }
                    break;
                case "WA":
                    System.out.println("Handling WA message...");

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check WA Router/b>");

                    // Add RCS-specific logic here

                    boolean LISTNERPROCESSORSERVERRESULT_WA = LinuxLogReader.checkComponentLog(responseid, prop1.getProperty("Username207WA"), prop1.getProperty("Password207WA"), prop1.getProperty("hostname207WA"), false, "dummy", prop1.getProperty("commonloglocation207WA"), prop1.getProperty("WArcvrlogfileName"));
                    if (LISTNERPROCESSORSERVERRESULT_WA) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>Request reached at WA Router</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>Request did not reach at WA Router</b>");

                    }
                    break;
                default:
                    //System.out.println("No priority has been set : ");

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>NO PRIORITY FOUND/b>");

                    break;
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //RAHUL ADDITIONAL FUNCTIONS FOR WA AND RCS FOR V4 AND V2
    public static void SETMSGTEXTANDCONTENTTYPE_V4V2_FOR_RCS(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String JSONTYPE, String shorting,String REPOSITORY) {
        try {
            String ph[]=to.split("X");
            to=ph[1];
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V4") || REPOSITORY.contentEquals("JSON_REPOSITORY_V2"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/RCS/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);

                // jsonObject.put("to", "7838787657");
                JSONArray jray = (JSONArray) jsonObject.get("messages");
                for (int i = 0; i < jray.size(); i++) {
                    // System.out.println("jsonarray -->[" +i+"]--> "+ jray.get(i));
                    JSONObject smallobjecttext = (JSONObject) jray.get(i);
                    smallobjecttext.put("msg", msgtext);
                    JSONObject smallobjectFROM = (JSONObject) jray.get(i);
                    smallobjectFROM.put("from", from);

                    JSONObject smallobjectTO = (JSONObject) jray.get(i);

                    smallobjectTO.put("to", to);

                    JSONObject smallobjectLANGUAGE = (JSONObject) jray.get(i);


                    if (Language.contentEquals("BLK")) {
                        smallobjectLANGUAGE.put("language", "");
                    } else {
                        smallobjectLANGUAGE.put("language", Language);
                    }
                }
                double random = Math.random();

                double x = random * 1000000;

                int MSGID = (int) x + 100; //Add 1 to change the range to 1 - 100 instead of 0 - 99
//MSGID ADDED DYNAMICALLY
                jsonObject.put("msgid", MSGID);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                jsonObject.put("s", shorting);
                // jsonObject.put("auth", APPID);
                //jsonObject.put("subauth",APPID);


                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/RCS/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    static void SETMSGTEXTANDCONTENTTYPE_V4V2_FOR_WA(String functionaname, String userid, String pass, String APPID, String from, String to, String msgtext, String alert, String selfID, String Intflag, String contenttype, String Language, String shorting ,String JSONTYPE, String REPOSITORY) {
        try {
            // read the json file
            if (JSONTYPE.contentEquals("text") && (REPOSITORY.contentEquals("JSON_REPOSITORY_V4") || REPOSITORY.contentEquals("JSON_REPOSITORY_V2"))) {
                FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/WA/ALLMESSAGE.json");
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
                String ph[]=to.split("X");
                to=ph[1];
                // System.out.println("This is mobile no from excel sheet "+ph[1]);
                // System.out.println("Before update encrypted JSON "+ jsonObject.toString());
                //System.out.println("Before adding " +jsonObject.get("encryptedData"));
                jsonObject.put("appid", APPID);
                jsonObject.put("userId", userid);
                jsonObject.put("pass", pass);
                jsonObject.put("from", from);
                jsonObject.put("to", to);
                jsonObject.put("text", msgtext);
                jsonObject.put("alert", alert);
                jsonObject.put("selfid", selfID);
                jsonObject.put("intflag", Intflag);
                jsonObject.put("contenttype", contenttype);
                jsonObject.put("subappid", APPID);
                jsonObject.put("s", shorting);

                if (Language.contentEquals("BLK")) {
                    jsonObject.put("language", "");
                } else {
                    jsonObject.put("language", Language);
                }

                FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/WA/ALLMESSAGE.json");
                writer.write(jsonObject.toString());
                //  System.out.println("After adding " +jsonObject.get("encryptedData"));
                // System.out.println("after update encrypted JSON "+ jsonObject.toString());
                reader.close();
                writer.close();
            } else {

                Assert.assertTrue(false, "Something wrong");
            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void SETMSGTEXTANDCONTENTTYPE_SBIBULK(String functionname, String username, String password, String feedid, String mobile, String messages, String jobname, String SHORT, String REPOSITORY) {
        try {
            FileReader reader = new FileReader("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
            
            jsonObject.put("username", username);
            jsonObject.put("password", password);
            jsonObject.put("feedid", feedid);
            jsonObject.put("jobname", jobname);
            jsonObject.put("short", SHORT);
            
            JSONArray dataArray = (JSONArray) jsonObject.get("Data");
            if (dataArray != null) {
                for (int i = 0; i < dataArray.size(); i++) {
                    JSONObject dataItem = (JSONObject) dataArray.get(i);
                    dataItem.put("mobile", mobile);
                    dataItem.put("messages", messages);
                }
            }
            
            FileWriter writer = new FileWriter("src/main/resources/Util/" + REPOSITORY + "/ALLMESSAGE.json");
            writer.write(jsonObject.toString());
            reader.close();
            writer.close();
            
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ParseException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static String extractValue(String log, String key) {

        try {
            Pattern pattern = Pattern.compile(key + "='([^']+)'");
            Matcher matcher = pattern.matcher(log);

            if (matcher.find()) {
                return matcher.group(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static String extractOrchField(String logData, String fieldName) {
        if (logData == null || logData.isEmpty()) return null;
        try {
            java.util.regex.Pattern pattern = java.util.regex.Pattern
                    .compile("\"" + fieldName + "\"\\s*:\\s*\"([^\"]+)\"");
            java.util.regex.Matcher matcher = pattern.matcher(logData);
            if (matcher.find()) {
                return matcher.group(1).trim();
            }
        } catch (Exception e) {
            System.out.println("extractOrchField error: " + e.getMessage());
        }
        return null;
    }

    public static String extractFromLog(String line, String key) {
        if (key.equals("mx")) {
            int start = line.indexOf("\"mx\":\"") + 6;
            int end = line.indexOf("\"", start);
            if (start > 5 && end > start) {
                return line.substring(start, end);
            }
        } else if (key.equals("SHORTURL_")) {
            int startIdx = line.indexOf("SHORTURL_");
            int endIdx = line.indexOf("}", startIdx);
            if (startIdx != -1 && endIdx != -1) {
                return line.substring(startIdx, endIdx + 1);
            } else {
                int spaceIdx = line.indexOf(" ", startIdx);
                return (spaceIdx != -1) ? line.substring(startIdx, spaceIdx) : line.substring(startIdx);
            }
        } else if (key.equals("sd")) {
            int start = line.indexOf("\"sd\":\"") + 6;
            int end = line.indexOf("\"", start);
            if (start > 5 && end > start) {
                return line.substring(start, end);
            }

        }

        return "";
    }
}

