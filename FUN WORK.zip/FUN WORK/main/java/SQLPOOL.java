import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class SQLPOOL {
    static Connection con = null;
    static Connection Recievercon = null;
    static Connection DLRcon = null;
    static TestBase ob = new TestBase();

    //test
    public static boolean CheckMysqlSCHEDULING_1(String ResponseID) throws SQLException {
        boolean result = false;

        System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                    ob.GetProperty("Scheduling_DB_URL"), ob.GetProperty("Scheduling_DB_USER"), ob.GetProperty("Scheduling_DB_PASS"));

            Statement stmt = con.createStatement();

            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            Thread.sleep(5000);
            ResultSet rs = stmt.executeQuery("select * from SCHEDULING_1  where responseId='" + FinalresponseID + "' limit 0,1");
            Thread.sleep(1000);
            System.out.println("temp" + rs.getFetchSize());
            while (rs.next()) {
                System.out.println(rs.getString(1) + "  " + rs.getString(10) + " " + rs.getString(9));
                //System.out.println( rs.getString(1));
                String DBResponseID = rs.getString(10);
                if (DBResponseID.contentEquals(FinalresponseID)) {
                    System.out.println("Request is successfully scheduled ");
                    result = true;

                }


            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {
            con.close();

        }
        return result;
    }
//Below function is used to check if data is present in the Live reciever table or not


    public static boolean CheckMysqlPUSHRECIEVERTABLE(String ResponseID, String Pushreciever_liveTablename) throws SQLException {
        boolean recieverresult = false;
        Statement pushstmt = null;
        ResultSet rs = null;
        System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));

            pushstmt = Recievercon.createStatement();


            System.out.println("Reciever Table going to chekc is " + Pushreciever_liveTablename);

            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            System.out.println("Going to execute below Query..");
            System.out.println("select * from " + Pushreciever_liveTablename + "  where responseId='" + FinalresponseID + "'");
            //Thread.sleep(5000);
            rs = pushstmt.executeQuery("select * from " + Pushreciever_liveTablename + "  where responseId='" + FinalresponseID + "' limit 0,1");
            Thread.sleep(1000);
            System.out.println("temp" + rs.getStatement().toString());
            // rs.beforeFirst();
            while (rs.next()) {
                System.out.println("push table has data");
                System.out.println(rs.getString(4) + "  " + rs.getString(29));

                String DBResponseID = rs.getString(4);
                //String RecieverStatus = rs.getString(29);
                System.out.println("IMPORTANT_DLR_INFO:DB responseid is= " + DBResponseID + " ActualResponseID is = " + FinalresponseID);

                if ((DBResponseID.contentEquals(FinalresponseID))) {
                    System.out.println("Scheduling Request is successfully recieved and processed by Reciever");
                    recieverresult = true;

                }


            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            pushstmt.close();
            rs.close();

        }
        return recieverresult;
    }

    //Below function is used to check if data is present in the Live DLR table or not
    public static boolean CheckMysqlDLRTABLE(String ResponseID, String DLR_liveTablename) throws SQLException {
        boolean DLRresult = false;
        Statement stmt = null;
        ResultSet rs = null;
        System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            DLRcon = DriverManager.getConnection(
                    ob.GetProperty("PUSHDLR_DB_URL"), ob.GetProperty("PUSHDLR_DB_USER"), ob.GetProperty("PUSHDLR_DB_PASS"));

            stmt = DLRcon.createStatement();

            System.out.println("Reciever Table going to chekc is " + DLR_liveTablename);
            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            //Thread.sleep(5000);
            rs = stmt.executeQuery("select * from " + DLR_liveTablename + "  where responseId='" + FinalresponseID + "'");
            //System.out.println("temp"+rs.getFetchSize());
            Thread.sleep(1000);
            while (rs.next()) {
                System.out.println("DLR table response " + rs.getString(4));

                String DBResponseID = rs.getString(4);
                // String RecieverStatus = rs.getString(29);
                System.out.println("IMPORTANT_DLR_INFO:DB responseid is= " + DBResponseID + " ActualResponseID is = " + FinalresponseID);
                if ((DBResponseID.contentEquals(FinalresponseID))) {
                   // System.out.println("Scheduling Request is successfully recieved and processed by DLR component");
                    DLRresult = true;

                }


            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {
            DLRcon.close();
            stmt.close();
            rs.close();

        }
        return DLRresult;
    }
//Below function is internally being used by checkshortstageDB function to fetch the joinid from live table

    public static String GETMSGID_FROM_PUSHRECEIVERDB(String ResponseID, String Pushreciever_liveTablename) throws SQLException {
        String MSGID = "";
        Statement pushstmt = null;
        ResultSet rs = null;
        System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


            pushstmt = Recievercon.createStatement();


            System.out.println("Reciever Table going to chekc is " + Pushreciever_liveTablename);

            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            System.out.println("Going to execute below Query..");
            System.out.println("select joinid from " + Pushreciever_liveTablename + "  where responseId='" + FinalresponseID + "'");
            Thread.sleep(10000);
            rs = pushstmt.executeQuery("select joinid from " + Pushreciever_liveTablename + "  where responseId='" + FinalresponseID + "' limit 0,1");
            // Thread.sleep(15000);
            System.out.println("Going to check data (MSGID) from pushtable");
            // rs.beforeFirst();

            while (rs.next()) {
                System.out.println("Request is successfully recieved and processed by Reciever");


                String MessageID = rs.getString(1);
                MSGID = MessageID;

            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            pushstmt.close();
            rs.close();

        }
        return MSGID;
    }

    public static boolean checkshortstageDB(String ResponseID, String Pushreciever_liveTablename, String Shortstage_liveTablename) throws SQLException {
        boolean result = false;
        Statement shortstagestmt = null;
        ResultSet rs = null;
        try {
            String MessageID = GETMSGID_FROM_PUSHRECEIVERDB(ResponseID, Pushreciever_liveTablename);
            System.out.println("The messageID is = " + MessageID);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(ob.GetProperty("SHORTSTAGE_DB_URL"), ob.GetProperty("SHORTSTAGE_DB_USER"), ob.GetProperty("SHORTSTAGE_DB_PASS"));

            shortstagestmt = Recievercon.createStatement();

            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            System.out.println("Shortstageuery--->select * from " + Shortstage_liveTablename + "  where joinid=" + MessageID);
            rs = shortstagestmt.executeQuery("select * from " + Shortstage_liveTablename + "  where joinid='" + MessageID + "' limit 0,1");
            Thread.sleep(1000);


            while (rs.next()) {
                System.out.println("shortstage table has data");
                System.out.println(rs.getString(13));

                result = true;


            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            shortstagestmt.close();
            rs.close();

        }
        return result;
    }

//Below function is used to get the MAP of misdata for responseid from current hour table and if data is not found
// in current hour after various retry then it goes to check in previous hour table.


    public static Map GETMISDATAFROMRCSRECIEVERTABLE(int waittime, String ResponseID, String PushRCSreciever_liveTablename) throws SQLException {

        Map<String, String> RECIEVERTABLEDATA = new HashMap<>();
        for (int i = 0; i < 3; i++) {

            Statement pushstmt = null;
            ResultSet rs = null;
            //System.out.println("The recieved Response ID from API =" + ResponseID.length());
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Recievercon = DriverManager.getConnection(
                        ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));

                pushstmt = Recievercon.createStatement();
                System.out.println("Reciever Table going to chekc is " + PushRCSreciever_liveTablename);
                String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
                System.out.println("Going to execute below Query..");
                System.out.println("select * from " + PushRCSreciever_liveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
                Thread.sleep(1000);
                rs = pushstmt.executeQuery("select * from " + PushRCSreciever_liveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
                Thread.sleep(1000);
                System.out.println("temp" + rs.getStatement().toString());
                // rs.beforeFirst();
                while (rs.next()) {
                    System.out.println("push table has data");
                    // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                    //String DBResponseID = rs.getString(4);

                    RECIEVERTABLEDATA.put("insert_datetime", rs.getString(1));
                    RECIEVERTABLEDATA.put("joinid", rs.getString(2));
                    RECIEVERTABLEDATA.put("messageid", rs.getString(3));
                    RECIEVERTABLEDATA.put("rcsMessageId", rs.getString(4));
                    RECIEVERTABLEDATA.put("responseid", rs.getString(5));
                    RECIEVERTABLEDATA.put("enterpriseid", rs.getString(6));
                    RECIEVERTABLEDATA.put("enterprisename", rs.getString(7));
                    RECIEVERTABLEDATA.put("subenterprisename", rs.getString(9));
                    RECIEVERTABLEDATA.put("author", rs.getString(10));
                    RECIEVERTABLEDATA.put("subauthor", rs.getString(11));
                    RECIEVERTABLEDATA.put("broadcastname", rs.getString(12));
                    RECIEVERTABLEDATA.put("receivedsender", rs.getString(15));
                    RECIEVERTABLEDATA.put("receivedsdate", rs.getString(16));
                    RECIEVERTABLEDATA.put("actualsender", rs.getString(17));
                    RECIEVERTABLEDATA.put("contenttype", rs.getString(18));
                    RECIEVERTABLEDATA.put("deliveryflag", rs.getString(19));
                    RECIEVERTABLEDATA.put("requestreceivedtime", rs.getString(20));
                    RECIEVERTABLEDATA.put("submittime", rs.getString(21));
                    RECIEVERTABLEDATA.put("messagetext", rs.getString(24));
                    RECIEVERTABLEDATA.put("bearer", rs.getString(25));
                    RECIEVERTABLEDATA.put("smscname", rs.getString(27));
                    RECIEVERTABLEDATA.put("smscount", rs.getString(28));
                    RECIEVERTABLEDATA.put("status", rs.getString(29));
                    RECIEVERTABLEDATA.put("statusdesc", rs.getString(30));
                    RECIEVERTABLEDATA.put("operatorid", rs.getString(33));
                    RECIEVERTABLEDATA.put("circleid", rs.getString(34));
                    RECIEVERTABLEDATA.put("operatorname", rs.getString(35));
                    RECIEVERTABLEDATA.put("dndflag", rs.getString(37));
                    RECIEVERTABLEDATA.put("countrycode", rs.getString(38));
                    RECIEVERTABLEDATA.put("smscredits", rs.getString(40));
                    RECIEVERTABLEDATA.put("templateid", rs.getString(44));
                    RECIEVERTABLEDATA.put("statusdescenum", rs.getString(47));
                    RECIEVERTABLEDATA.put("acc_id", rs.getString(57));
                    RECIEVERTABLEDATA.put("original_receivedsender", rs.getString(60));
                    RECIEVERTABLEDATA.put("original_actualsender", rs.getString(61));
                    RECIEVERTABLEDATA.put("dlt_tempid", rs.getString(62));
                    RECIEVERTABLEDATA.put("dlt_peid", rs.getString(65));
                    RECIEVERTABLEDATA.put("tempid_category", rs.getString(66));
                    RECIEVERTABLEDATA.put("originalmessage", rs.getString(68));
                    RECIEVERTABLEDATA.put("soip_flag", rs.getString(69));
                    RECIEVERTABLEDATA.put("vsms_flag", rs.getString(70));
                    RECIEVERTABLEDATA.put("wa_flag", rs.getString(71));
                    RECIEVERTABLEDATA.put("channel_sms", rs.getString(72));
                    RECIEVERTABLEDATA.put("channel_wa", rs.getString(73));
                    RECIEVERTABLEDATA.put("channel_rcs", rs.getString(74));
                    RECIEVERTABLEDATA.put("ruletype", rs.getString(75));
                    RECIEVERTABLEDATA.put("rcs_templatename", rs.getString(76));

                    RECIEVERTABLEDATA.put("nho_code", rs.getString("nho_code"));
                }


            } catch (Exception e) {
                System.out.println(e);
            } finally {

                Recievercon.close();
                pushstmt.close();
                rs.close();

            }

            if (!RECIEVERTABLEDATA.isEmpty()) {
                break;
            }
            try {

                System.out.println("Internal Retry from SQL function");
                Thread.sleep(waittime);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
// Below function is created to check the data in previous hour table in case the table data map is still blank which may be due to server time gap issue.

        if (RECIEVERTABLEDATA.isEmpty()) {
            System.out.println("Now system is going to check the data in previous hour table ");
            //String temp="PUSH_RECEIVER_12_1_13";
            String splt[] = PushRCSreciever_liveTablename.split("_");
            //System.out.println("Current hour "+splt[4]);

            int previoushour = Integer.parseInt(splt[4]) - 1;

            // System.out.println("Previous hour "+previoushour);
            String PushRCSreciever_PreviousHourliveTablename = splt[0] + "_" + splt[1] + "_" + splt[2] + "_" + splt[3] + "_" + previoushour;
            System.out.println("Previous hour table name " + PushRCSreciever_PreviousHourliveTablename);
            RECIEVERTABLEDATA = GETMISDATAFROMRCSRECIEVERTABLE_PREVIOUSHOUR(ResponseID, PushRCSreciever_PreviousHourliveTablename);
        }

        if (RECIEVERTABLEDATA.isEmpty()) {
            System.out.println("Now system is going to check the data in next hour table ");
            //String temp="PUSH_RECEIVER_12_1_13";
            String splt[] = PushRCSreciever_liveTablename.split("_");
            //System.out.println("Current hour "+splt[4]);

            int nexthour = Integer.parseInt(splt[4]) + 1;

            // System.out.println("Previous hour "+previoushour);
            String PushRCSreciever_PreviousHourliveTablename = splt[0] + "_" + splt[1] + "_" + splt[2] + "_" + splt[3] + "_" + nexthour;
            System.out.println("Previous hour table name " + PushRCSreciever_PreviousHourliveTablename);
            RECIEVERTABLEDATA = GETMISDATAFROMRCSRECIEVERTABLE_PREVIOUSHOUR(ResponseID, PushRCSreciever_PreviousHourliveTablename);
        }

        //


        return RECIEVERTABLEDATA;
    }


    public static Map GETMISDATAFROMRCSRECIEVERTABLE_PREVIOUSHOUR(String ResponseID, String PushRCSreciever_PREVIOUSHOURliveTablename) throws SQLException {

        Map<String, String> RCS_RECIEVERTABLEDATA_PREVIOUSHOUR = new HashMap<>();


        Statement pushstmt = null;
        ResultSet rs = null;
        //System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


            pushstmt = Recievercon.createStatement();
            System.out.println("Reciever Table going to chekc is " + PushRCSreciever_PREVIOUSHOURliveTablename);
            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            System.out.println("Going to execute below Query..");
            System.out.println("select * from " + PushRCSreciever_PREVIOUSHOURliveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
            Thread.sleep(1000);
            rs = pushstmt.executeQuery("select * from " + PushRCSreciever_PREVIOUSHOURliveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
            Thread.sleep(1000);
            System.out.println("temp" + rs.getStatement().toString());
            // rs.beforeFirst();
            while (rs.next()) {
                System.out.println("push table has data");
                // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                //String DBResponseID = rs.getString(4);

                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("insert_datetime", rs.getString(1));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("joinid", rs.getString(2));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("messageid", rs.getString(3));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("rcsMessageId", rs.getString(4));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("responseid", rs.getString(5));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("enterpriseid", rs.getString(6));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("enterprisename", rs.getString(7));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("subenterprisename", rs.getString(9));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("author", rs.getString(10));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("subauthor", rs.getString(11));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("broadcastname", rs.getString(12));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("receivedsender", rs.getString(15));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("receivedsdate", rs.getString(16));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("actualsender", rs.getString(17));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("contenttype", rs.getString(18));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("deliveryflag", rs.getString(19));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("requestreceivedtime", rs.getString(20));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("submittime", rs.getString(21));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("messagetext", rs.getString(24));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("bearer", rs.getString(25));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("smscname", rs.getString(27));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("smscount", rs.getString(28));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("status", rs.getString(29));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("statusdesc", rs.getString(30));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("operatorid", rs.getString(33));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("circleid", rs.getString(34));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("operatorname", rs.getString(35));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("dndflag", rs.getString(37));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("countrycode", rs.getString(38));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("smscredits", rs.getString(40));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("templateid", rs.getString(44));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("statusdescenum", rs.getString(47));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("acc_id", rs.getString(57));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("original_receivedsender", rs.getString(60));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("original_actualsender", rs.getString(61));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("dlt_tempid", rs.getString(62));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("dlt_peid", rs.getString(65));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("tempid_category", rs.getString(66));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("originalmessage", rs.getString(68));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("soip_flag", rs.getString(69));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("vsms_flag", rs.getString(70));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("wa_flag", rs.getString(71));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("channel_sms", rs.getString(72));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("channel_wa", rs.getString(73));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("channel_rcs", rs.getString(74));
                RCS_RECIEVERTABLEDATA_PREVIOUSHOUR.put("nho_code", rs.getString("nho_code"));

            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            pushstmt.close();
            rs.close();

        }


        return RCS_RECIEVERTABLEDATA_PREVIOUSHOUR;


    }




    public static Map GETMISDATAFROMRECIEVERTABLE(int waittime, String ResponseID, String Pushreciever_liveTablename) throws SQLException {

        Map<String, String> RECIEVERTABLEDATA = new HashMap<>();
        for (int i = 0; i < 3; i++) {

            Statement pushstmt = null;
            ResultSet rs = null;
            //System.out.println("The recieved Response ID from API =" + ResponseID.length());
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Recievercon = DriverManager.getConnection(
                        ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


                pushstmt = Recievercon.createStatement();
                System.out.println("Reciever Table going to chekc is " + Pushreciever_liveTablename);
                String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
                System.out.println("Going to execute below Query..");
                System.out.println("select * from " + Pushreciever_liveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
                Thread.sleep(1000);
                rs = pushstmt.executeQuery("select * from " + Pushreciever_liveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
                Thread.sleep(1000);
                System.out.println("temp" + rs.getStatement().toString());
                // rs.beforeFirst();
                while (rs.next()) {
                    System.out.println("push table has data");
                    // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                    //String DBResponseID = rs.getString(4);

                    RECIEVERTABLEDATA.put("insert_datetime", rs.getString(1));
                    RECIEVERTABLEDATA.put("joinid", rs.getString(2));
                    RECIEVERTABLEDATA.put("messageid", rs.getString(3));
                    RECIEVERTABLEDATA.put("responseid", rs.getString(4));
                    RECIEVERTABLEDATA.put("enterpriseid", rs.getString(5));
                    RECIEVERTABLEDATA.put("enterprisename", rs.getString(6));
                    RECIEVERTABLEDATA.put("subenterprisename", rs.getString(8));
                    RECIEVERTABLEDATA.put("author", rs.getString(9));
                    RECIEVERTABLEDATA.put("subauthor", rs.getString(10));
                    RECIEVERTABLEDATA.put("broadcastname", rs.getString(11));
                    RECIEVERTABLEDATA.put("receivedsender", rs.getString(14));
                    RECIEVERTABLEDATA.put("receivedsdate", rs.getString(15));
                    RECIEVERTABLEDATA.put("actualsender", rs.getString(16));
                    RECIEVERTABLEDATA.put("contenttype", rs.getString(17));
                    RECIEVERTABLEDATA.put("deliveryflag", rs.getString(18));
                    RECIEVERTABLEDATA.put("requestreceivedtime", rs.getString(19));
                    RECIEVERTABLEDATA.put("submittime", rs.getString(20));
                    RECIEVERTABLEDATA.put("messagetext", rs.getString(23));
                    RECIEVERTABLEDATA.put("bearer", rs.getString(24));
                    RECIEVERTABLEDATA.put("smscname", rs.getString(26));
                    RECIEVERTABLEDATA.put("smscount", rs.getString(27));
                    RECIEVERTABLEDATA.put("status", rs.getString(28));
                    RECIEVERTABLEDATA.put("statusdesc", rs.getString(29));
                    RECIEVERTABLEDATA.put("operatorid", rs.getString(32));
                    RECIEVERTABLEDATA.put("circleid", rs.getString(33));
                    RECIEVERTABLEDATA.put("operatorname", rs.getString(34));
                    RECIEVERTABLEDATA.put("dndflag", rs.getString(36));
                    RECIEVERTABLEDATA.put("countrycode", rs.getString(37));
                    RECIEVERTABLEDATA.put("smscredits", rs.getString(39));
                    RECIEVERTABLEDATA.put("templateid", rs.getString(43));
                    RECIEVERTABLEDATA.put("statusdescenum", rs.getString(46));
                    RECIEVERTABLEDATA.put("acc_id", rs.getString(58));
                    RECIEVERTABLEDATA.put("original_receivedsender", rs.getString(60));
                    RECIEVERTABLEDATA.put("original_actualsender", rs.getString(61));
                    RECIEVERTABLEDATA.put("dlt_tempid", rs.getString(62));
                    RECIEVERTABLEDATA.put("dlt_peid", rs.getString(65));
                    RECIEVERTABLEDATA.put("tempid_category", rs.getString(66));
                    RECIEVERTABLEDATA.put("originalmessage", rs.getString(67));
                    RECIEVERTABLEDATA.put("soip_flag", rs.getString(68));
                    RECIEVERTABLEDATA.put("vsms_flag", rs.getString(69));
                    RECIEVERTABLEDATA.put("mnp_dip_flag", rs.getString(70));


                }


            } catch (Exception e) {
                System.out.println(e);
            } finally {

                Recievercon.close();
                pushstmt.close();
                rs.close();

            }

            if (!RECIEVERTABLEDATA.isEmpty()) {
                break;
            }
            try {

                System.out.println("Internal Retry from SQL function");
                Thread.sleep(waittime);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
// Below function is created to check the data in previous hour table in case the table data map is still blank which may be due to server time gap issue.

        if (RECIEVERTABLEDATA.isEmpty()) {
            System.out.println("Now system is going to check the data in previous hour table ");
            //String temp="PUSH_RECEIVER_12_1_13";
            String splt[] = Pushreciever_liveTablename.split("_");
            //System.out.println("Current hour "+splt[4]);

            int previoushour = Integer.parseInt(splt[4]) - 1;

            // System.out.println("Previous hour "+previoushour);
            String Pushreciever_PreviousHourliveTablename = splt[0] + "_" + splt[1] + "_" + splt[2] + "_" + splt[3] + "_" + previoushour;
            System.out.println("Previous hour table name " + Pushreciever_PreviousHourliveTablename);
            RECIEVERTABLEDATA = GETMISDATAFROMRECIEVERTABLE_PREVIOUSHOUR(ResponseID, Pushreciever_PreviousHourliveTablename);
        }
        //
        if (RECIEVERTABLEDATA.isEmpty()) {
            System.out.println("Now system is going to check the data in next hour table ");
            //String temp="PUSH_RECEIVER_12_1_13";
            String splt[] = Pushreciever_liveTablename.split("_");
            //System.out.println("Current hour "+splt[4]);

            int nexthour = Integer.parseInt(splt[4]) + 1;

            // System.out.println("Previous hour "+previoushour);
            String Pushreciever_NextHourliveTablename = splt[0] + "_" + splt[1] + "_" + splt[2] + "_" + splt[3] + "_" + nexthour;
            System.out.println("Next hour table name " + Pushreciever_NextHourliveTablename);
            RECIEVERTABLEDATA = GETMISDATAFROMRECIEVERTABLE_PREVIOUSHOUR(ResponseID, Pushreciever_NextHourliveTablename);
        }


        return RECIEVERTABLEDATA;
    }


    public static Map GETMISDATAFROMRECIEVERTABLE_PREVIOUSHOUR(String ResponseID, String Pushreciever_PREVIOUSHOURliveTablename) throws SQLException {

        Map<String, String> RECIEVERTABLEDATA_PREVIOUSHOUR = new HashMap<>();


        Statement pushstmt = null;
        ResultSet rs = null;
        //System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


            pushstmt = Recievercon.createStatement();
            System.out.println("Reciever Table going to chekc is " + Pushreciever_PREVIOUSHOURliveTablename);
            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            System.out.println("Going to execute below Query..");
            System.out.println("select * from " + Pushreciever_PREVIOUSHOURliveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
            Thread.sleep(1000);
            rs = pushstmt.executeQuery("select * from " + Pushreciever_PREVIOUSHOURliveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
            Thread.sleep(1000);
            System.out.println("temp" + rs.getStatement().toString());
            // rs.beforeFirst();
            while (rs.next()) {
                System.out.println("push table has data");
                // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                //String DBResponseID = rs.getString(4);

                RECIEVERTABLEDATA_PREVIOUSHOUR.put("insert_datetime", rs.getString(1));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("joinid", rs.getString(2));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("messageid", rs.getString(3));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("responseid", rs.getString(4));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("enterpriseid", rs.getString(5));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("enterprisename", rs.getString(6));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("subenterprisename", rs.getString(8));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("author", rs.getString(9));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("subauthor", rs.getString(10));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("broadcastname", rs.getString(11));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("receivedsender", rs.getString(14));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("receivedsdate", rs.getString(15));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("actualsender", rs.getString(16));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("contenttype", rs.getString(17));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("deliveryflag", rs.getString(18));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("requestreceivedtime", rs.getString(19));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("submittime", rs.getString(20));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("messagetext", rs.getString(23));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("bearer", rs.getString(24));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("smscname", rs.getString(26));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("smscount", rs.getString(27));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("status", rs.getString(28));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("statusdesc", rs.getString(29));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("operatorid", rs.getString(32));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("circleid", rs.getString(33));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("operatorname", rs.getString(34));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("dndflag", rs.getString(36));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("countrycode", rs.getString(37));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("smscredits", rs.getString(39));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("templateid", rs.getString(43));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("statusdescenum", rs.getString(46));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("acc_id", rs.getString(58));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("original_receivedsender", rs.getString(60));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("original_actualsender", rs.getString(61));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("dlt_tempid", rs.getString(62));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("dlt_peid", rs.getString(65));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("tempid_category", rs.getString(66));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("originalmessage", rs.getString(67));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("soip_flag", rs.getString(68));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("vsms_flag", rs.getString(69));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("mnp_dip_flag", rs.getString(70));


            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            pushstmt.close();
            rs.close();

        }


        return RECIEVERTABLEDATA_PREVIOUSHOUR;


    }


//DLR STUFF


    public static Map GETMISDATAFROMDLRLIVETABLE(int waittime, String ResponseID, String DLR_liveTablename) throws SQLException {

        Map<String, String> DLRTABLEDATA = new HashMap<>();
        for (int i = 0; i < 3; i++) {

            Statement pushstmt = null;
            ResultSet rs = null;
            //System.out.println("The recieved Response ID from API =" + ResponseID.length());
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Recievercon = DriverManager.getConnection(
                        ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


                pushstmt = Recievercon.createStatement();
                System.out.println("DLR  Table going to chekc is " + DLR_liveTablename);
                String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
                System.out.println("Going to execute below Query..");
                System.out.println("select * from " + DLR_liveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
                Thread.sleep(1000);
                rs = pushstmt.executeQuery("select * from " + DLR_liveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
                Thread.sleep(1000);
                System.out.println("temp" + rs.getStatement().toString());
                // rs.beforeFirst();
                while (rs.next()) {
                    System.out.println("DLR  table has data");
                    // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                    //String DBResponseID = rs.getString(4);

                    DLRTABLEDATA.put("insert_datetime", rs.getString(1));
                    DLRTABLEDATA.put("joinid", rs.getString(2));
                    DLRTABLEDATA.put("messageid", rs.getString(3));
                    DLRTABLEDATA.put("responseid", rs.getString(4));
                    DLRTABLEDATA.put("enterpriseid", rs.getString(5));
                    DLRTABLEDATA.put("status", rs.getString(6));



                }


            } catch (Exception e) {
                System.out.println(e);
            } finally {

                Recievercon.close();
                pushstmt.close();
                rs.close();

            }

            if (!DLRTABLEDATA.isEmpty()) {
                break;
            }
            try {

                System.out.println("Internal Retry from SQL function");
                Thread.sleep(waittime);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
// Below function is created to check the data in previous hour table in case the table data map is still blank which may be due to server time gap issue.

        if (DLRTABLEDATA.isEmpty()) {
            System.out.println("Now system is going to check the data in previous hour table ");
            //String temp="PUSH_RECEIVER_12_1_13";
            String splt[] = DLR_liveTablename.split("_");
            //System.out.println("Current hour "+splt[4]);

            int previoushour = Integer.parseInt(splt[4]) - 1;

            // System.out.println("Previous hour "+previoushour);
            String DLR_PreviousHourliveTablename = splt[0] + "_" + splt[1] + "_" + splt[2] + "_" + splt[3] + "_" + previoushour;
            System.out.println("Previous hour table name " + DLR_PreviousHourliveTablename);
            DLRTABLEDATA = GETMISDATAFROMDLRTABLE_PREVIOUSHOUR(ResponseID, DLR_PreviousHourliveTablename);
        }

        //


        return DLRTABLEDATA;
    }

    public static Map GETRCSDATAFROMDLRLIVETABLE(int waittime, String Joinid, String DLR_liveTablename) throws SQLException {

        Map<String, String> DLRTABLEDATA = new HashMap<>();
        for (int i = 0; i < 3; i++) {

            Statement pushstmt = null;
            ResultSet rs = null;
            //System.out.println("The recieved Response ID from API =" + ResponseID.length());
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Recievercon = DriverManager.getConnection(
                        ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


                pushstmt = Recievercon.createStatement();
                System.out.println("DLR  Table going to chekc is " + DLR_liveTablename);
                String FinaljoinID = Joinid.replaceAll("[\\n\\t ]", "");
                System.out.println("Going to execute below Query..");
                System.out.println("select * from " + DLR_liveTablename + "  where joinid like '" + FinaljoinID + "%' ");
                Thread.sleep(1000);
                rs = pushstmt.executeQuery("select * from " + DLR_liveTablename + "  where joinid like '" + FinaljoinID + "%'");
                Thread.sleep(1000);
                System.out.println("temp" + rs.getStatement().toString());
                // rs.beforeFirst();
                while (rs.next()) {
                    System.out.println("DLR  table has data");
                    System.out.println(rs.getRow());
                    // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                    //String DBResponseID = rs.getString(4);

                    DLRTABLEDATA.put("ROWNO->"+rs.getRow()+"->id", rs.getString(1));
                    DLRTABLEDATA.put("ROWNO->"+rs.getRow()+"->joinid", rs.getString(2));
                    DLRTABLEDATA.put("ROWNO->"+rs.getRow()+"->rcsmessageid", rs.getString(3));
                    DLRTABLEDATA.put("ROWNO->"+rs.getRow()+"->enterpriseID", rs.getString(4));
                    DLRTABLEDATA.put("ROWNO->"+rs.getRow()+"->enterprisename", rs.getString(5));
                    DLRTABLEDATA.put("ROWNO->"+rs.getRow()+"->status", rs.getString(6));
                    DLRTABLEDATA.put("ROWNO->"+rs.getRow()+"->statusdesc", rs.getString(7));
                    DLRTABLEDATA.put("ROWNO->"+rs.getRow()+"->errorcode", rs.getString(8));



                }


            } catch (Exception e) {
                System.out.println(e);
            } finally {

                Recievercon.close();
                pushstmt.close();
                rs.close();

            }

            if (!DLRTABLEDATA.isEmpty()) {
                break;
            }
            try {

                System.out.println("Internal Retry from SQL function");
                Thread.sleep(waittime);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
// Below function is created to check the data in previous hour table in case the table data map is still blank which may be due to server time gap issue.
        if (DLRTABLEDATA.isEmpty()) {
            System.out.println("Now system is going to check the data in previous hour table ");
            //String temp="PUSH_RECEIVER_12_1_13";
            String splt[] = DLR_liveTablename.split("_");
            //System.out.println("Current hour "+splt[4]);

            int previoushour = Integer.parseInt(splt[4]) - 1;

            // System.out.println("Previous hour "+previoushour);
            String DLR_PreviousHourliveTablename = splt[0] + "_" + splt[1] + "_" + splt[2] + "_" + splt[3] + "_" + previoushour;
            System.out.println("Previous hour table name " + DLR_PreviousHourliveTablename);
            DLRTABLEDATA = GETRCSDATAFROMDLRTABLE_PREVIOUSHOUR(Joinid, DLR_PreviousHourliveTablename);
        }

        //


        return DLRTABLEDATA;
    }


    public static Map GETMISDATAFROM_WA_RECIEVERTABLE(int waittime, String ResponseID, String PushWAreciever_liveTablename) throws SQLException {

        Map<String, String> RECIEVERTABLEDATA = new HashMap<>();
        for (int i = 0; i < 3; i++) {

            Statement pushstmt = null;
            ResultSet rs = null;
            //System.out.println("The recieved Response ID from API =" + ResponseID.length());
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Recievercon = DriverManager.getConnection(
                        ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


                pushstmt = Recievercon.createStatement();
                System.out.println("Reciever Table going to chekc is " + PushWAreciever_liveTablename);
                String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
                System.out.println("Going to execute below Query..");
                System.out.println("select * from " + PushWAreciever_liveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
                Thread.sleep(5000);
                rs = pushstmt.executeQuery("select * from " + PushWAreciever_liveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
                Thread.sleep(5000);
                System.out.println("temp" + rs.getStatement().toString());
                // rs.beforeFirst();
                while (rs.next()) {
                    System.out.println("push table has data");
                    // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                    //String DBResponseID = rs.getString(4);

                    RECIEVERTABLEDATA.put("insert_datetime", rs.getString(1));
                    RECIEVERTABLEDATA.put("joinid", rs.getString(2));
                    RECIEVERTABLEDATA.put("messageid", rs.getString(3));
                    RECIEVERTABLEDATA.put("responseid", rs.getString(4));
                    RECIEVERTABLEDATA.put("enterpriseid", rs.getString(5));
                    RECIEVERTABLEDATA.put("enterprisename", rs.getString(6));
                    RECIEVERTABLEDATA.put("subenterpriseid", rs.getString(7));
                    RECIEVERTABLEDATA.put("subenterprisename", rs.getString(8));
                    RECIEVERTABLEDATA.put("author", rs.getString(9));
                    RECIEVERTABLEDATA.put("subauthor", rs.getString(10));
                    RECIEVERTABLEDATA.put("broadcastname", rs.getString(11));
                    RECIEVERTABLEDATA.put("receivedsender", rs.getString(14));
                    RECIEVERTABLEDATA.put("receivedsdate", rs.getString(15));
                    RECIEVERTABLEDATA.put("actualsender", rs.getString(16));
                    RECIEVERTABLEDATA.put("contenttype", rs.getString(17));
                    RECIEVERTABLEDATA.put("deliveryflag", rs.getString(18));
                    RECIEVERTABLEDATA.put("requestreceivedtime", rs.getString(19));
                    RECIEVERTABLEDATA.put("submittime", rs.getString(20));
                    RECIEVERTABLEDATA.put("messagetext", rs.getString(23));
                    RECIEVERTABLEDATA.put("bearer", rs.getString(24));
                    RECIEVERTABLEDATA.put("smscname", rs.getString(26));
                    RECIEVERTABLEDATA.put("smscount", rs.getString(27));
                    RECIEVERTABLEDATA.put("status", rs.getString(28));
                    RECIEVERTABLEDATA.put("statusdesc", rs.getString(29));
                    RECIEVERTABLEDATA.put("operatorid", rs.getString(32));
                    RECIEVERTABLEDATA.put("circleid", rs.getString(33));
                    RECIEVERTABLEDATA.put("operatorname", rs.getString(34));
                    RECIEVERTABLEDATA.put("dndflag", rs.getString(36));
                    RECIEVERTABLEDATA.put("countrycode", rs.getString(37));
                    RECIEVERTABLEDATA.put("smscredits", rs.getString(39));
                    RECIEVERTABLEDATA.put("templateid", rs.getString(43));
                    RECIEVERTABLEDATA.put("statusdescenum", rs.getString(46));
                    RECIEVERTABLEDATA.put("acc_id", rs.getString(56));
                    RECIEVERTABLEDATA.put("original_receivedsender", rs.getString(59));
                    RECIEVERTABLEDATA.put("original_actualsender", rs.getString(60));
                    RECIEVERTABLEDATA.put("dlt_tempid", rs.getString(61));
                    RECIEVERTABLEDATA.put("dlt_peid", rs.getString(64));
                    RECIEVERTABLEDATA.put("tempid_category", rs.getString(65));
                    RECIEVERTABLEDATA.put("originalmessage", rs.getString(67));
                    RECIEVERTABLEDATA.put("soip_flag", rs.getString(68));
                    RECIEVERTABLEDATA.put("vsms_flag", rs.getString(69));
                    RECIEVERTABLEDATA.put("wa_flag", rs.getString(70));
                    RECIEVERTABLEDATA.put("channel_sms", rs.getString(71));
                    RECIEVERTABLEDATA.put("channel_wa", rs.getString(72));
                    RECIEVERTABLEDATA.put("channel_rcs", rs.getString(73));
                    RECIEVERTABLEDATA.put("wabatransactionid", rs.getString(74));
                    RECIEVERTABLEDATA.put("wabaid", rs.getString(75));
                   RECIEVERTABLEDATA.put("wababusinessID", rs.getString(76));


                }


            } catch (Exception e) {
                System.out.println(e);
            } finally {

                Recievercon.close();
                pushstmt.close();
                rs.close();

            }

            if (!RECIEVERTABLEDATA.isEmpty()) {
                break;
            }
            try {

                System.out.println("Internal Retry from SQL function");
                Thread.sleep(waittime);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
// Below function is created to check the data in previous hour table in case the table data map is still blank which may be due to server time gap issue.

        if (RECIEVERTABLEDATA.isEmpty()) {
            System.out.println("Now system is going to check the data in previous hour table ");
            //String temp="PUSH_RECEIVER_12_1_13";
            String splt[] = PushWAreciever_liveTablename.split("_");
            //System.out.println("Current hour "+splt[4]);

            int previoushour = Integer.parseInt(splt[4]) - 1;

            // System.out.println("Previous hour "+previoushour);
            String Push_WA_reciever_PreviousHourliveTablename = splt[0] + "_" + splt[1] + "_" + splt[2] + "_" + splt[3] + "_" + previoushour;
            System.out.println("Previous hour table name " + Push_WA_reciever_PreviousHourliveTablename);
            RECIEVERTABLEDATA = GETMISDATAFROM_WA_RECIEVERTABLE_PREVIOUSHOUR(ResponseID, Push_WA_reciever_PreviousHourliveTablename);
        }

        //


        return RECIEVERTABLEDATA;
    }



    public static Map GETMISDATAFROM_WA_RECIEVERTABLE_PREVIOUSHOUR(String ResponseID, String PushRCSreciever_PREVIOUSHOURliveTablename) throws SQLException {

        Map<String, String> RECIEVERTABLEDATA = new HashMap<>();


        Statement pushstmt = null;
        ResultSet rs = null;
        //System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


            pushstmt = Recievercon.createStatement();
            System.out.println("Reciever Table going to chekc is " + PushRCSreciever_PREVIOUSHOURliveTablename);
            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            System.out.println("Going to execute below Query..");
            System.out.println("select * from " + PushRCSreciever_PREVIOUSHOURliveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
            Thread.sleep(1000);
            rs = pushstmt.executeQuery("select * from " + PushRCSreciever_PREVIOUSHOURliveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
            Thread.sleep(1000);
            System.out.println("temp" + rs.getStatement().toString());
            // rs.beforeFirst();
            while (rs.next()) {
                System.out.println("push table has data");
                // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                //String DBResponseID = rs.getString(4);

                RECIEVERTABLEDATA.put("insert_datetime", rs.getString(1));
                RECIEVERTABLEDATA.put("joinid", rs.getString(2));
                RECIEVERTABLEDATA.put("messageid", rs.getString(3));
                RECIEVERTABLEDATA.put("rcsMessageId", rs.getString(4));
                RECIEVERTABLEDATA.put("responseid", rs.getString(5));
                RECIEVERTABLEDATA.put("enterpriseid", rs.getString(6));
                RECIEVERTABLEDATA.put("enterprisename", rs.getString(7));
                RECIEVERTABLEDATA.put("subenterprisename", rs.getString(9));
                RECIEVERTABLEDATA.put("author", rs.getString(10));
                RECIEVERTABLEDATA.put("subauthor", rs.getString(11));
                RECIEVERTABLEDATA.put("broadcastname", rs.getString(12));
                RECIEVERTABLEDATA.put("receivedsender", rs.getString(15));
                RECIEVERTABLEDATA.put("receivedsdate", rs.getString(16));
                RECIEVERTABLEDATA.put("actualsender", rs.getString(17));
                RECIEVERTABLEDATA.put("contenttype", rs.getString(18));
                RECIEVERTABLEDATA.put("deliveryflag", rs.getString(19));
                RECIEVERTABLEDATA.put("requestreceivedtime", rs.getString(20));
                RECIEVERTABLEDATA.put("submittime", rs.getString(21));
                RECIEVERTABLEDATA.put("messagetext", rs.getString(24));
                RECIEVERTABLEDATA.put("bearer", rs.getString(25));
                RECIEVERTABLEDATA.put("smscname", rs.getString(27));
                RECIEVERTABLEDATA.put("smscount", rs.getString(28));
                RECIEVERTABLEDATA.put("status", rs.getString(29));
                RECIEVERTABLEDATA.put("statusdesc", rs.getString(30));
                RECIEVERTABLEDATA.put("operatorid", rs.getString(33));
                RECIEVERTABLEDATA.put("circleid", rs.getString(34));
                RECIEVERTABLEDATA.put("operatorname", rs.getString(35));
                RECIEVERTABLEDATA.put("dndflag", rs.getString(37));
                RECIEVERTABLEDATA.put("countrycode", rs.getString(38));
                RECIEVERTABLEDATA.put("smscredits", rs.getString(40));
                RECIEVERTABLEDATA.put("templateid", rs.getString(44));
                RECIEVERTABLEDATA.put("statusdescenum", rs.getString(47));
                RECIEVERTABLEDATA.put("acc_id", rs.getString(57));
                RECIEVERTABLEDATA.put("original_receivedsender", rs.getString(60));
                RECIEVERTABLEDATA.put("original_actualsender", rs.getString(61));
                RECIEVERTABLEDATA.put("dlt_tempid", rs.getString(62));
                RECIEVERTABLEDATA.put("dlt_peid", rs.getString(65));
                RECIEVERTABLEDATA.put("tempid_category", rs.getString(66));
                RECIEVERTABLEDATA.put("originalmessage", rs.getString(68));
                RECIEVERTABLEDATA.put("soip_flag", rs.getString(69));
                RECIEVERTABLEDATA.put("vsms_flag", rs.getString(70));
                RECIEVERTABLEDATA.put("wa_flag", rs.getString(71));
                RECIEVERTABLEDATA.put("channel_sms", rs.getString(72));
                RECIEVERTABLEDATA.put("channel_wa", rs.getString(73));
                RECIEVERTABLEDATA.put("channel_rcs", rs.getString(74));
                RECIEVERTABLEDATA.put("wabatransactionid", rs.getString(75));
                RECIEVERTABLEDATA.put("wabaid", rs.getString(76));
                RECIEVERTABLEDATA.put("wababusinessID", rs.getString(77));

            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            pushstmt.close();
            rs.close();

        }


        return RECIEVERTABLEDATA;


    }


    public static Map GETMISDATAFROMDLRTABLE_PREVIOUSHOUR(String ResponseID, String DLR_PreviousHourliveTablename) throws SQLException {

        Map<String, String> DLRTABLEDATA_PREVIOUSHOUR = new HashMap<>();


        Statement pushstmt = null;
        ResultSet rs = null;
        //System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


            pushstmt = Recievercon.createStatement();
            System.out.println("Reciever Table going to chekc is " + DLR_PreviousHourliveTablename);
            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            System.out.println("Going to execute below Query..");
            System.out.println("select * from " + DLR_PreviousHourliveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
            Thread.sleep(1000);
            rs = pushstmt.executeQuery("select * from " + DLR_PreviousHourliveTablename + "  where responseId like '" + FinalresponseID + "%' limit 0,1");
            Thread.sleep(1000);
            System.out.println("temp" + rs.getStatement().toString());
            // rs.beforeFirst();
            while (rs.next()) {
                System.out.println("push table has data");
                // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                //String DBResponseID = rs.getString(4);

                DLRTABLEDATA_PREVIOUSHOUR.put("insert_datetime", rs.getString(1));
                DLRTABLEDATA_PREVIOUSHOUR.put("joinid", rs.getString(2));
                DLRTABLEDATA_PREVIOUSHOUR.put("messageid", rs.getString(3));
                DLRTABLEDATA_PREVIOUSHOUR.put("responseid", rs.getString(4));
                DLRTABLEDATA_PREVIOUSHOUR.put("enterpriseid", rs.getString(5));
                DLRTABLEDATA_PREVIOUSHOUR.put("enterprisename", rs.getString(6));



            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            pushstmt.close();
            rs.close();

        }


        return DLRTABLEDATA_PREVIOUSHOUR;


    }

    public static Map GETRCSDATAFROMDLRTABLE_PREVIOUSHOUR(String Joinid, String DLR_PreviousHourliveTablename) throws SQLException {

        Map<String, String> DLRTABLEDATA_PREVIOUSHOUR = new HashMap<>();


        Statement pushstmt = null;
        ResultSet rs = null;
        //System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


            pushstmt = Recievercon.createStatement();
            System.out.println("Reciever Table going to chekc is " + DLR_PreviousHourliveTablename);
            String FinaljoinID = Joinid.replaceAll("[\\n\\t ]", "");
            System.out.println("Going to execute below Query..");
            System.out.println("select * from " + DLR_PreviousHourliveTablename + "  where joinid like '" + FinaljoinID + "%' limit 0,1");
            Thread.sleep(1000);
            rs = pushstmt.executeQuery("select * from " + DLR_PreviousHourliveTablename + "  where joinid like '" + FinaljoinID + "%' limit 0,1");
            Thread.sleep(1000);
            System.out.println("temp" + rs.getStatement().toString());
            // rs.beforeFirst();
            while (rs.next()) {
                System.out.println("push table has data");
                // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                //String DBResponseID = rs.getString(4);



                DLRTABLEDATA_PREVIOUSHOUR.put("ROWNO->"+rs.getRow()+"->id", rs.getString(1));
                DLRTABLEDATA_PREVIOUSHOUR.put("ROWNO->"+rs.getRow()+"->joinid", rs.getString(2));
                DLRTABLEDATA_PREVIOUSHOUR.put("ROWNO->"+rs.getRow()+"->rcsmessageid", rs.getString(3));
                DLRTABLEDATA_PREVIOUSHOUR.put("ROWNO->"+rs.getRow()+"->enterpriseID", rs.getString(4));
                DLRTABLEDATA_PREVIOUSHOUR.put("ROWNO->"+rs.getRow()+"->enterprisename", rs.getString(5));
                DLRTABLEDATA_PREVIOUSHOUR.put("ROWNO->"+rs.getRow()+"->status", rs.getString(6));
                DLRTABLEDATA_PREVIOUSHOUR.put("ROWNO->"+rs.getRow()+"->statusdesc", rs.getString(7));
                DLRTABLEDATA_PREVIOUSHOUR.put("ROWNO->"+rs.getRow()+"->errorcode", rs.getString(8));

            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            pushstmt.close();
            rs.close();

        }


        return DLRTABLEDATA_PREVIOUSHOUR;


    }
    public static Map GETMISDATAFROMRECIEVERTABLENEGATIVE(int waittime,String enterprisename,String Pushreciever_liveTablename) throws SQLException {

        Map<String, String> RECIEVERTABLEDATA = new HashMap<>();
        for (int i = 0; i < 3; i++) {

            Statement pushstmt = null;
            ResultSet rs = null;
            //System.out.println("The recieved Response ID from API =" + ResponseID.length());
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Recievercon = DriverManager.getConnection(
                        ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


                pushstmt = Recievercon.createStatement();
                System.out.println("Reciever Table going to chekc is " + Pushreciever_liveTablename);
//                String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
                System.out.println("Going to execute below Query..");
                System.out.println("select * from " + Pushreciever_liveTablename +  " where enterprisename="+"'"+enterprisename+"'"+";");
                Thread.sleep(1000);
                rs = pushstmt.executeQuery("select * from " + Pushreciever_liveTablename + " where enterprisename="+"'"+enterprisename+"'"+";");
                Thread.sleep(1000);
                System.out.println("temp" + rs.getStatement().toString());
                // rs.beforeFirst();
                while (rs.next()) {
                    System.out.println("push table has data");

                    RECIEVERTABLEDATA.put("insert_datetime", rs.getString(1));
                    RECIEVERTABLEDATA.put("joinid", rs.getString(2));
                    RECIEVERTABLEDATA.put("messageid", rs.getString(3));
                    RECIEVERTABLEDATA.put("responseid", rs.getString(4));
                    RECIEVERTABLEDATA.put("enterpriseid", rs.getString(5));
                    RECIEVERTABLEDATA.put("enterprisename", rs.getString(6));
                    RECIEVERTABLEDATA.put("subenterprisename", rs.getString(8));
                    RECIEVERTABLEDATA.put("author", rs.getString(9));
                    RECIEVERTABLEDATA.put("subauthor", rs.getString(10));
                    RECIEVERTABLEDATA.put("broadcastname", rs.getString(11));
                    RECIEVERTABLEDATA.put("receivedsender", rs.getString(14));
                    RECIEVERTABLEDATA.put("receivedsdate", rs.getString(15));
                    RECIEVERTABLEDATA.put("actualsender", rs.getString(16));
                    RECIEVERTABLEDATA.put("contenttype", rs.getString(17));
                    RECIEVERTABLEDATA.put("deliveryflag", rs.getString(18));
                    RECIEVERTABLEDATA.put("requestreceivedtime", rs.getString(19));
                    RECIEVERTABLEDATA.put("submittime", rs.getString(20));
                    RECIEVERTABLEDATA.put("messagetext", rs.getString(23));
                    RECIEVERTABLEDATA.put("bearer", rs.getString(24));
                    RECIEVERTABLEDATA.put("smscname", rs.getString(26));
                    RECIEVERTABLEDATA.put("smscount", rs.getString(27));
                    RECIEVERTABLEDATA.put("status", rs.getString(28));
                    RECIEVERTABLEDATA.put("statusdesc", rs.getString(29));
                    RECIEVERTABLEDATA.put("operatorid", rs.getString(32));
                    RECIEVERTABLEDATA.put("circleid", rs.getString(33));
                    RECIEVERTABLEDATA.put("operatorname", rs.getString(34));
                    RECIEVERTABLEDATA.put("dndflag", rs.getString(36));
                    RECIEVERTABLEDATA.put("countrycode", rs.getString(37));
                    RECIEVERTABLEDATA.put("smscredits", rs.getString(39));
                    RECIEVERTABLEDATA.put("templateid", rs.getString(43));
                    RECIEVERTABLEDATA.put("statusdescenum", rs.getString(46));
                    RECIEVERTABLEDATA.put("acc_id", rs.getString(58));
                    RECIEVERTABLEDATA.put("original_receivedsender", rs.getString(60));
                    RECIEVERTABLEDATA.put("original_actualsender", rs.getString(61));
                    RECIEVERTABLEDATA.put("dlt_tempid", rs.getString(62));
                    RECIEVERTABLEDATA.put("dlt_peid", rs.getString(65));
                    RECIEVERTABLEDATA.put("tempid_category", rs.getString(66));
                    RECIEVERTABLEDATA.put("originalmessage", rs.getString(67));
                    RECIEVERTABLEDATA.put("soip_flag", rs.getString(68));
                    RECIEVERTABLEDATA.put("vsms_flag", rs.getString(69));
                    RECIEVERTABLEDATA.put("mnp_dip_flag", rs.getString(70));


                }


            } catch (Exception e) {
                System.out.println(e);
            } finally {

                Recievercon.close();
                pushstmt.close();
                rs.close();

            }

            if (!RECIEVERTABLEDATA.isEmpty()) {
                break;
            }
            try {

                System.out.println("Internal Retry from SQL function");
                Thread.sleep(waittime);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
// Below function is created to check the data in previous hour table in case the table data map is still blank which may be due to server time gap issue.

        if (RECIEVERTABLEDATA.isEmpty()) {
            System.out.println("Now system is going to check the data in previous hour table ");
            //String temp="PUSH_RECEIVER_12_1_13";
            String splt[] = Pushreciever_liveTablename.split("_");
            //System.out.println("Current hour "+splt[4]);

            int previoushour = Integer.parseInt(splt[4]) - 1;

            // System.out.println("Previous hour "+previoushour);
            String Pushreciever_PreviousHourliveTablename = splt[0] + "_" + splt[1] + "_" + splt[2] + "_" + splt[3] + "_" + previoushour;
            System.out.println("Previous hour table name " + Pushreciever_PreviousHourliveTablename);
            RECIEVERTABLEDATA = GETMISDATAFROMRECIEVERTABLE_PREVIOUSHOURNEGATIVE(enterprisename, Pushreciever_PreviousHourliveTablename);
        }




        return RECIEVERTABLEDATA;
    }

    public static Map GETMISDATAFROMRECIEVERTABLE_PREVIOUSHOURNEGATIVE(String enterprisename, String Pushreciever_PREVIOUSHOURliveTablename) throws SQLException {

        Map<String, String> RECIEVERTABLEDATA_PREVIOUSHOUR = new HashMap<>();


        Statement pushstmt = null;
        ResultSet rs = null;
        //System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


            pushstmt = Recievercon.createStatement();
            System.out.println("Reciever Table going to chekc is " + Pushreciever_PREVIOUSHOURliveTablename);
//            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            System.out.println("Going to execute below Query..");
            System.out.println("select * from " + Pushreciever_PREVIOUSHOURliveTablename + " where enterprisename="+"'"+enterprisename+"'"+";");
            Thread.sleep(1000);
            rs = pushstmt.executeQuery("select * from " + Pushreciever_PREVIOUSHOURliveTablename + " where enterprisename="+"'"+enterprisename+"'"+";");
            Thread.sleep(1000);
            System.out.println("temp" + rs.getStatement().toString());
            // rs.beforeFirst();
            while (rs.next()) {
                System.out.println("push table has data");
                // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                //String DBResponseID = rs.getString(4);

                RECIEVERTABLEDATA_PREVIOUSHOUR.put("insert_datetime", rs.getString(1));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("joinid", rs.getString(2));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("messageid", rs.getString(3));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("responseid", rs.getString(4));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("enterpriseid", rs.getString(5));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("enterprisename", rs.getString(6));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("subenterprisename", rs.getString(8));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("author", rs.getString(9));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("subauthor", rs.getString(10));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("broadcastname", rs.getString(11));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("receivedsender", rs.getString(14));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("receivedsdate", rs.getString(15));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("actualsender", rs.getString(16));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("contenttype", rs.getString(17));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("deliveryflag", rs.getString(18));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("requestreceivedtime", rs.getString(19));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("submittime", rs.getString(20));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("messagetext", rs.getString(23));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("bearer", rs.getString(24));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("smscname", rs.getString(26));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("smscount", rs.getString(27));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("status", rs.getString(28));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("statusdesc", rs.getString(29));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("operatorid", rs.getString(32));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("circleid", rs.getString(33));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("operatorname", rs.getString(34));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("dndflag", rs.getString(36));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("countrycode", rs.getString(37));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("smscredits", rs.getString(39));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("templateid", rs.getString(43));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("statusdescenum", rs.getString(46));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("acc_id", rs.getString(58));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("original_receivedsender", rs.getString(60));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("original_actualsender", rs.getString(61));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("dlt_tempid", rs.getString(62));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("dlt_peid", rs.getString(65));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("tempid_category", rs.getString(66));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("originalmessage", rs.getString(67));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("soip_flag", rs.getString(68));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("vsms_flag", rs.getString(69));
                RECIEVERTABLEDATA_PREVIOUSHOUR.put("mnp_dip_flag", rs.getString(70));


            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            pushstmt.close();
            rs.close();

        }


        return RECIEVERTABLEDATA_PREVIOUSHOUR;


    }

    public static Map GETWADATAFROMDLRLIVETABLE(int waittime, String Joinid, String DLR_liveTablename) throws SQLException {

        Map<String, String> DLRTABLEDATA = new HashMap<>();
        for (int i = 0; i < 3; i++) {

            Statement pushstmt = null;
            ResultSet rs = null;
            //System.out.println("The recieved Response ID from API =" + ResponseID.length());
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Recievercon = DriverManager.getConnection(
                        ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


                pushstmt = Recievercon.createStatement();
                System.out.println("DLR  Table going to chekc is " + DLR_liveTablename);
                String FinaljoinID = Joinid.replaceAll("[\\n\\t ]", "");
                System.out.println("Going to execute below Query..");
                System.out.println("select * from " + DLR_liveTablename + "  where joinid like '" + FinaljoinID + "%' limit 0,1");
                Thread.sleep(1000);
                rs = pushstmt.executeQuery("select * from " + DLR_liveTablename + "  where joinid like '" + FinaljoinID + "%' limit 0,1");
                Thread.sleep(1000);
                System.out.println("temp" + rs.getStatement().toString());
                // rs.beforeFirst();
                while (rs.next()) {
                    System.out.println("DLR  table has data");
                    // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                    //String DBResponseID = rs.getString(4);

                    ((Map)DLRTABLEDATA).put("ROWNO->" + rs.getRow() + "->id", rs.getString(1));
                    ((Map)DLRTABLEDATA).put("ROWNO->" + rs.getRow() + "->joinid", rs.getString(2));
                    ((Map)DLRTABLEDATA).put("ROWNO->" + rs.getRow() + "->wabatransid", rs.getString(3));
                    ((Map)DLRTABLEDATA).put("ROWNO->" + rs.getRow() + "->enterpriseID", rs.getString(4));
                    ((Map)DLRTABLEDATA).put("ROWNO->" + rs.getRow() + "->enterprisename", rs.getString(5));
                    ((Map)DLRTABLEDATA).put("ROWNO->" + rs.getRow() + "->status", rs.getString(6));
                    ((Map)DLRTABLEDATA).put("ROWNO->" + rs.getRow() + "->statusdesc", rs.getString(7));
                    ((Map)DLRTABLEDATA).put("ROWNO->" + rs.getRow() + "->dlrreceivedtime", rs.getString(8));



                }


            } catch (Exception e) {
                System.out.println(e);
            } finally {

                Recievercon.close();
                pushstmt.close();
                rs.close();

            }

            if (!DLRTABLEDATA.isEmpty()) {
                break;
            }
            try {

                System.out.println("Internal Retry from SQL function");
                Thread.sleep(waittime);
            } catch (Exception e) {
                System.out.println(e);
            }
        }

// Below function is created to check the data in previous hour table in case the table data map is still blank which may be due to server time gap issue.

        if (DLRTABLEDATA.isEmpty()) {
            System.out.println("Now system is going to check the data in previous hour table ");
            //String temp="PUSH_RECEIVER_12_1_13";
            String splt[] = DLR_liveTablename.split("_");
            //System.out.println("Current hour "+splt[4]);

            int previoushour = Integer.parseInt(splt[4]) - 1;

            // System.out.println("Previous hour "+previoushour);
            String DLR_PreviousHourliveTablename = splt[0] + "_" + splt[1] + "_" + splt[2] + "_" + splt[3] + "_" + previoushour;
            System.out.println("Previous hour table name " + DLR_PreviousHourliveTablename);
            DLRTABLEDATA = GETWADATAFROMDLRTABLE_PREVIOUSHOUR(Joinid, DLR_PreviousHourliveTablename);
        }

        //


        return DLRTABLEDATA;
    }







    public static Map GETWADATAFROMDLRTABLE_PREVIOUSHOUR(String Joinid, String DLR_PreviousHourliveTablename) throws SQLException {

        Map<String, String> DLRTABLEDATA_PREVIOUSHOUR = new HashMap<>();


        Statement pushstmt = null;
        ResultSet rs = null;
        //System.out.println("The recieved Response ID from API =" + ResponseID.length());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(
                    ob.GetProperty("PUSHRECIEVER_DB_URL"), ob.GetProperty("PUSHRECIEVER_DB_USER"), ob.GetProperty("PUSHRECIEVER_DB_PASS"));


            pushstmt = Recievercon.createStatement();
            System.out.println("Reciever Table going to chekc is " + DLR_PreviousHourliveTablename);
            String FinaljoinID = Joinid.replaceAll("[\\n\\t ]", "");
            System.out.println("Going to execute below Query..");
            System.out.println("select * from " + DLR_PreviousHourliveTablename + "  where joinid like '" + FinaljoinID + "%' limit 0,1");
            Thread.sleep(1000);
            rs = pushstmt.executeQuery("select * from " + DLR_PreviousHourliveTablename + "  where joinid like '" + FinaljoinID + "%' limit 0,1");
            Thread.sleep(1000);
            System.out.println("temp" + rs.getStatement().toString());
            // rs.beforeFirst();
            while (rs.next()) {
                System.out.println("push table has data");
                // System.out.println(rs.getString(4) + "  " + rs.getString(29));

                //String DBResponseID = rs.getString(4);

                ((Map)DLRTABLEDATA_PREVIOUSHOUR).put("ROWNO->" + rs.getRow() + "->id", rs.getString(1));
                ((Map)DLRTABLEDATA_PREVIOUSHOUR).put("ROWNO->" + rs.getRow() + "->joinid", rs.getString(2));
                ((Map)DLRTABLEDATA_PREVIOUSHOUR).put("ROWNO->" + rs.getRow() + "->wabatransid", rs.getString(3));
                ((Map)DLRTABLEDATA_PREVIOUSHOUR).put("ROWNO->" + rs.getRow() + "->enterpriseID", rs.getString(4));
                ((Map)DLRTABLEDATA_PREVIOUSHOUR).put("ROWNO->" + rs.getRow() + "->enterprisename", rs.getString(5));
                ((Map)DLRTABLEDATA_PREVIOUSHOUR).put("ROWNO->" + rs.getRow() + "->status", rs.getString(6));
                ((Map)DLRTABLEDATA_PREVIOUSHOUR).put("ROWNO->" + rs.getRow() + "->statusdesc", rs.getString(7));
                ((Map)DLRTABLEDATA_PREVIOUSHOUR).put("ROWNO->" + rs.getRow() + "->dlrreceivedtime", rs.getString(8));



            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            pushstmt.close();
            rs.close();

        }


        return DLRTABLEDATA_PREVIOUSHOUR;


    }


    public static Map GETMISDATA_FROM_SHORTSTAGE_RECIEVERTABLE(String ResponseID, String liveTablename, String Shortstage_liveTablename, String fieldname) throws SQLException {
        boolean result = false;
        Statement shortstagestmt = null;
        Map<String, String> BEETABLEDATA = new HashMap<>();
        ResultSet rs = null;
        try {
            String MessageID = GETMSGID_FROM_PUSHRECEIVERDB(ResponseID, liveTablename);
            System.out.println("The messageID is = " + MessageID);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Recievercon = DriverManager.getConnection(ob.GetProperty("SHORTSTAGE_DB_URL"), ob.GetProperty("SHORTSTAGE_DB_USER"), ob.GetProperty("SHORTSTAGE_DB_PASS"));

            shortstagestmt = Recievercon.createStatement();

            String FinalresponseID = ResponseID.replaceAll("[\\n\\t ]", "");
            System.out.println("Shortstageuery--->select "+fieldname+" from " + Shortstage_liveTablename + "  where joinid=" + MessageID);
            rs = shortstagestmt.executeQuery("select "+fieldname+" from " + Shortstage_liveTablename + "  where joinid=" + MessageID);
                    Thread.sleep(1000);

                    while (rs.next()) {
                BEETABLEDATA.put("routing_channel",rs.getString(1));


            }


        } catch (Exception e) {
            System.out.println(e);
        } finally {

            Recievercon.close();
            shortstagestmt.close();
            rs.close();

        }
        return BEETABLEDATA;
    }

}



