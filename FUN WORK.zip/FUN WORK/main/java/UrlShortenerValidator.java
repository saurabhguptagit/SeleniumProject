import java.util.regex.*;
import java.util.*;

public class UrlShortenerValidator {

    public static Map RETURNSHORTRESULT(String Originaltext, String msgtext) {
        //String string1 = "XXXXXXXXXXXXSettlement https://timesofindia.indiatimes.com/ for amount https://timesofindia.indiatimes.com/ for loan no. https://www.google.com/ is initiated.";
       // String string2 = "Alert! http://acl.cc/xJYRj3pwG Settlement for amount http://acl.cc/xJYRj3pwG for loan no. http://acl.cc/xJYRj3pwG is initiated.";

        Map<String, Object> map = new HashMap<>();

        // List

        String string1 = Originaltext;
         String string2 = msgtext;

        List<String> originalUrls = extractUrls(string1);
        List<String> shortenedUrls = extractUrls(string2);

        System.out.println("Original URLs: " + originalUrls);
        System.out.println("Shortened URLs: " + shortenedUrls);

        // Basic validation
        if (originalUrls.size() != shortenedUrls.size()) {
            System.out.println("Mismatch in number of URLs ❌");
        } else {
            System.out.println("URL count matches");
        }

        if (allUrlsAreShort(string2)) {
            System.out.println("All URLs are shortened ✅");
            map.put("shortresult", shortenedUrls);
            map.put("isShorteningpass", true);
        } else {
            System.out.println("Some URLs are NOT shortened ❌");
            map.put("shortresult", shortenedUrls);
            map.put("isShorteningpass", false);
        }

        return map;
    }
   /* public static boolean hasShortUrls(String text) {
        String shortUrlRegex = "http://acl\\.cc/\\S+";
        return text.matches(".*" + shortUrlRegex + ".*");
    }
*/

    public static boolean allUrlsAreShort(String text) {
        List<String> urls = extractUrls(text);

        // If no URLs, you can decide true/false based on requirement
        if (urls.isEmpty()) return false;

        for (String url : urls) {
            if (!isShortUrl(url)) {
                return false; // ❌ Found a long URL → fail immediately
            }
        }
        return true; // ✅ All URLs are short
    }

    public static List<String> extractUrls(String text) {
        List<String> urls = new ArrayList<>();
        String regex = "(https?://\\S+)";
        Matcher matcher = Pattern.compile(regex).matcher(text);

        while (matcher.find()) {
            urls.add(matcher.group());
        }
        return urls;
    }

    public static boolean isShortUrl(String url) {
        return url.startsWith("http://acl.cc/");
    }
}

