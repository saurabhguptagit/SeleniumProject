import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

    public class ExcelUtils {

//test
		public static String TESTDATA_SHEET_PATH = System.getProperty("user.dir") + "/src/main/resources/Util/";

		static Workbook book;
		static Sheet sheet;
		//static int GetspecificrowID=0;
		public static Object[][] getTestData(String sheetName, int Getrowno,String Testdatafilename) {

			System.out.println("the row no passed to function is "+Getrowno);
			FileInputStream file = null;
			try {
				file = new FileInputStream(TESTDATA_SHEET_PATH+Testdatafilename);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			try {
				book = WorkbookFactory.create(file);
			} catch (Exception e) {
				e.printStackTrace();
			}
			sheet = book.getSheet(sheetName);
		System.out.println("Last row no "+sheet.getLastRowNum());
			System.out.println(sheet.getRow(0).getLastCellNum());


			if (Getrowno == 0)
			{
				Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
				for (int i = 0; i < sheet.getLastRowNum(); i++) {
					for (int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
						data[i][k] = sheet.getRow(i + 1).getCell(k).toString();

					}
				}
				return data;
		    }
			else{
				Object[][] specificdata = new Object[1][sheet.getRow(0).getLastCellNum()];
				for (int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
					specificdata[0][k] = sheet.getRow(Getrowno).getCell(k).toString();

				}
				return specificdata;
			}

		}
	}