import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Map;

public class TestServlet {
    TestBase ob;

    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
        //ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST FOR NTEXT LISTNERS</b></h5>");
        String env = ob.GetProperty("Environment");
        if (env.contentEquals("QA_AWS")) {
            RestAssured.baseURI = ob.GetProperty("QA_AWS_TESTSERVLET_BASE_URI");

        } else if (env.contentEquals("QA_142_Direct")) {
            RestAssured.baseURI = ob.GetProperty("QA_AWS_DIRECT_TEXT_BASE_URI");
        } else {
            throw new Exception("Envioenment name in Property is not valid");
        }

    }


    @Test(dataProvider = "getNTEXTdetails", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void Check_Error_Codes_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String ExpecResponse, String shortflag, String drflag, String msgid, String alertdnd, String D, String f, String iu, String au, String fb) {
        if (!FunctionName.contentEquals("Test_DuplicateMessageID")) {
            ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_Listener_ERRORCASE -->" + FunctionName + "</b>");
            try {
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Negative case-->" + FunctionName + "</b>");
                String SCTYPE = "";
                if (Contenttype.contentEquals("BLK")) {

                } else {
                    double ctype = Double.parseDouble(Contenttype);
                    int ictype = (int) (Math.round(ctype * 100) / 100);
                    SCTYPE = String.valueOf(ictype);
                }

                if (APPID.contentEquals("BLK")) {
                    APPID = "";
                }
                if (UserID.contentEquals("BLK")) {
                    UserID = "";
                }
                if (Passd.contentEquals("BLK")) {
                    Passd = "";
                }
                if (ALERT.contentEquals("BLK")) {
                    ALERT = "";
                } else {
                    double alrt = Double.parseDouble(ALERT);
                    int INALERT = (int) (Math.round(alrt * 100) / 100);
                    ALERT = String.valueOf(INALERT);
                }
                if (INTFLAG.contentEquals("BLK")) {
                    INTFLAG = "";
                }
                if (MSG.contentEquals("BLK")) {
                    MSG = "";
                }
                if (FROM.contentEquals("BLK")) {
                    FROM = "";
                }
                if (TO.contentEquals("BLK")) {
                    TO = "";
                }
                if (shortflag.contentEquals("BLK")) {
                    shortflag = "";
                } else {
                    double shortflg = Double.parseDouble(shortflag);
                    int SHORTFLAG = (int) (Math.round(shortflg * 100) / 100);
                    shortflag = String.valueOf(SHORTFLAG);
                }

                if (SELFID.contentEquals("FALSE")) {
                    msgid = "";
                }
                if (msgid.contentEquals("BLK")) {
                    msgid = "";
                }
                if (drflag.contentEquals("BLK")) {
                    drflag = "";
                } else {
                    double DRflg = Double.parseDouble(drflag);
                    int DRFLAG = (int) (Math.round(DRflg * 100) / 100);
                    drflag = String.valueOf(DRFLAG);
                }
                if (alertdnd.contentEquals("BLK")) {
                    alertdnd = "";
                } else {
                    double alerdndflg = Double.parseDouble(alertdnd);
                    int DNDFLAG = (int) (Math.round(alerdndflg * 100) / 100);
                    alertdnd = String.valueOf(DNDFLAG);
                }
                if (D.contentEquals("BLK")) {
                    D = "";
                }

                if (f.contentEquals("BLK")) {
                    f = "";
                } else {
                    double ff = Double.parseDouble(f);
                    int fff = (int) (Math.round(ff * 100) / 100);
                    f = String.valueOf(fff);
                }

                if (iu.contentEquals("BLK")) {
                    iu = "";
                }
                if (au.contentEquals("BLK")) {
                    au = "";
                }
                if (fb.contentEquals("BLK")) {
                    fb = "";
                }
                RequestSpecification request = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "9918702626")
                        .param("text", MSG)
                        .param("alert", ALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("s", shortflag)
                        .param("dr", drflag)
                        .param("msgid", msgid)
                        .param("alertdnd", alertdnd)
                        .param("d", D)
                        .param("f", f)
                        .param("iu", iu)
                        .param("au", au)
                        .param("fb", fb);

                Response response = request.post();
                System.out.println("Response Object  " + response.asString());

                double Eresponse = Double.parseDouble(ExpecResponse);
                int Ecode = (int) (Math.round(Eresponse * 100) / 100);
                String ExpecetdNResponse = String.valueOf(Ecode);

                String Acturesponse = response.asString().replaceAll("[\\n\\t ]", "");

            /*double a = Double.parseDouble(Acturesponse);
            int Acode = (int) (Math.round(a * 100) / 100);
            String ANResponse = String.valueOf(Acode); */

                if (Acturesponse.contentEquals(ExpecetdNResponse)) {
                    System.out.println(FunctionName + " Passed");
                    ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Acturesponse + " did not match with Expected Response " + ExpecetdNResponse);

                    Assert.assertEquals(Acturesponse, ExpecetdNResponse, "Response code not matched for " + FunctionName);

                    System.out.println("Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);


                }


            } catch (Exception e) {
                ExtentBASETEST.extentReportsDemo("INFO", e.toString());
                System.out.println(e);

            }
        }

    }


    @Test(dataProvider = "getNTEXTdetailsPositive", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void Check_Template_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_TEMPLATEMATCHING--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the postive case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                System.out.println("Response Object  " + responseid);
           /*     // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), true, "TestMSG", ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }

            */
                //

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                boolean DLRCHECK = false;
                String DLRLivetablename = "";
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "MSG", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + responseid + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        DLRCHECK = true;

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    }
                    System.out.println(MISDATA);
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);


                    if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                        DLRCHECK = true;
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    }


                }

                //DLR
                if (DLRCHECK) {
                    boolean result = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                    System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + result);

                    if (result) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    } else {
                        System.out.println("DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }

                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }

                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }


                    }
                }
                ExtentBASETEST.extentReportsDemo("INFO", "DLR TEST EXECUTED");

                //END


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTSMSCOUNTDATA", priority = 0, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void Check_SMSCOUNT_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String smscount) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>Check_SMSCOUNT_TEXTLISTNER--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            double b = Double.parseDouble(smscount);
            int SMSCOUNTroundOff = (int) (Math.round(b * 100) / 100);
            System.out.println("Expected sms count is " + SMSCOUNTroundOff);


            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the SMS COUNT  case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                System.out.println("Response Object  " + responseid);

              /*  // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), true, "TestMSG", ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //

               */
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));

                if (SMSCRESULT) {
                    //JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid,ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"),false,"DUMMY",ob.GetProperty("commonloglocation94"));
                    // ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->"+jsonbody.toString());


                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                    System.out.println(MISDATA);
                    // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                    if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                    }
                } else {

                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                    if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {
                        System.out.println(MISDATA);
                        // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                        if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                            ExtentBASETEST.extentReportsDemo("PASS", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                        }
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    }
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Something is wrong");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTSPECIFICROWforTilta", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void SPECIALCHAR_TILTA_HANDLING__TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_TEMPLATEMATCHING--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Tilta handling case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request.toString());
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);


                TestBase.setcurrenttime();
                Thread.sleep(6000);
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                System.out.println(MISDATA);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA-->" + MISDATA.toString());

                String actualmsg = ob.GetProperty("SPECIALCHAR_TILTA_TEXT");

                String newLineExpectedmsg = actualmsg.replace('~', '\n');

                String newLineActualmsg = MISDATA.get("messagetext");
                if (newLineExpectedmsg.contentEquals(newLineActualmsg)) {
                    String aar[] = newLineActualmsg.split("\n");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Replaced text with new line ---><b>" + Arrays.deepToString(aar) + "</b>");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Text with ~ char ---><b>" + actualmsg + "</b>");
                    ExtentBASETEST.extentReportsDemo("PASS", " <b>The ~  is successfully  converted into new line charracter </b>");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The ~ in the Actual message " + newLineActualmsg + " is not converted into new line charracter ....Please see Expected text --->" + newLineExpectedmsg);

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforshortening", priority = 1, enabled = true, invocationCount = 1)
    public void Check_SHORTENING_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_SHORTENING--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("s", "1");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the shortening case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);


                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                boolean shortresult = SQLPOOL.checkshortstageDB(responseid, PushRecieverLivetablename, ShortstageLiveBeetablename);

                if (shortresult) {
                    System.out.println("Shortening passed");
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    ExtentBASETEST.extentReportsDemo("PASS", "SHORTENING PASSED");
                    Assert.assertTrue(shortresult, "Shortening passed");

                    //DLR

                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                    //ENDDLR

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "SHORTENING FAILED");
                    Assert.assertTrue(shortresult, "Shortening Failed");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforinsufficentcredit", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void INSUFFICIENT_CREDIT_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_ListenerTest started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "919971498470")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Insufficent credit  case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                boolean DLRCHECKFLAG = false;
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "MSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                    }
                }
                //
                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }


                boolean result = LinuxLogReader.CheckPrepaidbalance(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "MSG", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (result) {
                    DLRCHECKFLAG = true;
                    ExtentBASETEST.extentReportsDemo("PASS", FunctionName + " PASSED for " + responseid);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", FunctionName + " FAILED for " + responseid);

                }

                if (DLRCHECKFLAG) {
                    TestBase.setcurrenttime();
                    Thread.sleep(1000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTSPECIFICROWforInternational", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void INTERNATIONAL_REQ_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_Listener started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "61491570156")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the international case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
               /*
                Thread.sleep(5000);
                JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid,ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"),false,"DUMMY",ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                try
                {
                    if(jsonbody.isEmpty())
                    {
                        ExtentBASETEST.extentReportsDemo("ERROR ","The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->"+jsonbody.toString());

                }catch(Exception e)
                {

                    ExtentBASETEST.extentReportsDemo("ERROR ",e.toString());

                } */
                TestBase.setcurrenttime();
                Thread.sleep(2000);
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                System.out.println(MISDATA);
                String smsc = MISDATA.get("smscname");
                //String smsc= String.valueOf(jsonbody.get("sn"));
                if (smsc.contains("-inter")) {

                    ExtentBASETEST.extentReportsDemo("PASS", "Request " + responseid + " is successfully submitted to SMSC & smsc selected is " + smsc);


                } else if (smsc.contains("NOT SUBMITTED TO SMSC")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + " Request has not been submitted to SMSC");
                    Assert.assertTrue(false, "FOR Request " + responseid + " SMSC is not matched for international request---> " + smsc);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + " SMSC is not matched for international request---> " + smsc);
                    Assert.assertTrue(false, "FOR Request " + responseid + " SMSC is not matched for international request--->" + smsc);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforCLIYES", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void OpenCLI_YES_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTENER_Test started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the OPEN CLI Yes case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response id " + responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));

                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " is matching with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is not matching with  Recieved sender is " + recievedsender);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());


        }

    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforCLINO", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void OpenCLI_NO_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTNER_Test started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the OPEN CLI NO case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response id " + responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));

                //

                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (!actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());


        }


    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforTemplateCONVERSION", priority = 1, enabled = true, invocationCount = 1)
    public void Check_Templateconversion_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String contertedtext) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_TEMPLATECONVERSION--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check MSG conversion for TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                System.out.println("this is actual  msg  before conversion" + MSG);
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg  before conversion <b>" + MSG + "</b>");

                System.out.println("this is expected converted msg from Excel" + contertedtext);
                ExtentBASETEST.extentReportsDemo("INFO", "this is expected converted msg from Excel <b>" + contertedtext + "</b>");

                System.out.println("this is actual converted msg from live sql table" + MISDATA.get("messagetext"));
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("messagetext") + "</b>");
                try {
                    if (contertedtext.contentEquals(MISDATA.get("messagetext"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The msg conversion is successfull</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The msg conversion is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTSPECIFICROWforINVALIDMESSAGE", priority = 1, enabled = true, invocationCount = 1)
    public void Check_INVALID_MESSAGE_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_INVALIDMESSAGE--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check INVALID MSG for TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }


                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if ("INVALID MESSAGE".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID msg check is successfull</b>");
                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR


                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID msg check NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTDPITCCheck", priority = 2, enabled = true, invocationCount = 1)
    public void Check_DPI_TC_TEXTLISTENER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String dpi, String tc, String dtm) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_DPI_DTM_TC_CHECK--> " + FunctionName + "</b>");
        try {
            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);
            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);
            if (dpi.contentEquals("BLK")) {
                dpi = "";
            }
            if (dtm.contentEquals("BLK")) {
                dtm = "";
            }
            if (tc.contentEquals("BLK")) {
                tc = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "8527607709")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("dpi", dpi)
                    .param("tc", tc)
                    .param("dtm", dtm);
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check MSG conversion for TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {


            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();


            System.out.println("Status code  " + statusCode);


            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response Object  " + responseid);

                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);


                ExtentBASETEST.extentReportsDemo("INFO", "this is Expected tc -->  <b>" + tc + "</b>" + " dpi --> <b>" + dpi + "</b>" + "dtm --> <b>" + dtm + "</b>");


                ExtentBASETEST.extentReportsDemo("INFO", "this is Actual --> tc from DB  --> <b>" + MISDATA.get("tempid_category") + "</b>" + " dpi from DB  --> <b>" + MISDATA.get("dlt_peid") + "</b>" + " dtm from DB  --><b>" + MISDATA.get("dlt_tempid") + "</b>");


                String act_tc = MISDATA.get("tempid_category");
                String act_dpi = MISDATA.get("dlt_peid");
                String act_dtm = MISDATA.get("dlt_tempid");


                try {
                    if (tc.contentEquals(act_tc) && dpi.contentEquals(act_dpi) && dtm.contentEquals(act_dtm)) {
                        System.out.println("Message is passed with dtm dpi tc");
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The actual and expected  tc , dpi and dtm are matching</b>");
                    } else {
                        System.out.println("Message is not passed with dtm ,dpi & tc parameter");
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The actual and expected  tc , dpi and dtm are Not matching</b>");
                    }
                } catch (NullPointerException e) {
                    System.out.println("Please check the live table...");
                    ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());
        }
    }

    Response response;

    @Test(dataProvider = "getNTEXTSPECIFICROWforDUPLICATEMSG", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void Check_DUPLICATE_MESSAGE_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTNER_ -->" + FunctionName + "</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Duplicate MSG -->" + FunctionName + "</b>");
            String SCTYPE = "";

            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double alrt = Double.parseDouble(ALERT);
            int INALERT = (int) (Math.round(alrt * 100) / 100);
            String AALERT = String.valueOf(INALERT);


            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                response = request.post();
                hitcount++;


            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {


                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);

                //System.out.println("Function name is "+FunctionName);
                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                    System.out.println("Response Object  " + responseid);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                    TestBase.setcurrenttime();
                    Thread.sleep(3000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }


                    String dbstatus = MISDATA.get("statusdesc");


                    try {
                        if (dbstatus.contentEquals("DUPLICATE MESSAGE FOUND")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");
                            //DLR
                            boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                            if (DLRresult) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                                JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                                ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                                boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                                if (dlrrecieved) {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                    Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                    if (DLRDATA.isEmpty()) {
                                        ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                        Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                    }
                                    ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                    ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                                } else {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                                }

                            }

                            ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                            //DLREND

                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } catch (Exception e) {
                        System.out.println("Please check the live table...");
                        ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                    }


                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");

                }

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforMSGIDCHECKNOTNEEDED", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void Check_DUPLICATE_MSGID_NOT_REQUIRED_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTNER_ -->" + FunctionName + "</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Duplicate MSGID not needed -->" + FunctionName + "</b>");
            String SCTYPE = "";

            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double alrt = Double.parseDouble(ALERT);
            int INALERT = (int) (Math.round(alrt * 100) / 100);
            String AALERT = String.valueOf(INALERT);


            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API for <b>" + i + " time");

                response = request.post();
                hitcount++;
                System.out.println("Response Object  " + response.asString());
                ExtentBASETEST.extentReportsDemo("INFO", "<b >Going to hit the API for <b>" + "Response Object  " + response.asString());


            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {


                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);

                //System.out.println("Function name is "+FunctionName);
                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                    System.out.println("Response Object  " + responseid);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                    TestBase.setcurrenttime();
                    Thread.sleep(3000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);


                    String dbstatus = MISDATA.get("statusdesc");


                    try {
                        if (dbstatus.contentEquals("SUBMITTED TO SMSC")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");
                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } catch (Exception e) {
                        System.out.println("Please check the live table...");
                        ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                    }


                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");

                }

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforDUPLICATEMSGID", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void Check_DUPLICATE_MESSAGEID_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String ExpecResponse, String shortflag, String drflag, String msgid, String alertdnd, String D, String F, String IU, String AU, String FB) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTNER_ERRORCASE -->" + FunctionName + "</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Duplicate MSG id error-->" + FunctionName + "</b>");
            String SCTYPE = "";

            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double alrt = Double.parseDouble(ALERT);
            int INALERT = (int) (Math.round(alrt * 100) / 100);
            ALERT = String.valueOf(INALERT);


            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", TO)
                    .param("text", MSG)
                    .param("alert", ALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("msgid", msgid);

            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API for <b>" + i + " time");

                response = request.post();
                hitcount++;
                System.out.println("Response Object  " + response.asString());
                ExtentBASETEST.extentReportsDemo("INFO", "<b >Going to hit the API for <b>" + "Response Object  " + response.asString());


            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {

                double Eresponse = Double.parseDouble(ExpecResponse);
                int Ecode = (int) (Math.round(Eresponse * 100) / 100);
                String ExpecetdNResponse = String.valueOf(Ecode);

                String Acturesponse = response.asString().replaceAll("[\\n\\t ]", "");

                double a = Double.parseDouble(Acturesponse);
                int Acode = (int) (Math.round(a * 100) / 100);
                String ANResponse = String.valueOf(Acode);
                if (Acturesponse.contentEquals(ExpecetdNResponse)) {
                    System.out.println(FunctionName + " Passed");
                    ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Acturesponse + " did not match with Expected Response " + ExpecetdNResponse);

                    Assert.assertEquals(Acturesponse, ExpecetdNResponse, "Response code not matched for " + FunctionName);

                    System.out.println("Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);


                }
            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }


    @Test(dataProvider = "getNTEXTOPTIONALPARAM", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void OPTIONAL_PARAM_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_OPTIONAL_PARAM--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("auth", ob.GetProperty("auth"))
                    .param("brd", ob.GetProperty("brd"))
                    .param("subappid", ob.GetProperty("subappid"))
                    .param("sch", ob.GetProperty("sch"))
                    .param("bsize", ob.GetProperty("bsize"))
                    .param("path", ob.GetProperty("path"))
                    .param("subauth", ob.GetProperty("subauth"))
                    .param("acc", ob.GetProperty("acc"))
                    .param("alertdnd", ob.GetProperty("alertdnd"));

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API with below optional paramters for TEXT : auth , brd , subappid , sch, bsize , path , subauth, acc, alertdnd</b>");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Expected optional parameters values ---> <br> auth : " + ob.GetProperty("auth") + ", <br> brd :" + ob.GetProperty("brd") + ",<br> subappid : " + ob.GetProperty("subappid") + ", <br> subauth : " + ob.GetProperty("subauth") + ",<br> acc : " + ob.GetProperty("acc") + "</b>");


            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);


                TestBase.setcurrenttime();
                Thread.sleep(6000);
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                System.out.println(MISDATA);

                ExtentBASETEST.extentReportsDemo("INFO", "<b>Actual  optional parameters values from DB---> <br>auth : " + MISDATA.get("author") + ",<br> brd :" + MISDATA.get("broadcastname") + ",<br> subappid : " + MISDATA.get("subenterprisename") + ",  <br>subauth : " + MISDATA.get("subauthor") + ", <br> acc : " + MISDATA.get("acc_id") + "</b>");


                if ((ob.GetProperty("auth").contentEquals(MISDATA.get("author"))) && (ob.GetProperty("brd").contentEquals(MISDATA.get("broadcastname"))) && (ob.GetProperty("subappid").contentEquals(MISDATA.get("subenterprisename"))) && (ob.GetProperty("subauth").contentEquals(MISDATA.get("subauthor"))) && (ob.GetProperty("acc").contentEquals(MISDATA.get("acc_id")))) {

                    ExtentBASETEST.extentReportsDemo("PASS", "<b>Actual  optional parameters values from DB is correctly matching with Expected and Request status is <b>" + MISDATA.get("statusdesc"));
//DLR
                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                    //DLREND

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Actual  optional parameters values from DB is not  matching with Expected and Request status is <b> " + MISDATA.get("statusdesc"));


                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getdlttempidNotAllowedCheck", priority = 1, enabled = true, invocationCount = 1)
    public void Check_dlt_tempid_Not_Allowed_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_dlt_tempid_Not_Allowed-> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check dlt_tempid_Not_Allowedfor TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if ("DLT TEMPID NOT FOUND".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The DLT TEMPID NOT FOUND check is successfull</b>");

                        //DLR
                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                        //DLREND
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The DLT TEMPID NOT FOUND  NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTdatafordefaultsender", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void DEFAULT_SENDER_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String Expected_sender) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTENER_Test started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the OPEN CLI Yes case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response id " + responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }
                //
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    // String actualsender=jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (Expected_sender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Recieved sender is " + recievedsender + "  matching with expected sender " + Expected_sender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "   Recieved sender is " + recievedsender + " NOT matching with expected sender " + Expected_sender);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());


        }

    }

    @Test(dataProvider = "getNTEXTSOIPDATA", priority = 1, enabled = true, invocationCount = 1)
    public void Check_SOIP_CASES_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String ExpectedStatusdesc, String ExpectedSMSC) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_SOIP-> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check" + FunctionName + " </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                String actualsmsc = MISDATA.get("smscname");
                String actualstatusdesc = MISDATA.get("statusdesc");
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if ((ExpectedStatusdesc.contentEquals(actualstatusdesc)) && actualsmsc.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTSPECIFICROWforIvrvFlag", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void Ivrvflag_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
// In the case of IVrvflag clould smsc needed.
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_Listener started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("ivrvflag", "1");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Ivrvflag case SMSC selection for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }
                JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                try {
                    if (jsonbody.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("ERROR ", "The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                } catch (Exception e) {

                    ExtentBASETEST.extentReportsDemo("ERROR ", e.toString());

                }

                String smsc = String.valueOf(jsonbody.get("sn"));
                if (smsc.contains("-cloud")) {

                    ExtentBASETEST.extentReportsDemo("PASS", "Request " + responseid + " is successfully submitted to SMSC & <b> request  processed through cloud connectivity , smsc selected is " + smsc + "</b>");


                } else if (smsc.contains("NOT SUBMITTED TO SMSC")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + " Request has not been submitted to SMSC");
                    Assert.assertTrue(false, "FOR Request " + responseid + " SMSC is not matched for Ivrv flag request---> " + smsc);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + "  Cloud SMSC is not selected for Ivrv flag  request---> " + smsc);
                    Assert.assertTrue(false, "FOR Request " + responseid + " Cloud SMSC is not selected for Ivrv flag request--->" + smsc);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforIvrvFlag() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 16, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSOIPDATA() {

        Object data[][] = ExcelUtils.getTestData("NTEXT_SOIP_TEST", 0, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTdatafordefaultsender() {
        Object data[][] = ExcelUtils.getTestData("NTEXT_DEFAULT_SENDER_TEST", 4, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTDPITCCheck() {
        Object data[][] = ExcelUtils.getTestData("NTEXTOPENTEMPLATE", 1, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTdetails() {
        Object data[][] = ExcelUtils.getTestData("NTEXTdataNegative", 0, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTdetailsPositive() {
        Object data[][] = ExcelUtils.getTestData("NTEXTTemplatecases", 0, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforTilta() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 5, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforshortening() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 6, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforinsufficentcredit() {

        Object data[][] = ExcelUtils.getTestData("NTEXT_INSUFFICIENT_CREDIT", 0, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforInternational() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 8, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforCLIYES() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 9, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTOPTIONALPARAM() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 12, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforCLINO() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 10, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforTemplateCONVERSION() {

        Object data[][] = ExcelUtils.getTestData("NTEXTTEMPLATECONVERSTION", 1, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforINVALIDMESSAGE() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 11, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSMSCOUNTDATA() {
        Object data[][] = ExcelUtils.getTestData("NTEXTSMSCOUNT", 0, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforDUPLICATEMSGID() {

        Object data[][] = ExcelUtils.getTestData("NTEXTdataNegative", 11, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforDUPLICATEMSG() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 13, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getdlttempidNotAllowedCheck() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 14, "TestData_TEXT.xlsx");

        return data;
    }


    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforMSGIDCHECKNOTNEEDED() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 15, "TestData_TEXT.xlsx");
        return data;
    }

    @Test(dataProvider = "getTextNegativedataLOG", priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void Check_ERRORCASEINLOG_Text(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String shortflag, String drflag, String msgid, String alertdnd, String D, String f, String iu, String au, String fb,String Expectedmsg) {
        if (!FunctionName.contentEquals("Test_DuplicateMessageID")) {
            ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_Listener_ERRORCASE -->" + FunctionName + "</b>");
            try {
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Negative case-->" + FunctionName + "</b>");
                String SCTYPE = "";
                if (Contenttype.contentEquals("BLK")) {

                } else {
                    double ctype = Double.parseDouble(Contenttype);
                    int ictype = (int) (Math.round(ctype * 100) / 100);
                    SCTYPE = String.valueOf(ictype);
                }

                if (APPID.contentEquals("BLK")) {
                    APPID = "";
                }
                if (UserID.contentEquals("BLK")) {
                    UserID = "";
                }
                if (Passd.contentEquals("BLK")) {
                    Passd = "";
                }
                if (ALERT.contentEquals("BLK")) {
                    ALERT = "";
                } else {
                    double alrt = Double.parseDouble(ALERT);
                    int INALERT = (int) (Math.round(alrt * 100) / 100);
                    ALERT = String.valueOf(INALERT);
                }
                if (INTFLAG.contentEquals("BLK")) {
                    INTFLAG = "";
                }
                if (MSG.contentEquals("BLK")) {
                    MSG = "";
                }
                if (FROM.contentEquals("BLK")) {
                    FROM = "";
                }
                if (TO.contentEquals("BLK")) {
                    TO = "";
                }
                if (shortflag.contentEquals("BLK")) {
                    shortflag = "";
                } else {
                    double shortflg = Double.parseDouble(shortflag);
                    int SHORTFLAG = (int) (Math.round(shortflg * 100) / 100);
                    shortflag = String.valueOf(SHORTFLAG);
                }

                if (SELFID.contentEquals("FALSE")) {
                    msgid = "";
                }
                if (msgid.contentEquals("BLK")) {
                    msgid = "";
                }
                if (drflag.contentEquals("BLK")) {
                    drflag = "";
                } else {
                    double DRflg = Double.parseDouble(drflag);
                    int DRFLAG = (int) (Math.round(DRflg * 100) / 100);
                    drflag = String.valueOf(DRFLAG);
                }
                if (alertdnd.contentEquals("BLK")) {
                    alertdnd = "";
                } else {
                    double alerdndflg = Double.parseDouble(alertdnd);
                    int DNDFLAG = (int) (Math.round(alerdndflg * 100) / 100);
                    alertdnd = String.valueOf(DNDFLAG);
                }
                if (D.contentEquals("BLK")) {
                    D = "";
                }

                if (f.contentEquals("BLK")) {
                    f = "";
                } else {
                    double ff = Double.parseDouble(f);
                    int fff = (int) (Math.round(ff * 100) / 100);
                    f = String.valueOf(fff);
                }

                if (iu.contentEquals("BLK")) {
                    iu = "";
                }
                if (au.contentEquals("BLK")) {
                    au = "";
                }
                if (fb.contentEquals("BLK")) {
                    fb = "";
                }
                RequestSpecification request = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "9918702626")
                        .param("text", MSG)
                        .param("alert", ALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("s", shortflag)
                        .param("dr", drflag)
                        .param("msgid", msgid)
                        .param("alertdnd", alertdnd)
                        .param("d", D)
                        .param("f", f)
                        .param("iu", iu)
                        .param("au", au)
                        .param("fb", fb);

                Response response = request.post();
                System.out.println("Response Object  " + response.asString());

                String responseid = response.asString().replaceAll("[\\n\\t ]", "");



            /*double a = Double.parseDouble(Acturesponse);
            int Acode = (int) (Math.round(a * 100) / 100);
            String ANResponse = String.valueOf(Acode); */

                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the postive case for TEXT </b>");

                System.out.println("Request Object  " + request);
                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);
                if (statusCode == 200) {


                    System.out.println("Request is accepted");

                    //PROCESSOR LOG CHECK
                    if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                        }
                    }

                    //

                    boolean result = LinuxLogReader.CheckLOGERRORMESSAGE(Expectedmsg, responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), false, "DUMMY", ob.GetProperty("commonloglocation205"),ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (result) {
                        ExtentBASETEST.extentReportsDemo("PASS", FunctionName + " TEST  PASSED for " + responseid + "<br> below message found in log " + Expectedmsg);
                        //DLR
                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //DLREND

                    } else {

                    }


                }
            } catch (Exception e) {
                ExtentBASETEST.extentReportsDemo("INFO", e.toString());
                System.out.println(e);

            }
        }

    }
    @DataProvider
    public Object[][] getTextNegativedataLOG() {

        Object data[][] = ExcelUtils.getTestData("dataNegativeLOG", 0, "TestData_TEXT.xlsx");
        return data;


    }


    @Test(dataProvider = "getRCSTESTDATA", priority = 1,  enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_NTEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470
            Response response= null;

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7906665842")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("s","0");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the RCS component </b>");
            if(FunctionName.contains("UNICODE"))
            {
                 response = request.get();
            }else {
                 response = request.post();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String RCSRECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));

                        //ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //



                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {
                    if(MISDATA.get("templateid").isEmpty())
                    { ExtentBASETEST.extentReportsDemo("FAIL", "Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());
                     Assert.assertTrue(false,"Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());

                    }else {
                        ExtentBASETEST.extentReportsDemo("PASS", " <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());
                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(submitstatus.contentEquals("submitted"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        DLRCHECK = true;
                        joinid=MISDATA.get("joinid");
                    }
                    else {
                        ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                        Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @DataProvider
    public Object[][] getTEXTSPECIFICROWforRCSCAPABILITY() {

        Object data[][] = ExcelUtils.getTestData("RCSCAPABILITY", 0, "TestData_NTEXT.xlsx");

        return data;
    }
    @DataProvider
    public Object[][] getRCSTESTDATA() {

        Object data[][] = ExcelUtils.getTestData("RCS_TEST_DATA", 0, "TestData_NTEXT.xlsx");

        return data;
    }


    @Test(dataProvider = "getTEXTSPECIFICROWforRCSCAPABILITY", priority = 1,  enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_CAPABILITY_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,String capability) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_NTEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470
            String ph[]=TO.split("X");
            System.out.println("This is mobile no from excel sheet "+ph[1]);
            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", ph[1])
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("s","0");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the RCS CAPABILITY CHECK FOR PHHONENUMBER </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String RCSRECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(5000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                       if(capability.contentEquals("YES")) {

                           if (responseString.contains("RCS capable mobile list -> [+91" + ph[1] + "]")) {
                               ExtentBASETEST.extentReportsDemo("PASS", "<b> Capability check is passed "+"RCS capable mobile list -> [+91" + ph[1] + "]");

                           } else {
                               ExtentBASETEST.extentReportsDemo("FAIL", "<b> Capability check is NOT Passed for number</b>");

                           }
                       }


//RCS capable mobile list -> [+919971498470]

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //



                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {


                    ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(capability.contentEquals("YES")) {
                        if (submitstatus.contentEquals("submitted")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                            DLRCHECK = true;
                            joinid = MISDATA.get("joinid");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);
                            Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);

                        }
                    } else if(capability.contentEquals("NO"))
                    {
                        if (submitstatus.contentEquals("notCapable") ) {
                            ExtentBASETEST.extentReportsDemo("PASS", " DB has updated with status "+"<b>"+submitstatus+"</b>");
                         String expectedQname="RCS_NOT_CAPABLE_+91" + ph[1];
                            ExtentBASETEST.extentReportsDemo("INFO", " <b> Now going to check not capable redis Q..</b>");

                          String Qdata=JedisQueueReader.GetRedisdata(ob.GetProperty("redis_server_ip"),ob.GetProperty("redis_server_user"),ob.GetProperty("redis_server_pass"),ob.GetProperty("redis_server_host"),ob.GetProperty("redis_server_port"),ob.GetProperty("redis_host_pass"),expectedQname);
                          //  ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);


                  if(Qdata.contentEquals("1"))
                       {
                           ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);

                       }
                  else
                  {
                      ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has NOT  been set..Please check Redis property and investigate Manually ");


                  }
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " NOT CAPABLE CHECK IS FAILED AND RCS status in DB is "+"<b>"+submitstatus+"</b>");

                        }
                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTDARSDATA", priority = 1, enabled = true, invocationCount = 1)
    public void Check_DARS_CASES_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,  String ExpectedSMSC) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_DARS-> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
            //917838269548

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", TO)
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check" + FunctionName + " </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                String actualsmsc = MISDATA.get("smscname");
           if(actualsmsc==null)
           {
               actualsmsc = "BLK";
               ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
               Assert.fail("<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
           }
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if (ExpectedSMSC.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> <font color=green> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b> </font>");
                        ExtentBASETEST.extentReportsDemo("INFO", "<font color=blue>The MIS data for the same is below --> <br> " + MISDATA+"</font>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> <font color=red>Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b></font>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @DataProvider
    public Object[][] getNTEXTDARSDATA() {

        Object data[][] = ExcelUtils.getTestData("DARS", 0, "TestData_TEXT.xlsx");

        return data;
    }

    @Test(dataProvider = "getTEXTSPECIFICROWforWA", priority = 1, enabled= false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_WA_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_NTEXT_BASE_URI") + " " + "<b>TEXTLISTNER_WA CHECK--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API for WA </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String WARECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //WA COMPONENT  LOG CHECK
                if (ob.GetProperty("checkWAlog").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), false, "dummy", ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 207 WA ROUTER </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 207 WA server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 207 WA SERVER</b>");
                    }
                }

                //


                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String WADLRTABLENAME = Livetablename.get("WADLRTABLENAME");
                WARECIEVRTABLENAME = Livetablename.get("WARECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROM_WA_RECIEVERTABLE(500, responseid, WARECIEVRTABLENAME);
                String joinid = "";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {


                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus = MISDATA.get("statusdesc");
                    if (submitstatus.contentEquals("submitted")) {
                        ExtentBASETEST.extentReportsDemo("INFO", " THE WA REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO WA");
                        DLRCHECK = true;
                        joinid = MISDATA.get("joinid");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", " THE WA REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO WA and actual status is " + submitstatus);
                        Assert.fail("THE WA REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO WA and actual status is " + submitstatus);

                    }
                }
                Thread.sleep(10000);

                if (DLRCHECK) {
                    Map<String, String> DLRDATA = SQLPOOL.GETWADATAFROMDLRLIVETABLE(500, joinid, WADLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The WA DLRDATA could not be pulled from DB ");
                    } else {
                        if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully recieved and the current status of WA message is  <b>SENT, DELIVERED, READ</b>");
                        } else if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully recieved and the current status of WA message is  <b>SENT, DELIVERED </b>");
                        } else if (DLRDATA.containsValue("sent") && !DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully recieved and the current status of WA message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "WA_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }

    @DataProvider
    public Object[][] getTEXTSPECIFICROWforWA() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 18, "TestData_NTEXT.xlsx");

        return data;

    }

    @Test(dataProvider = "getNTEXTSPECIFICROWforJUM_10326", priority = 1,  enabled = true, invocationCount = 1)
    public void Check_JUM_10326_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String contertedtext) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_JUM_10326--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check MSG conversion for TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                System.out.println("this is actual  msg  before conversion" + MSG);
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg  before conversion <b>" + MSG + "</b>");

                System.out.println("this is expected converted msg from Excel" + contertedtext);
                ExtentBASETEST.extentReportsDemo("INFO", "this is expected converted msg from Excel <b>" + contertedtext + "</b>");

                System.out.println("this is actual converted msg from live sql table" + MISDATA.get("messagetext"));
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("messagetext") + "</b>");
                try {
                    if (contertedtext.contentEquals(MISDATA.get("messagetext"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The msg conversion is successfull</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The msg conversion is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforJUM_10326() {

        Object data[][] = ExcelUtils.getTestData("JUM_10326", 0, "TestData_TEXT.xlsx");

        return data;
    }



    @Test(dataProvider = "getCredencedata", priority = 1,  enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_CREDENCE_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String credenceCHECK) {
        try {
            Thread.sleep(10000);
        } catch (Exception e) {

        }

        String ph[]=TO.split("X");
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_NTEXT_BASE_URI")+" "+"<b>TEXTLISTNER_CREDENCE CHECK--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", ph[1])
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("s","0");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the credence system forwarding </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);


                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                             } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                Thread.sleep(5000);
//test

                if (true) {


                    String credendedata=JedisQueueReader.Getcredenceredisdata(responseid);
                    if(credendedata.isEmpty()&& credenceCHECK.contentEquals("YES"))
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The data is not found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+responseid+" but is was expected to be in Credence Q</b>");

                    }
                    else if(credendedata.isEmpty()&& credenceCHECK.contentEquals("NO"))
                    {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The data is not found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+responseid+" AND  is was ALSO NOT expected to be in Credence Q</b>");

                    }
                    else if((!credendedata.isEmpty()) && credenceCHECK.contentEquals("NO"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b> CREDENCE DATA IS---></b>"+credendedata);

                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The data  is  found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+responseid+" but is was NOT expected to be in Credence Q</b>");

                    }

                    else if((!credendedata.isEmpty()) && credenceCHECK.contentEquals("YES"))
                    {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST HAS BEEN  FORWARDED TO CREDENCE ,DATA IS---></b>"+credendedata);

                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The data is found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+responseid+" AND  is was ALSO  expected to be in Credence Q</b>");

                    }



                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON SMS ROUTER COMPONENT</b>");
                }







            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @DataProvider
    public Object[][] getCredencedata() {

        Object data[][] = ExcelUtils.getTestData("JUM-5768_CREDENCE", 0, "TestData_TEXT.xlsx");

        return data;

    }
}








