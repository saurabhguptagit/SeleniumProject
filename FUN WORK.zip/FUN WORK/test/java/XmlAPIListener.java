import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.util.Arrays;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class XmlAPIListener {
    Response response;
    Map<String, String> requestHeaders = new HashMap<>();

    Map<String, String> ErrorcodesMAP = new HashMap<>();
    String sheetName = "data";
    TestBase ob;

    //test
    @BeforeTest

    public void setHeader() {
        requestHeaders.put("content-type", "application/xml");


    }

    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
        // ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST FOR XMLLanguageAPI LISTNERS</b></h5>");
        String env = ob.GetProperty("Environment");
        if (env.contentEquals("QA_AWS")) {
            RestAssured.baseURI = ob.GetProperty("BASEURI_XmlAPIListener");

        } else if (env.contentEquals("QA_142_Direct")) {
            RestAssured.baseURI = ob.GetProperty("BASEURI_XmlAPIListener");
        } else {
            throw new Exception("Envioenment name in Property is not valid");
        }

    }
    public String ADDXMLSTR(File XMLDataInFile) throws Exception
    {
        FileReader read=new FileReader(XMLDataInFile);

        String xmldata="";
        int i;
        while ((i = read.read()) != -1)
        {
            xmldata=xmldata+(char)i;
        }
        xmldata="xmlStr="+xmldata;

        System.out.println("data "+ xmldata);
        return xmldata;
    }

    @DataProvider
    public Object[][] getXMLTemplatedata() {
        Object data[][] = ExcelUtils.getTestData("Templatecases", 0, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }
    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLTemplatedata")
    public void Check_Templates_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner_TEMPLATEMATCHING--> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            //RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
			
			


            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));


           
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") ;//+ "-1";
                System.out.println(response_id);
                boolean DLRCHECK = false;
                String DLRLivetablename = "";
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), true, "TestMSG", ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), true, MSG, ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));


                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + response_id + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(2000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);
                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        DLRCHECK = true;

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    }
                    System.out.println(MISDATA);

                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                        DLRLivetablename = Livetablename.get("DLRTABLENAME");
                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            DLRCHECK = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }

                }


                //DLR
                if (DLRCHECK) {
                    boolean result = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                    System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + result);

                    if (result) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    } else {
                        System.out.println("DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }

                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }

                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }


                    }
                }
                ExtentBASETEST.extentReportsDemo("INFO", "DLR TEST EXECUTED");

                //END

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }



    @Test(priority = 2, enabled = true, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSMSCOUNTdata")
    public void Check_SMSCOUNT_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String smscount) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner_SMSCOUNT MATCHING--> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the SMSCOUNT matching<b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }
            double b = Double.parseDouble(smscount);
            int SMSCOUNTroundOff = (int) (Math.round(b * 100) / 100);
            System.out.println("Expected sms count is " + SMSCOUNTroundOff);


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                Thread.sleep(2000);

                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), true, "TestMSG", ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), true, MSG, ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);

                    if(MISDATA.isEmpty())
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                    }
                    System.out.println(MISDATA);
                    // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                    if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                                ExtentBASETEST.extentReportsDemo("PASS", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                            } else {
                                ExtentBASETEST.extentReportsDemo("FAIL", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                            }
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");

                            Thread.sleep(Retry_Waiting_period);

                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }


                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @Test(priority = 1, enabled = false, dataProvider = "getXMLdataNegative", invocationCount = SetandGetGlobalVariable.count)
    public void Check_Negative_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String ExpecResponse, String language, String shortflag, String drflag, String msgid, String alertdnd) {
        if (!FunctionName.contentEquals("Test_DuplicateMessageID")) {
            ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>ERRORCase_XmlAPIListener " + FunctionName + "</b>");

            try {
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Negative case-->" + FunctionName + "</b>");
                // Specify the base URL to the RESTful web service


                XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, language, "XmlLangaugeAPIListenerNegative.xml", msgid);

                double Eresponse = Double.parseDouble(ExpecResponse);
                int Ecode = (int) (Math.round(Eresponse * 100) / 100);
                String ExpecetdNResponse = String.valueOf(Ecode);

                File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListenerNegative.xml");
                RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

                RestAssured.given().headers(requestHeaders);

                Response response = request.post();

                if (UserID.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("userid", "defaultvalue", "XmlLangaugeAPIListenerNegative.xml");
                }
                if (Passd.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("pass", "defaultvalue", "XmlLangaugeAPIListenerNegative.xml");
                }

                if (APPID.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("appid", "defaultvalue", "XmlLangaugeAPIListenerNegative.xml");
                }

                if (Contenttype.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("content-type", "defaultvalue", "XmlLangaugeAPIListenerNegative.xml");
                }
                if (FROM.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("from", "defaultvalue", "XmlLangaugeAPIListenerNegative.xml");
                }
                if (ALERT.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("alert", "1", "XmlLangaugeAPIListenerNegative.xml");
                }

                if (FunctionName.contains("MESSAGEID_TAGMISS")) {
                    XML_OPERATIONS.ADD_NODE("msgid", "defaultvalue", "XmlLangaugeAPIListenerNegative.xml");
                }
                int statusCode = response.getStatusCode();

                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    System.out.println(statusCode);
                    // System.out.println(response.body().asString());
                    String temp = response.body().asString();
                    XmlPath xmlPath = new XmlPath(temp);
                    try {
                        String Errorcode = xmlPath.get("push.error.code");
                        if (Errorcode.contentEquals(ExpecetdNResponse)) {
                            System.out.println(FunctionName + " Passed");
                            ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Errorcode + " matched with Expected Response " + ExpecetdNResponse);
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Errorcode + " did not match with Expected Response " + ExpecetdNResponse);

                            Assert.assertEquals(Errorcode, ExpecetdNResponse, "Response code not matched for " + FunctionName);

                            System.out.println("Actual response " + Errorcode + " matched with Expected Response " + ExpecetdNResponse);


                        }
                    }catch(Exception e)
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", "Response id "+ xmlPath.get("push.response-id")+" generated instead off getting Error code for Test " + FunctionName);
                    }

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");
                }

            } catch (Exception e) {
                ExtentBASETEST.extentReportsDemo("INFO", e.toString());
                Assert.fail(e.toString());

            }
        }
    }


    @DataProvider
    public Object[][] getXMLdataNegative() {
        Object data[][] = ExcelUtils.getTestData("DataNegative", 0, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }

    @Test(dataProvider = "getXmlLangaugeAPIListenerforINVALIDMESSAGE", priority = 1, enabled = false, invocationCount = 1)
    public void Check_INVALID_MESSAGE_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>getXmlAPIListenerforINVALIDMESSAGE--> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Tilta handling  <b>");
            Response response = (Response) request.post();

            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());
                try {
                    if ("INVALID MESSAGE".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID msg check is successfull</b>");

                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID msg check NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforINVALIDMESSAGE() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 11, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;

    }

    @Test(dataProvider = "getXmlLangaugeAPIListenerforTilta", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void SPECIALCHAR_TILTA_HANDLING_XMLAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner--> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Tilta handling  <b>");
            Response response = (Response) request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);

                Thread.sleep(6000);
                TestBase.setcurrenttime();

                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);
                System.out.println(MISDATA);
                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());

                String actualmsg = ob.GetProperty("SPECIALCHAR_TILTA_TEXT");

                String newLineExpectedmsg = actualmsg.replace('~', '\n');

                String newLineActualmsg = MISDATA.get("messagetext");
                if (newLineExpectedmsg.contentEquals(newLineActualmsg)) {
                    String aar[] = newLineActualmsg.split("\n");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Replaced text with new line ---><b>" + Arrays.deepToString(aar) + "</b>");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Text with ~ char ---><b>" + actualmsg + "</b>");
                    ExtentBASETEST.extentReportsDemo("PASS", " <b>The ~  is successfully  converted into new line charracter </b>");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The ~ in the Actual message " + newLineActualmsg + " is not converted into new line charracter ....Please see Expected text --->" + newLineExpectedmsg);

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }
        } catch (Exception var25) {
            ExtentBASETEST.extentReportsDemo("FAIL", var25.toString());
            Assert.fail(var25.toString());
        }

    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforTilta() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 5, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTdatafordefaultsender() {
        Object data[][] = ExcelUtils.getTestData("DEFAULT_SENDER_TEST", 0, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getNTEXTdatafordefaultsender")
    public void DEFAULT_SENDER_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String Expected_sender) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner_Default sender MATCHING--> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the SMSCOUNT matching<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), true, "TestMSG", ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), true, MSG, ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    // String actualsender=jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (Expected_sender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + response_id + "  Recieved sender is " + recievedsender + "  matching with expected sender " + Expected_sender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + response_id + "   Recieved sender is " + recievedsender + " NOT matching with expected sender " + Expected_sender);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + response_id + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + response_id + "  is not sent to SMSC");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getSOIPDATA() {

        Object data[][] = ExcelUtils.getTestData("SOIP_TEST", 0, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;
    }

    @Test(dataProvider = "getSOIPDATA", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_SOIP_CASES_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String ExpectedStatusdesc, String ExpectedSMSC) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner_SOIP Cases--> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Tilta handling  <b>");
            Response response = (Response) request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                Thread.sleep(2000);
                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);
                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                String actualsmsc = MISDATA.get("smscname");
                String actualstatusdesc = MISDATA.get("statusdesc");
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if ((ExpectedStatusdesc.contentEquals(actualstatusdesc)) && actualsmsc.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }
        } catch (Exception var25) {
            ExtentBASETEST.extentReportsDemo("FAIL", var25.toString());
            Assert.fail(var25.toString());
        }

    }


    @Test(dataProvider = "getSPECIFICROWforTemplateCONVERSION", priority = 1, enabled = false, invocationCount = 1)
    public void Check_Templateconversion_XMLAPILISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String contertedtext) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XMLAPI_TEMPLATECONVERSION--> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template conversion  <b>");
            Response response = (Response) request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + response_id + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                System.out.println("this is actual  msg  before conversion" + MSG);
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg  before conversion <b>" + MSG + "</b>");

                System.out.println("this is expected converted msg from Excel" + contertedtext);
                ExtentBASETEST.extentReportsDemo("INFO", "this is expected converted msg from Excel <b>" + contertedtext + "</b>");

                System.out.println("this is actual converted msg from live sql table" + MISDATA.get("messagetext"));
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("messagetext") + "</b>");
                try {
                    if (contertedtext.contentEquals(MISDATA.get("messagetext"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The msg conversion is successfull</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The msg conversion is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @DataProvider
    public Object[][] getSPECIFICROWforTemplateCONVERSION() {

        Object data[][] = ExcelUtils.getTestData("TEMPLATECONVERSTION", 0, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;
    }


    @DataProvider
    public Object[][] getSPECIFICROWforshortening() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 6, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;
    }

    @Test(dataProvider = "getSPECIFICROWforshortening", priority = 1, enabled = false, invocationCount = 3)
    public void Check_SHORTENING_XMLAPILISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListener-SHORTENING CHECK--> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            XML_OPERATIONS.ADD_NODE("shorten", "1", "XmlLangaugeAPIListener.xml");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the shortening <b>");
            Response response = (Response) request.post();
            XML_OPERATIONS.REMOVE_NODE("shorten", "XmlLangaugeAPIListener.xml");
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + response_id);

                System.out.println("Response Object  " + response_id);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);


                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                boolean shortresult = SQLPOOL.checkshortstageDB(response_id, PushRecieverLivetablename, ShortstageLiveBeetablename);

                if (shortresult) {
                    System.out.println("Shortening passed");
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    ExtentBASETEST.extentReportsDemo("PASS", "SHORTENING PASSED");
                    Assert.assertTrue(shortresult, "Shortening passed");
                    //DLR

                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                    //ENDDLR
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "SHORTENING FAILED");
                    Assert.assertTrue(shortresult, "Shortening Failed");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }

    @Test(dataProvider = "getXmlLangaugeAPIListenerforTOblank", priority = 1, enabled = false, invocationCount = 1)
    public void Check_TO_BLANK_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>getXmlAPIListenerforTOBlank-> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            XML_OPERATIONS.ADD_ATTRIBUTE("msisdn", "", "XmlLangaugeAPIListener.xml");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            Response response = (Response) request.post();

            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());
                try {
                    if ("INVALID MSISDN".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID MSISDN check is successfull</b>");

                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID MSISDN check is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforTOblank() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 17, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;

    }

    @Test(dataProvider = "getXmlAPIListenerforTOTAGMISS", priority = 1, enabled = false, invocationCount = 1)
    public void ACheck_TO_TAGMISS_XmlLangaugeAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>getXmlAPIListenerforTOBlank-> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            Response response = (Response) request.post();
            XML_OPERATIONS.ADD_ATTRIBUTE("msisdn", "7838787657", "XmlLangaugeAPIListener.xml");

            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());
                try {
                    if ("INVALID MSISDN".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID MSISDN check is successfull</b>");
                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID MSISDN check is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforTOTAGMISS() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 18, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;

    }

    @Test(dataProvider = "getXmlAPIListenerforMSGblank", priority = 1, enabled = false, invocationCount = 1)
    public void Check_MSG_BLANK_XmlLangaugeAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>getXmlAPIListenerforMSGBlank-> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            XML_OPERATIONS.ADD_ATTRIBUTE("msg", "", "XmlLangaugeAPIListener.xml");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            Response response = (Response) request.post();

            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());
                try {
                    if ("INVALID MESSAGE".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID MESSAGE check is successfull</b>");

                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID MESSAGE check is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforMSGblank() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 19, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;

    }

    @Test(dataProvider = "getXmlAPIListenerforMSGMISS", priority = 1, enabled = false, invocationCount = 1)
    public void Check_MSG_TAGMISS_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>getXmlAPIListenerforMSGBlank-> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            Response response = (Response) request.post();

            XML_OPERATIONS.ADD_ATTRIBUTE("msg", "defaulttext", "XmlLangaugeAPIListener.xml");

            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());
                try {
                    if ("INVALID MESSAGE".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID MESSAGE check is successfull</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID MESSAGE check is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforMSGMISS() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 20, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;

    }


    @Test(dataProvider = "getXmlLangaugeAPIListenerforSPECIFICROWforinsufficentcredit", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)

    public void INSUFFICIENT_CREDIT_XMLAPILISTENER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {


        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListenerTest started--> " + FunctionName + "</b>");

        try {

            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");

            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(this.requestHeaders);

            Response response = (Response) request.post();

            System.out.println("Request Object  " + request);

            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Insufficent credit  case for XML  API  </b>");

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                boolean DLRCHECKFLAG = false;
                System.out.println(statusCode);

                System.out.println(response.body().asString());

                String temp = response.body().asString();

                XmlPath xmlPath = new XmlPath(temp);

                String response_id = xmlPath.get("push.response-id") + "-1";
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), true, "TestMSG", ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //
                boolean result = LinuxLogReader.CheckPrepaidbalance(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));

                if (result) {
                    DLRCHECKFLAG = true;
                    ExtentBASETEST.extentReportsDemo("PASS", FunctionName + " PASSED for " + response_id);

                } else {

                    ExtentBASETEST.extentReportsDemo("FAIL", FunctionName + " FAILED for " + response_id);


                }
                if (DLRCHECKFLAG) {
                    TestBase.setcurrenttime();
                    Thread.sleep(1000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                }

            } else {

                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");

                Assert.fail("Status code is not success");


            }


        } catch (Exception e) {

            ExtentBASETEST.extentReportsDemo("INFO", e.toString());

            //Assert.fail(e.toString());


        }

    }

    @DataProvider

    public Object[][] getXmlLangaugeAPIListenerforSPECIFICROWforinsufficentcredit() {

        Object data[][] = ExcelUtils.getTestData("INSUFFICIENT_CREDIT", 0, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }

    @Test(dataProvider = "getXmlLangaugeAPIListenerforgetdlttempidNotAllowedCheck", priority = 1, enabled = false, invocationCount = 1)

    public void Check_dlt_tempid_Not_Allowed_XMLAPILISTENER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {


        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XMLAPILISTENER_dlt_tempid_Not_Allowed-> " + FunctionName + "</b>");

        try {


            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");


            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");

            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(this.requestHeaders);

            Response response = (Response) request.post();

            System.out.println("Request Object  " + request);

            int statusCode = response.getStatusCode();


            System.out.println("Status code  " + statusCode);


            if (Language.contentEquals("BLK")) {

                Language = "";

            }


            ExtentBASETEST.extentReportsDemo("INFO", "<b>Goi`ng to hit the API to check dlt_tempid_Not_Allowedfor XML language listner </b>");


            try {

                Thread.sleep(2000);

            } catch (Exception e) {


            }

            System.out.println("Request Object  " + request);

            // int statusCode = response.getStatusCode();


            System.out.println("Status code  " + statusCode);


            //System.out.println("Function name is "+FunctionName);


            if (statusCode == 200) {

                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);

                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);

                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + response_id + "</b>");


                TestBase.setcurrenttime();

                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();

                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, response_id, PushRecieverLivetablename);
                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");

                try {

                    if ("TEMPLATE NOT FOUND AT ACL".contentEquals(MISDATA.get("statusdesc"))) {

                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The DLT TEMPID NOT FOUND check is successfull</b>");

                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The DLT TEMPID NOT FOUND  NOT  successfull</b>");

                    }

                } catch (NullPointerException e) {

                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");

                }


            } else {

                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");

                Assert.fail("Status code is not success");


            }


        } catch (Exception e) {

            ExtentBASETEST.extentReportsDemo("INFO", e.toString());

            //Assert.fail(e.toString());


        }

    }


    @DataProvider

    public Object[][] getXmlLangaugeAPIListenerforgetdlttempidNotAllowedCheck() {


        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 14, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");


        return data;


    }


    @Test(dataProvider = "getSPECIFICROWforDUPLICATEMSGID", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void DUPLICATEMSGID_HANDLING_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String ExpecResponse, String Language, String shortflag, String drflag, String msgid, String alertdnd) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>Start XML  API-> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Duplicate MSG id error--> <b>");


            int hitcount = 0;

            for (int i = 1; i < 3; i++) {

                ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API for <b>" + i + " time");

                response = (Response) request.post();
                hitcount++;
                System.out.println("Response Object  " + response.asString());
                ExtentBASETEST.extentReportsDemo("INFO", "<b >Going to hit the API for <b>" + "Response Object  " + response.asString());


            }

            System.out.println("HIT count  " + hitcount);


            if (hitcount == 2) {
                int statusCode = response.getStatusCode();
                double Eresponse = Double.parseDouble(ExpecResponse);
                int Ecode = (int) (Math.round(Eresponse * 100) / 100);
                String ExpecetdNResponse = String.valueOf(Ecode);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                // System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String Acturesponse = xmlPath.get("push.error.code");

                double a = Double.parseDouble(Acturesponse);
                int Acode = (int) (Math.round(a * 100) / 100);
                String ANResponse = String.valueOf(Acode);
                if (Acturesponse.contentEquals(ExpecetdNResponse)) {
                    System.out.println(FunctionName + " Passed");
                    ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Acturesponse + " did not match with Expected Response " + ExpecetdNResponse);

                    Assert.assertEquals(Acturesponse, ExpecetdNResponse, "Response code not matched for " + FunctionName);

                    System.out.println("Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);


                }
            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());
        }

    }

    @DataProvider
    public Object[][] getSPECIFICROWforDUPLICATEMSGID() {

        Object data[][] = ExcelUtils.getTestData("DataNegative", 19, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }


    @Test(dataProvider = "getSPECIFICROWforMSGIDCHECKNOTNEEDED", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void DUPLICATEMSGID_NOTNEEDED_HANDLING_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>Start XML  API-> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Duplicate MSG Check not needed--> <b>");


            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API for <b>" + i + " time");

                response = (Response) request.post();
                hitcount++;
                System.out.println("Response Object  " + response.asString());
                ExtentBASETEST.extentReportsDemo("INFO", "<b >Going to hit the API for <b>" + "Response Object  " + response.asString());


            }

            System.out.println("HIT count  " + hitcount);


            if (hitcount == 2) {
                int statusCode = response.getStatusCode();

                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    System.out.println(statusCode);
                    System.out.println(response.body().asString());
                    String temp = response.body().asString();
                    XmlPath xmlPath = new XmlPath(temp);
                    String response_id = xmlPath.get("push.response-id") + "-1";
                    System.out.println(response_id);


                    System.out.println("Response Object  " + response_id);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + response_id + "</b>");

                    TestBase.setcurrenttime();
                    Thread.sleep(3000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, response_id, PushRecieverLivetablename);

                    if(MISDATA.isEmpty())
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                    }
                    String dbstatus = MISDATA.get("statusdesc");


                    try {
                        if (dbstatus.contentEquals("SUBMITTED TO SMSC")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");
                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } catch (Exception e) {
                        System.out.println("Please check the live table...");
                        ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                    }


                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");

                }

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());
        }

    }


    @DataProvider
    public Object[][] getSPECIFICROWforMSGIDCHECKNOTNEEDED() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 15, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforInternational")
    public void International_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListenerinternational.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListenerinternational.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the International Feature <b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");


                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), true, "TestMSG", ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //
                JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                try {
                    if (jsonbody.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("ERROR ", "The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                } catch (Exception e) {

                    ExtentBASETEST.extentReportsDemo("ERROR ", e.toString());

                }

                String smsc = String.valueOf(jsonbody.get("sn"));
                if (smsc.contains("-inter")) {

                    ExtentBASETEST.extentReportsDemo("PASS", "Request " + response_id + " is successfully submitted to SMSC & smsc selected is " + smsc);


                } else if (smsc.contains("NOT SUBMITTED TO SMSC")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + response_id + " Request has not been submitted to SMSC");
                    Assert.assertTrue(false, "FOR Request " + response_id + " SMSC is not matched for international request---> " + smsc);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + response_id + " SMSC is not matched for international request---> " + smsc);
                    Assert.assertTrue(false, "FOR Request " + response_id + " SMSC is not matched for international request--->" + smsc);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforInternational() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 8, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforCLIYES")
    public void CLIYES_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the CLI YES Feature <b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                Thread.sleep(2000);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + responseid);

                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());


        }


    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforCLIYES() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 9, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforCLINO")
    public void CLINO_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the CLI NO Feature <b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                Thread.sleep(2000);

                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), true, "TestMSG", ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (!actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforCLINO() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 10, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;
    }

    @Test(dataProvider = "getXmlLangaugeAPIListenerOpenTemplate", priority = 1, enabled = false, invocationCount = 1)
    public void Check_OPEN_Template_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        String dtm = "565656";
        String dpi = "565666";
        String tc = "0";
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>getXmlAPIListener -> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            XML_OPERATIONS.ADD_ATTRIBUTE("dtm", "565656", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_ATTRIBUTE("dpi", "565666", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_ATTRIBUTE("tc", "0", "XmlLangaugeAPIListener.xml");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));
            RestAssured.given().headers(this.requestHeaders);
            Response response = (Response) request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            XML_OPERATIONS.REMOVE_ATTRIBUTE("dtm", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_ATTRIBUTE("dpi", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_ATTRIBUTE("tc", "XmlLangaugeAPIListener.xml");
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "this is Expected tc -->  <b>" + tc + "</b>" + " dpi --> <b>" + dpi + "</b>" + "dtm --> <b>" + dtm + "</b>");

                ExtentBASETEST.extentReportsDemo("INFO", "this is Actual --> tc from DB  --> <b>" + MISDATA.get("tempid_category") + "</b>" + " dpi from DB  --> <b>" + MISDATA.get("dlt_peid") + "</b>" + " dtm from DB  --><b>" + MISDATA.get("dlt_tempid") + "</b>");


                String act_tc = MISDATA.get("tempid_category");
                String act_dpi = MISDATA.get("dlt_peid");
                String act_dtm = MISDATA.get("dlt_tempid");


                try {
                    if (tc.contentEquals(act_tc) && dpi.contentEquals(act_dpi) && dtm.contentEquals(act_dtm)) {
                        System.out.println("Message is passed with dtm dpi tc");
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The actual and expected  tc , dpi and dtm are matching</b>");
                    } else {
                        System.out.println("Message is not passed with dtm ,dpi & tc parameter");
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The actual and expected  tc , dpi and dtm are Not matching</b>");
                    }
                } catch (NullPointerException e) {
                    System.out.println("Please check the live table...");
                    ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());
        }
    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerOpenTemplate() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 21, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;

    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSecondaryAccount")
    public void Check_Secondary_Account_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, "8527607709", MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Secondary Account Feature<b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), true, "TestMSG", ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("commonloglocation98"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), true, MSG, ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + response_id + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(5000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                    System.out.println(MISDATA);
                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getSecondaryAccount() {
        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 22, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLOPTIONALPARAM")
    public void Check_Optional_Param_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner --> " + FunctionName + "</b>");
        try {
            String shorten = "0";
            String path = "lopdlt1";
            String brd = "lopdlt1";
            String auth = "lopdlt1";
            String subappid = "lopdlt1";
            String subauth = "lopdlt1";
            String sch = "lopdlt1";
            String bsize = "100";
            String acc = "0";
            String alertdnd = "0";
            String ivrvflag = "1";
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            XML_OPERATIONS.ADD_NODE("shorten", "0", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("path", "lopdlt1", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("brd", "lopdlt1", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("subappid", "lopdlt1", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("auth", "lopdlt1", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("subauth", "lopdlt1", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("sch", "lopdlt1", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("bsize", "100", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("acc", "0", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("alertdnd", "0", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.ADD_NODE("ivrvflag", "1", "XmlLangaugeAPIListener.xml");
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API with below optional paramters for XMLLANGUAGE LISTENER : shorten , path , brd , subappid , auth , subauth, sch , bsize , acc , alertdnd , ivrvflag</b>");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Expected optional parameters values ---> <br> shorten : 0 , <br> path : lopdlt1 , <br> brd : lopdlt1_test , <br> subappid : lopdlt1 , <br> auth : lopdlt1 , <br> subauth : lopdlt1 , <br> sch : lopdlt1 ,<br> bsize : 100,<br> acc : lopdlt1 , <br> alertdnd : 0 , <br> ivrvflag: 1");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Optional Parameters<b>");
            Response response = request.post();
            XML_OPERATIONS.REMOVE_NODE("shorten", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("path", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("brd", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("subappid", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("auth", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("subauth", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("sch", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("bsize", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("acc", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("alertdnd", "XmlLangaugeAPIListener.xml");
            XML_OPERATIONS.REMOVE_NODE("ivrvflag", "XmlLangaugeAPIListener.xml");

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();
            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id") + "-1";
                System.out.println(response_id);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + response_id);

                System.out.println("Response Object  " + response_id);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);

                TestBase.setcurrenttime();
                Thread.sleep(6000);
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                System.out.println(MISDATA);

                ExtentBASETEST.extentReportsDemo("INFO", "<b>Actual  optional parameters values from DB---> <br>auth : " + MISDATA.get("author") + ",<br> brd :" + MISDATA.get("broadcastname") + ",<br> subappid : " + MISDATA.get("subenterprisename") + ",  <br>subauth : " + MISDATA.get("subauthor") + ", <br> acc : " + MISDATA.get("acc_id") + "</b>");


                if ((auth.contentEquals(MISDATA.get("author"))) && brd.contentEquals(MISDATA.get("broadcastname")) && subappid.contentEquals(MISDATA.get("subenterprisename")) && subauth.contentEquals(MISDATA.get("subauthor")) && acc.contentEquals(MISDATA.get("acc_id"))) {

                    ExtentBASETEST.extentReportsDemo("PASS", "<b>Actual  optional parameters values from DB is correctly matching with Expected and Request status is <b>" + MISDATA.get("statusdesc"));

                    //DLR
                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                    //DLREND
                } else {

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Expected  optional parameters values AUTH= " + auth + "  brd= " + brd + " subappid=  " + subappid + " subaurthor =" + subauth + " acc =" + acc + "<br>" + "Actual  optional parameters values AUTH= " + MISDATA.get("author") + "  brd= " + MISDATA.get("broadcastname") + " subappid=  " + MISDATA.get("subenterprisename") + " subaurthor =" + MISDATA.get("subauthor") + " acc =" + MISDATA.get("acc_id"));
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Actual  optional parameters values from DB is not  matching with Expected and Request status is <b> " + MISDATA.get("statusdesc"));


                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());
        }
    }

    @DataProvider
    public Object[][] getXMLOPTIONALPARAM() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 12, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforDUPLICATEMSG")
    public void Check_Duplicate_Message_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>XmlAPIListner_Check_Duplicate_Message--> " + FunctionName + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlLangaugeAPIListener.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Duplicate Message Feature <b>");
            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                response = request.post();
                hitcount++;
            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {

                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);

                Response response = request.post();
                if (FunctionName.contains("blank_language")) {
                    XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
                }
                System.out.println("Request Object  " + request);
                System.out.println("Status code  " + statusCode);
                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    System.out.println(statusCode);
                    System.out.println(response.body().asString());
                    String temp = response.body().asString();
                    XmlPath xmlPath = new XmlPath(temp);
                    String response_id = xmlPath.get("push.response-id") + "-1";
                    System.out.println(response_id);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + response_id + "</b>");

                    TestBase.setcurrenttime();
                    Thread.sleep(3000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(6000, response_id, PushRecieverLivetablename);
                    if(MISDATA.isEmpty())
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                    }

                    String dbstatus = MISDATA.get("statusdesc");


                    try {
                        if (dbstatus.contentEquals("DUPLICATE MESSAGE FOUND")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");

                            //DLR
                            boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                            if (DLRresult) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                                JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                                ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                                boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                                if (dlrrecieved) {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                    Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                                    if (DLRDATA.isEmpty()) {
                                        ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                        Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                    }
                                    ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                    ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                                } else {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                                }

                            }

                            ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                            //DLREND

                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } catch (Exception e) {
                        System.out.println("Please check the live table...");
                        ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                    }


                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");

                }

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforDUPLICATEMSG() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 23, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }

    @Test(priority = 1, enabled = false, dataProvider = "getXMLdataNegative_AlertDND", invocationCount = SetandGetGlobalVariable.count)
    public void Check_Alert_DND_XmlAPIListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String ExpecResponse, String language, String shortflag, String drflag, String msgid, String alertdnd) {
        if (!FunctionName.contentEquals("Test_DuplicateMessageID")) {
            ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XmlAPIListener")+" "+"<b>ERRORCase_XmlAPIListener_Check_Alert_DND_Cases " + FunctionName + "</b>");

            try {
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Negative case-->" + FunctionName + "</b>");
                // Specify the base URL to the RESTful web service

                XML_OPERATIONS.ADD_NODE("alertdnd", alertdnd, "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, language, "XmlLangaugeAPIListenerNegative_alertdnd.xml", msgid);
                double Eresponse = Double.parseDouble(ExpecResponse);
                int Ecode = (int) (Math.round(Eresponse * 100) / 100);
                String ExpecetdNResponse = String.valueOf(Ecode);

                File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlLangaugeAPIListenerNegative_alertdnd.xml");
                RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(ADDXMLSTR(XMLDataInFile));

                RestAssured.given().headers(requestHeaders);

                Response response = request.post();
                XML_OPERATIONS.REMOVE_NODE("alertdnd", "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                if (UserID.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("userid", "defaultvalue", "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                }
                if (Passd.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("pass", "defaultvalue", "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                }

                if (APPID.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("appid", "defaultvalue", "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                }

                if (Contenttype.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("content-type", "defaultvalue", "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                }
                if (FROM.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("from", "defaultvalue", "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                }
                if (ALERT.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("alert", "1", "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                }

                if (FunctionName.contains("MESSAGEID_TAGMISS")) {
                    XML_OPERATIONS.ADD_NODE("msgid", "defaultvalue", "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                }
                int statusCode = response.getStatusCode();

                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    System.out.println(statusCode);
                    // System.out.println(response.body().asString());
                    String temp = response.body().asString();
                    XmlPath xmlPath = new XmlPath(temp);
                    String Errorcode = xmlPath.get("push.error.code");
                    if (Errorcode.contentEquals(ExpecetdNResponse)) {
                        System.out.println(FunctionName + " Passed");
                        ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Errorcode + " matched with Expected Response " + ExpecetdNResponse);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Errorcode + " did not match with Expected Response " + ExpecetdNResponse);

                        Assert.assertEquals(Errorcode, ExpecetdNResponse, "Response code not matched for " + FunctionName);

                        System.out.println("Actual response " + Errorcode + " matched with Expected Response " + ExpecetdNResponse);


                    }

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");
                }

            } catch (Exception e) {
                ExtentBASETEST.extentReportsDemo("INFO", e.toString());
                Assert.fail(e.toString());

            }
        }
    }


    @DataProvider
    public Object[][] getXMLdataNegative_AlertDND() {
        Object data[][] = ExcelUtils.getTestData("AlertDND", 0, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }





    @DataProvider
    public Object[][] getXMLSMSCOUNTdata() {
        Object data[][] = ExcelUtils.getTestData("SMSCOUNT", 0, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }
	}