public class SetandGetGlobalVariable {
    private static String TemplateID;
    public static final int count = 1;
    public static int specificrowid=0;
    public static void SetTemplateID(String id) {
        TemplateID = id;
    }

    public static String GETTemplateid() {
        return TemplateID;
    }
//test
}


