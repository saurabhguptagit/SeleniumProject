import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class URL_REFRESH {

	//test
	@Test(priority = 1, enabled = true, dataProvider = "getRefreshURLdata")
	public void RefreshURL(String URL,String Expectedreposebody)
	{   

		//RestAssured.baseURI = URL;


		RequestSpecification httpRequest = RestAssured.given();

		//Response response = httpRequest.request(Method.GET);

		Response response = httpRequest.post(URL);
		String responseBody = response.getBody().asString();
		//System.out.println(httpRequest.toString());
		int statuscode =response.getStatusCode();
		if(statuscode==200)
		{
			System.out.println("Response code is =>  " + statuscode);
			System.out.println("Response Body is =>  " + responseBody);
			Assert.assertEquals(responseBody,Expectedreposebody,"Response not matched");

		}
		else
		{
			Assert.fail("Status code is not success");
		}

	}

	@DataProvider
	public Object[][] getRefreshURLdata() {
		Object data[][] = ExcelUtils.getTestData("Refresh_DB",0,"TestData-V1.xlsx");
		return data;
	}
}