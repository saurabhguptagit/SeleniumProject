import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class TextListener {
    TestBase ob;

    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
        //ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST FOR NTEXT LISTNERS</b></h5>");

            RestAssured.baseURI = ob.GetProperty("QA_AWS_TEXT_BASE_URI");

       

    }


    @Test(dataProvider = "getNTEXTdetails", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_Error_Codes_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String ExpecResponse, String shortflag, String drflag, String msgid, String alertdnd, String D, String f, String iu, String au, String fb) {
        if (!FunctionName.contentEquals("Test_DuplicateMessageID")) {
            ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_Listener_ERRORCASE -->" + FunctionName + "</b>");
            try {
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Negative case-->" + FunctionName + "</b>");
                String SCTYPE = "";
                if (Contenttype.contentEquals("BLK")) {

                } else {
                    double ctype = Double.parseDouble(Contenttype);
                    int ictype = (int) (Math.round(ctype * 100) / 100);
                    SCTYPE = String.valueOf(ictype);
                }

                if (APPID.contentEquals("BLK")) {
                    APPID = "";
                }
                if (UserID.contentEquals("BLK")) {
                    UserID = "";
                }
                if (Passd.contentEquals("BLK")) {
                    Passd = "";
                }
                if (ALERT.contentEquals("BLK")) {
                    ALERT = "";
                } else {
                    double alrt = Double.parseDouble(ALERT);
                    int INALERT = (int) (Math.round(alrt * 100) / 100);
                    ALERT = String.valueOf(INALERT);
                }
                if (INTFLAG.contentEquals("BLK")) {
                    INTFLAG = "";
                }
                if (MSG.contentEquals("BLK")) {
                    MSG = "";
                }
                if (FROM.contentEquals("BLK")) {
                    FROM = "";
                }
                if (TO.contentEquals("BLK")) {
                    TO = "";
                }
                if (shortflag.contentEquals("BLK")) {
                    shortflag = "";
                } else {
                    double shortflg = Double.parseDouble(shortflag);
                    int SHORTFLAG = (int) (Math.round(shortflg * 100) / 100);
                    shortflag = String.valueOf(SHORTFLAG);
                }

                if (SELFID.contentEquals("FALSE")) {
                    msgid = "";
                }
                if (msgid.contentEquals("BLK")) {
                    msgid = "";
                }
                if (drflag.contentEquals("BLK")) {
                    drflag = "";
                } else {
                    double DRflg = Double.parseDouble(drflag);
                    int DRFLAG = (int) (Math.round(DRflg * 100) / 100);
                    drflag = String.valueOf(DRFLAG);
                }
                if (alertdnd.contentEquals("BLK")) {
                    alertdnd = "";
                } else {
                    double alerdndflg = Double.parseDouble(alertdnd);
                    int DNDFLAG = (int) (Math.round(alerdndflg * 100) / 100);
                    alertdnd = String.valueOf(DNDFLAG);
                }
                if (D.contentEquals("BLK")) {
                    D = "";
                }

                if (f.contentEquals("BLK")) {
                    f = "";
                } else {
                    double ff = Double.parseDouble(f);
                    int fff = (int) (Math.round(ff * 100) / 100);
                    f = String.valueOf(fff);
                }

                if (iu.contentEquals("BLK")) {
                    iu = "";
                }
                if (au.contentEquals("BLK")) {
                    au = "";
                }
                if (fb.contentEquals("BLK")) {
                    fb = "";
                }
                RequestSpecification request = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "9918702626")
                        .param("text", MSG)
                        .param("alert", ALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("s", shortflag)
                        .param("dr", drflag)
                        .param("msgid", msgid)
                        .param("alertdnd", alertdnd)
                        .param("d", D)
                        .param("f", f)
                        .param("iu", iu)
                        .param("au", au)
                        .param("fb", fb);

                Response response = request.post();
                System.out.println("Response Object  " + response.asString());

                double Eresponse = Double.parseDouble(ExpecResponse);
                int Ecode = (int) (Math.round(Eresponse * 100) / 100);
                String ExpecetdNResponse = String.valueOf(Ecode);

                String Acturesponse = response.asString().replaceAll("[\\n\\t ]", "");

            /*double a = Double.parseDouble(Acturesponse);
            int Acode = (int) (Math.round(a * 100) / 100);
            String ANResponse = String.valueOf(Acode); */

                if (Acturesponse.contentEquals(ExpecetdNResponse)) {
                    System.out.println(FunctionName + " Passed");
                    ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Acturesponse + " did not match with Expected Response " + ExpecetdNResponse);

                    Assert.assertEquals(Acturesponse, ExpecetdNResponse, "Response code not matched for " + FunctionName);

                    System.out.println("Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);


                }

            } catch (Exception e) {
                ExtentBASETEST.extentReportsDemo("INFO", e.toString());
                System.out.println(e);

            }
        }

    }


    @Test(dataProvider = "getNTEXTdetailsPositive", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_Template_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_TEMPLATEMATCHING--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the postive case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                System.out.println("Response Object  " + responseid);

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                boolean DLRCHECK = false;
                String DLRLivetablename = "";
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "MSG", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + responseid + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        DLRCHECK = true;

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    }
                    System.out.println(MISDATA);
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);


                    if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                        DLRCHECK = true;
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    }


                }

                //DLR
                if (DLRCHECK) {
                    boolean result = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                    System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + result);

                    if (result) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    } else {
                        System.out.println("DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }

                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }

                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }


                    }
                }
                ExtentBASETEST.extentReportsDemo("INFO", "DLR TEST EXECUTED");

                //END


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTSMSCOUNTDATA", priority = 0, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_SMSCOUNT_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String smscount) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>Check_SMSCOUNT_TEXTLISTNER--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            double b = Double.parseDouble(smscount);
            int SMSCOUNTroundOff = (int) (Math.round(b * 100) / 100);
            System.out.println("Expected sms count is " + SMSCOUNTroundOff);


            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the SMS COUNT  case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                System.out.println("Response Object  " + responseid);


                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
              boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));

                if (SMSCRESULT) {
                    //JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid,ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"),false,"DUMMY",ob.GetProperty("commonloglocation94"));
                     ExtentBASETEST.extentReportsDemo("INFO", "DATA FOUND IN 207");


                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                    System.out.println(MISDATA);
                    // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                    if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                    }
                } else {

                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                    if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {
                        System.out.println(MISDATA);
                        // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                        if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                            ExtentBASETEST.extentReportsDemo("PASS", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                        }
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    }
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Something is wrong");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTSPECIFICROWforTilta", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void SPECIALCHAR_TILTA_HANDLING__TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_TILTA_HANDLING--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Tilta handling case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request.toString());
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);


                TestBase.setcurrenttime();
                Thread.sleep(6000);
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                System.out.println(MISDATA);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA-->" + MISDATA.toString());

                String actualmsg = ob.GetProperty("SPECIALCHAR_TILTA_TEXT");

                String newLineExpectedmsg = actualmsg.replace('~', '\n');

                String newLineActualmsg = MISDATA.get("messagetext");
                if (newLineExpectedmsg.contentEquals(newLineActualmsg)) {
                    String aar[] = newLineActualmsg.split("\n");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Replaced text with new line ---><b>" + Arrays.deepToString(aar) + "</b>");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Text with ~ char ---><b>" + actualmsg + "</b>");
                    ExtentBASETEST.extentReportsDemo("PASS", " <b>The ~  is successfully  converted into new line charracter </b>");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The ~ in the Actual message " + newLineActualmsg + " is not converted into new line charracter ....Please see Expected text --->" + newLineExpectedmsg);

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforshortening", priority = 1, enabled = false, invocationCount = 1)
    public void Check_SHORTENING_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_SHORTENING--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("s", "1");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the shortening case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();
            String shortflag="1";
            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "DUMMY", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "DUMMY", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "DUMMY", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 206 orchestrator SERVER</b>");
                    }
                }

                //


                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                if(shortflag.contentEquals("1")) {
                    String originalmessage = "BLK";
                    String messagetext = MISDATA.get("messagetext");
                    Map shorturlresult = UrlShortenerValidator.RETURNSHORTRESULT(originalmessage, messagetext);
                    boolean shortresult=false;
                    shortresult=(boolean)shorturlresult.get("isShorteningpass");


                    ExtentBASETEST.extentReportsDemo("INFO", " <b> The shorten urls from message text are </b> -->" + shorturlresult.get("shortresult"));
                    if(shortresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", " <b> ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTED ? </b> -->" + shorturlresult.get("isShorteningpass"));
                    }
                    else
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", " <b> ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTED ? </b> -->" + shorturlresult.get("isShorteningpass"));

                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforinsufficentcredit", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void INSUFFICIENT_CREDIT_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_ListenerTest started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "919971498470")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Insufficent credit  case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                boolean DLRCHECKFLAG = false;
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "MSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                    }
                }
                //
                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }


                boolean result = LinuxLogReader.CheckPrepaidbalance(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "MSG", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (result) {
                    DLRCHECKFLAG = true;
                    ExtentBASETEST.extentReportsDemo("PASS", FunctionName + " PASSED for " + responseid);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", FunctionName + " FAILED for " + responseid);

                }

                if (DLRCHECKFLAG) {
                    TestBase.setcurrenttime();
                    Thread.sleep(1000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTSPECIFICROWforInternational", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void INTERNATIONAL_REQ_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_Listener started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "61491570156")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the international case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
               /*
                Thread.sleep(5000);
                JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid,ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"),false,"DUMMY",ob.GetProperty("commonloglocation94"),ob.GetProperty("rcvrlogfileName"));
                try
                {
                    if(jsonbody.isEmpty())
                    {
                        ExtentBASETEST.extentReportsDemo("ERROR ","The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->"+jsonbody.toString());

                }catch(Exception e)
                {

                    ExtentBASETEST.extentReportsDemo("ERROR ",e.toString());

                } */
                TestBase.setcurrenttime();
                Thread.sleep(2000);
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                System.out.println(MISDATA);
                String smsc = MISDATA.get("smscname");
                //String smsc= String.valueOf(jsonbody.get("sn"));
                if (smsc.contains("-inter")) {

                    ExtentBASETEST.extentReportsDemo("PASS", "Request " + responseid + " is successfully submitted to SMSC & smsc selected is " + smsc);


                } else if (smsc.contains("NOT SUBMITTED TO SMSC")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + " Request has not been submitted to SMSC");
                    Assert.assertTrue(false, "FOR Request " + responseid + " SMSC is not matched for international request---> " + smsc);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + " SMSC is not matched for international request---> " + smsc);
                    Assert.assertTrue(false, "FOR Request " + responseid + " SMSC is not matched for international request--->" + smsc);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforCLIYES", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void OpenCLI_YES_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTENER_Test started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the OPEN CLI Yes case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response id " + responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));

                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " is matching with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is not matching with  Recieved sender is " + recievedsender);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());


        }

    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforCLINO", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void OpenCLI_NO_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTNER_Test started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the OPEN CLI NO case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response id " + responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));

                //

                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (!actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());


        }


    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforTemplateCONVERSION", priority = 1, enabled = false, invocationCount = 1)
    public void Check_Templateconversion_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String contertedtext) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_TEMPLATECONVERSION--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check MSG conversion for TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                System.out.println("this is actual  msg  before conversion" + MSG);
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg  before conversion <b>" + MSG + "</b>");

                System.out.println("this is expected converted msg from Excel" + contertedtext);
                ExtentBASETEST.extentReportsDemo("INFO", "this is expected converted msg from Excel <b>" + contertedtext + "</b>");

                System.out.println("this is actual converted msg from live sql table" + MISDATA.get("messagetext"));
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("messagetext") + "</b>");
                try {
                    if (contertedtext.contentEquals(MISDATA.get("messagetext"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The msg conversion is successfull</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The msg conversion is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTSPECIFICROWforINVALIDMESSAGE", priority = 1, enabled = false, invocationCount = 1)
    public void Check_INVALID_MESSAGE_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_INVALIDMESSAGE--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check INVALID MSG for TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }


                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if ("INVALID MESSAGE".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID msg check is successfull</b>");
                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR


                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID msg check NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTDPITCCheck", priority = 2, enabled = false, invocationCount = 1)
    public void Check_DPI_TC_TEXTLISTENER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String dpi, String tc, String dtm) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_DPI_DTM_TC_CHECK--> " + FunctionName + "</b>");
        try {
            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);
            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);
            if (dpi.contentEquals("BLK")) {
                dpi = "";
            }
            if (dtm.contentEquals("BLK")) {
                dtm = "";
            }
            if (tc.contentEquals("BLK")) {
                tc = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "8527607709")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("dpi", dpi)
                    .param("tc", tc)
                    .param("dtm", dtm);
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check MSG conversion for TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {


            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();


            System.out.println("Status code  " + statusCode);


            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response Object  " + responseid);

                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);


                ExtentBASETEST.extentReportsDemo("INFO", "this is Expected tc -->  <b>" + tc + "</b>" + " dpi --> <b>" + dpi + "</b>" + "dtm --> <b>" + dtm + "</b>");


                ExtentBASETEST.extentReportsDemo("INFO", "this is Actual --> tc from DB  --> <b>" + MISDATA.get("tempid_category") + "</b>" + " dpi from DB  --> <b>" + MISDATA.get("dlt_peid") + "</b>" + " dtm from DB  --><b>" + MISDATA.get("dlt_tempid") + "</b>");


                String act_tc = MISDATA.get("tempid_category");
                String act_dpi = MISDATA.get("dlt_peid");
                String act_dtm = MISDATA.get("dlt_tempid");


                try {
                    if (tc.contentEquals(act_tc) && dpi.contentEquals(act_dpi) && dtm.contentEquals(act_dtm)) {
                        System.out.println("Message is passed with dtm dpi tc");
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The actual and expected  tc , dpi and dtm are matching</b>");
                    } else {
                        System.out.println("Message is not passed with dtm ,dpi & tc parameter");
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The actual and expected  tc , dpi and dtm are Not matching</b>");
                    }
                } catch (NullPointerException e) {
                    System.out.println("Please check the live table...");
                    ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());
        }
    }

    Response response;

    @Test(dataProvider = "getNTEXTSPECIFICROWforDUPLICATEMSG", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_DUPLICATE_MESSAGE_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTNER_ -->" + FunctionName + "</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Duplicate MSG -->" + FunctionName + "</b>");
            String SCTYPE = "";

            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double alrt = Double.parseDouble(ALERT);
            int INALERT = (int) (Math.round(alrt * 100) / 100);
            String AALERT = String.valueOf(INALERT);


            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                response = request.post();
                hitcount++;


            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {


                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);

                //System.out.println("Function name is "+FunctionName);
                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                    System.out.println("Response Object  " + responseid);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                    TestBase.setcurrenttime();
                    Thread.sleep(3000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }


                    String dbstatus = MISDATA.get("statusdesc");


                    try {
                        if (dbstatus.contentEquals("DUPLICATE MESSAGE FOUND")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");
                            //DLR
                            boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                            if (DLRresult) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                                JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                                ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                                boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                                if (dlrrecieved) {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                    Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                    if (DLRDATA.isEmpty()) {
                                        ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                        Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                    }
                                    ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                    ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                                } else {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                                }

                            }

                            ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                            //DLREND

                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } catch (Exception e) {
                        System.out.println("Please check the live table...");
                        ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                    }


                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");

                }

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforMSGIDCHECKNOTNEEDED", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_DUPLICATE_MSGID_NOT_REQUIRED_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTNER_ -->" + FunctionName + "</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Duplicate MSGID not needed -->" + FunctionName + "</b>");
            String SCTYPE = "";

            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double alrt = Double.parseDouble(ALERT);
            int INALERT = (int) (Math.round(alrt * 100) / 100);
            String AALERT = String.valueOf(INALERT);


            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API for <b>" + i + " time");

                response = request.post();
                hitcount++;
                System.out.println("Response Object  " + response.asString());
                ExtentBASETEST.extentReportsDemo("INFO", "<b >Going to hit the API for <b>" + "Response Object  " + response.asString());


            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {


                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);

                //System.out.println("Function name is "+FunctionName);
                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                    System.out.println("Response Object  " + responseid);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                    TestBase.setcurrenttime();
                    Thread.sleep(3000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);


                    String dbstatus = MISDATA.get("statusdesc");


                    try {
                        if (dbstatus.contentEquals("SUBMITTED TO SMSC")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");
                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } catch (Exception e) {
                        System.out.println("Please check the live table...");
                        ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                    }


                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");

                }

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforDUPLICATEMSGID", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_DUPLICATE_MESSAGEID_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String ExpecResponse, String shortflag, String drflag, String msgid, String alertdnd, String D, String F, String IU, String AU, String FB) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTNER_ERRORCASE -->" + FunctionName + "</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Duplicate MSG id error-->" + FunctionName + "</b>");
            String SCTYPE = "";

            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double alrt = Double.parseDouble(ALERT);
            int INALERT = (int) (Math.round(alrt * 100) / 100);
            ALERT = String.valueOf(INALERT);


            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", TO)
                    .param("text", MSG)
                    .param("alert", ALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("msgid", msgid);

            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API for <b>" + i + " time");

                response = request.post();
                hitcount++;
                System.out.println("Response Object  " + response.asString());
                ExtentBASETEST.extentReportsDemo("INFO", "<b >Going to hit the API for <b>" + "Response Object  " + response.asString());


            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {

                double Eresponse = Double.parseDouble(ExpecResponse);
                int Ecode = (int) (Math.round(Eresponse * 100) / 100);
                String ExpecetdNResponse = String.valueOf(Ecode);

                String Acturesponse = response.asString().replaceAll("[\\n\\t ]", "");

                double a = Double.parseDouble(Acturesponse);
                int Acode = (int) (Math.round(a * 100) / 100);
                String ANResponse = String.valueOf(Acode);
                if (Acturesponse.contentEquals(ExpecetdNResponse)) {
                    System.out.println(FunctionName + " Passed");
                    ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Acturesponse + " did not match with Expected Response " + ExpecetdNResponse);

                    Assert.assertEquals(Acturesponse, ExpecetdNResponse, "Response code not matched for " + FunctionName);

                    System.out.println("Actual response " + Acturesponse + " matched with Expected Response " + ExpecetdNResponse);


                }
            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }


    @Test(dataProvider = "getNTEXTOPTIONALPARAM", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void OPTIONAL_PARAM_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_OPTIONAL_PARAM--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("auth", ob.GetProperty("auth"))
                    .param("brd", ob.GetProperty("brd"))
                    .param("subappid", ob.GetProperty("subappid"))
                    .param("sch", ob.GetProperty("sch"))
                    .param("bsize", ob.GetProperty("bsize"))
                    .param("path", ob.GetProperty("path"))
                    .param("subauth", ob.GetProperty("subauth"))
                    .param("acc", ob.GetProperty("acc"))
                    .param("alertdnd", ob.GetProperty("alertdnd"));

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API with below optional paramters for TEXT : auth , brd , subappid , sch, bsize , path , subauth, acc, alertdnd</b>");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Expected optional parameters values ---> <br> auth : " + ob.GetProperty("auth") + ", <br> brd :" + ob.GetProperty("brd") + ",<br> subappid : " + ob.GetProperty("subappid") + ", <br> subauth : " + ob.GetProperty("subauth") + ",<br> acc : " + ob.GetProperty("acc") + "</b>");


            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);


                TestBase.setcurrenttime();
                Thread.sleep(6000);
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                System.out.println(MISDATA);

                ExtentBASETEST.extentReportsDemo("INFO", "<b>Actual  optional parameters values from DB---> <br>auth : " + MISDATA.get("author") + ",<br> brd :" + MISDATA.get("broadcastname") + ",<br> subappid : " + MISDATA.get("subenterprisename") + ",  <br>subauth : " + MISDATA.get("subauthor") + ", <br> acc : " + MISDATA.get("acc_id") + "</b>");


                if ((ob.GetProperty("auth").contentEquals(MISDATA.get("author"))) && (ob.GetProperty("brd").contentEquals(MISDATA.get("broadcastname"))) && (ob.GetProperty("subappid").contentEquals(MISDATA.get("subenterprisename"))) && (ob.GetProperty("subauth").contentEquals(MISDATA.get("subauthor"))) && (ob.GetProperty("acc").contentEquals(MISDATA.get("acc_id")))) {

                    ExtentBASETEST.extentReportsDemo("PASS", "<b>Actual  optional parameters values from DB is correctly matching with Expected and Request status is <b>" + MISDATA.get("statusdesc"));
//DLR
                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                    //DLREND

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Actual  optional parameters values from DB is not  matching with Expected and Request status is <b> " + MISDATA.get("statusdesc"));


                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getdlttempidNotAllowedCheck", priority = 1, enabled = false, invocationCount = 1)
    public void Check_dlt_tempid_Not_Allowed_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_dlt_tempid_Not_Allowed-> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check dlt_tempid_Not_Allowedfor TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if ("DLT TEMPID NOT FOUND".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The DLT TEMPID NOT FOUND check is successfull</b>");

                        //DLR
                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                        //DLREND
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The DLT TEMPID NOT FOUND  NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getNTEXTdatafordefaultsender", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void DEFAULT_SENDER_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String Expected_sender) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_LISTENER_Test started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the OPEN CLI Yes case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response id " + responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }
                //
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    // String actualsender=jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (Expected_sender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Recieved sender is " + recievedsender + "  matching with expected sender " + Expected_sender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "   Recieved sender is " + recievedsender + " NOT matching with expected sender " + Expected_sender);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());


        }

    }



    @Test(dataProvider = "getNTEXTSPECIFICROWforIvrvFlag", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Ivrvflag_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
// In the case of IVrvflag clould smsc needed.
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_Listener started--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("ivrvflag", "1");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Ivrvflag case SMSC selection for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }
                JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                try {
                    if (jsonbody.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("ERROR ", "The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                } catch (Exception e) {

                    ExtentBASETEST.extentReportsDemo("ERROR ", e.toString());

                }

                String smsc = String.valueOf(jsonbody.get("sn"));
                if (smsc.contains("-cloud")) {

                    ExtentBASETEST.extentReportsDemo("PASS", "Request " + responseid + " is successfully submitted to SMSC & <b> request  processed through cloud connectivity , smsc selected is " + smsc + "</b>");


                } else if (smsc.contains("NOT SUBMITTED TO SMSC")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + " Request has not been submitted to SMSC");
                    Assert.assertTrue(false, "FOR Request " + responseid + " SMSC is not matched for Ivrv flag request---> " + smsc);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + "  Cloud SMSC is not selected for Ivrv flag  request---> " + smsc);
                    Assert.assertTrue(false, "FOR Request " + responseid + " Cloud SMSC is not selected for Ivrv flag request--->" + smsc);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforIvrvFlag() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 16, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSOIPDATA() {

        Object data[][] = ExcelUtils.getTestData("NTEXT_SOIP_TEST", 0, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTdatafordefaultsender() {
        Object data[][] = ExcelUtils.getTestData("NTEXT_DEFAULT_SENDER_TEST", 4, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTDPITCCheck() {
        Object data[][] = ExcelUtils.getTestData("NTEXTOPENTEMPLATE", 1, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTdetails() {
        Object data[][] = ExcelUtils.getTestData("NTEXTdataNegative", 0, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTdetailsPositive() {
        Object data[][] = ExcelUtils.getTestData("NTEXTTemplatecases", 1, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforTilta() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 5, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforshortening() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 6, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforinsufficentcredit() {

        Object data[][] = ExcelUtils.getTestData("NTEXT_INSUFFICIENT_CREDIT", 0, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforInternational() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 8, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforCLIYES() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 9, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTOPTIONALPARAM() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 12, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforCLINO() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 10, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforTemplateCONVERSION() {

        Object data[][] = ExcelUtils.getTestData("NTEXTTEMPLATECONVERSTION", 1, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforINVALIDMESSAGE() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 11, "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSMSCOUNTDATA() {
        Object data[][] = ExcelUtils.getTestData("NTEXTSMSCOUNT", 0, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforDUPLICATEMSGID() {

        Object data[][] = ExcelUtils.getTestData("NTEXTdataNegative", 11, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforDUPLICATEMSG() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 13, "TestData_TEXT.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getdlttempidNotAllowedCheck() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 14, "TestData_TEXT.xlsx");

        return data;
    }


    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforMSGIDCHECKNOTNEEDED() {

        Object data[][] = ExcelUtils.getTestData("NTEXTSPECIFICDATA", 15, "TestData_TEXT.xlsx");
        return data;
    }

    @Test(dataProvider = "getTextNegativedataLOG", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_ERRORCASEINLOG_Text(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String shortflag, String drflag, String msgid, String alertdnd, String D, String f, String iu, String au, String fb,String Expectedmsg) {
        if (!FunctionName.contentEquals("Test_DuplicateMessageID")) {
            ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXT_Listener_ERRORCASE -->" + FunctionName + "</b>");
            try {
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Negative case-->" + FunctionName + "</b>");
                String SCTYPE = "";
                if (Contenttype.contentEquals("BLK")) {

                } else {
                    double ctype = Double.parseDouble(Contenttype);
                    int ictype = (int) (Math.round(ctype * 100) / 100);
                    SCTYPE = String.valueOf(ictype);
                }

                if (APPID.contentEquals("BLK")) {
                    APPID = "";
                }
                if (UserID.contentEquals("BLK")) {
                    UserID = "";
                }
                if (Passd.contentEquals("BLK")) {
                    Passd = "";
                }
                if (ALERT.contentEquals("BLK")) {
                    ALERT = "";
                } else {
                    double alrt = Double.parseDouble(ALERT);
                    int INALERT = (int) (Math.round(alrt * 100) / 100);
                    ALERT = String.valueOf(INALERT);
                }
                if (INTFLAG.contentEquals("BLK")) {
                    INTFLAG = "";
                }
                if (MSG.contentEquals("BLK")) {
                    MSG = "";
                }
                if (FROM.contentEquals("BLK")) {
                    FROM = "";
                }
                if (TO.contentEquals("BLK")) {
                    TO = "";
                }
                if (shortflag.contentEquals("BLK")) {
                    shortflag = "";
                } else {
                    double shortflg = Double.parseDouble(shortflag);
                    int SHORTFLAG = (int) (Math.round(shortflg * 100) / 100);
                    shortflag = String.valueOf(SHORTFLAG);
                }

                if (SELFID.contentEquals("FALSE")) {
                    msgid = "";
                }
                if (msgid.contentEquals("BLK")) {
                    msgid = "";
                }
                if (drflag.contentEquals("BLK")) {
                    drflag = "";
                } else {
                    double DRflg = Double.parseDouble(drflag);
                    int DRFLAG = (int) (Math.round(DRflg * 100) / 100);
                    drflag = String.valueOf(DRFLAG);
                }
                if (alertdnd.contentEquals("BLK")) {
                    alertdnd = "";
                } else {
                    double alerdndflg = Double.parseDouble(alertdnd);
                    int DNDFLAG = (int) (Math.round(alerdndflg * 100) / 100);
                    alertdnd = String.valueOf(DNDFLAG);
                }
                if (D.contentEquals("BLK")) {
                    D = "";
                }

                if (f.contentEquals("BLK")) {
                    f = "";
                } else {
                    double ff = Double.parseDouble(f);
                    int fff = (int) (Math.round(ff * 100) / 100);
                    f = String.valueOf(fff);
                }

                if (iu.contentEquals("BLK")) {
                    iu = "";
                }
                if (au.contentEquals("BLK")) {
                    au = "";
                }
                if (fb.contentEquals("BLK")) {
                    fb = "";
                }
                RequestSpecification request = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "9918702626")
                        .param("text", MSG)
                        .param("alert", ALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("s", shortflag)
                        .param("dr", drflag)
                        .param("msgid", msgid)
                        .param("alertdnd", alertdnd)
                        .param("d", D)
                        .param("f", f)
                        .param("iu", iu)
                        .param("au", au)
                        .param("fb", fb);

                Response response = request.post();
                System.out.println("Response Object  " + response.asString());

                String responseid = response.asString().replaceAll("[\\n\\t ]", "");



            /*double a = Double.parseDouble(Acturesponse);
            int Acode = (int) (Math.round(a * 100) / 100);
            String ANResponse = String.valueOf(Acode); */

                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the postive case for TEXT </b>");

                System.out.println("Request Object  " + request);
                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);
                if (statusCode == 200) {


                    System.out.println("Request is accepted");

                    //PROCESSOR LOG CHECK
                    if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                        }
                    }

                    //

                    boolean result = LinuxLogReader.CheckLOGERRORMESSAGE(Expectedmsg, responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), false, "DUMMY", ob.GetProperty("commonloglocation205"),ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (result) {
                        ExtentBASETEST.extentReportsDemo("PASS", FunctionName + " TEST  PASSED for " + responseid + "<br> below message found in log " + Expectedmsg);
                        //DLR
                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //DLREND

                    } else {

                    }


                }
            } catch (Exception e) {
                ExtentBASETEST.extentReportsDemo("INFO", e.toString());
                System.out.println(e);

            }
        }

    }
    @DataProvider
    public Object[][] getTextNegativedataLOG() {

        Object data[][] = ExcelUtils.getTestData("dataNegativeLOG", 0, "TestData_TEXT.xlsx");
        return data;


    }


    @Test(dataProvider = "getRCSTESTDATA", priority = 1,  enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language ,String SHORT) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
       // Reporter.log("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double stype = Double.parseDouble(SHORT);
            int istype = (int) (Math.round(stype * 100) / 100);
            String shortening = String.valueOf(istype);



            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470
            Response response= null;

            RequestSpecification request;

            if(shortening.contentEquals("3"))
            {
                request  = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "9918702626")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);
            } else{

                request   = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "9918702626")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .param("s",shortening);

            }


            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the RCS component </b>");
            if(FunctionName.contains("UNICODE"))
            {
                 response = request.get();
            }else {
                 response = request.post();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String RCSRECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");

                if(responseid.startsWith("-"))
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " response is  "+responseid);
                    Assert.assertTrue(false," response is  "+responseid);

                }
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
if(shortening.contentEquals("1"))
{
    String check1="\"sto\":\"SHORT_URL_PICKER_INPUT_QUEUE\"";
    String check2="CommonUtility::sendToShortUrlRepository::appId -> "+APPID;
    if(responseString.contains(check1)&&responseString.contains(check2))
    {
        ExtentBASETEST.extentReportsDemo("INFO", "<b> For the request shortening flag was 1 and request successfully sent to SHORT URL component of RCS and it has been verified in log   both strings are found in log</b>" +"First string "+ check1 +"Second string "+ check2);

    }

    TestBase.setcurrenttime();
    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
    String RCSRecieverLivetablename = Livetablename.get("RCSRECIEVERTABLENAME");
    String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
    boolean shortresult = SQLPOOL.checkshortstageDB(responseid, RCSRecieverLivetablename, ShortstageLiveBeetablename);

    if (shortresult) {
        System.out.println("Shortening passed");
        Map<String, String> BEEMISDATA = SQLPOOL.GETMISDATA_FROM_SHORTSTAGE_RECIEVERTABLE( responseid, RCSRecieverLivetablename,ShortstageLiveBeetablename,"routing_channel");

        ExtentBASETEST.extentReportsDemo("INFO", " The Routing channel for RCS request in Short bee table  is  "+BEEMISDATA.get("routing_channel"));

        if (BEEMISDATA.isEmpty()) {
            ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
        } else {
            ExtentBASETEST.extentReportsDemo("INFO", "SHORTENING PASSED");

        }


    } else {
        ExtentBASETEST.extentReportsDemo("INFO", "SHORTENING FAILED");
    }
}

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {
                    if(MISDATA.get("templateid").isEmpty())
                    { ExtentBASETEST.extentReportsDemo("FAIL", "Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());
                     Assert.assertTrue(false,"Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());

                    }else {
                        ExtentBASETEST.extentReportsDemo("PASS", " <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());
                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(submitstatus.contentEquals("submitted"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        DLRCHECK = true;
                        joinid=MISDATA.get("joinid");
                    }
                    else {
                        ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                        Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @DataProvider
    public Object[][] getTEXTSPECIFICROWforRCSCAPABILITY() {

        Object data[][] = ExcelUtils.getTestData("RCSCAPABILITY", 5, "TestData_TEXT.xlsx");

        return data;
    }
    @DataProvider
    public Object[][] getRCSTESTDATA() {

        Object data[][] = ExcelUtils.getTestData("RCS_TEST_DATA", 4, "TestData_TEXT.xlsx");

        return data;
    }


    @Test(dataProvider = "getTEXTSPECIFICROWforRCSCAPABILITY", priority = 1,  enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_CAPABILITY_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,String capability) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");

        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470
            String ph[]=TO.split("X");
            System.out.println("This is mobile no from excel sheet "+ph[1]);
            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", ph[1])
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("s","0");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the RCS CAPABILITY CHECK FOR PHHONENUMBER </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String RCSRECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(5000);
                    boolean RCSCOMPONENTLOGRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (RCSCOMPONENTLOGRESULT) {

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>"+ responseString);


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check MIS</b>");



                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {


                    ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(capability.contentEquals("YES")) {
                        if (submitstatus.contentEquals("submitted")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                            DLRCHECK = true;
                            joinid = MISDATA.get("joinid");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);
                            Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);

                        }
                    } else if(capability.contentEquals("NO"))
                    {
                        if (submitstatus.contentEquals("REJECTED DUE TO DEVICE NOT CAPABLE TO RECEIVE RCS") ) {
                            ExtentBASETEST.extentReportsDemo("PASS", " DB has updated with status "+"<b>"+submitstatus+"</b>");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " NOT CAPABLE CHECK IS FAILED AND RCS status in DB is "+"<b>"+submitstatus+"</b>");

                        }
                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getNTEXTDARSDATA", priority = 1, enabled = false, invocationCount = 1)
    public void Check_DARS_CASES_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,  String ExpectedSMSC) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_DARS-> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
            //917838269548

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", TO)
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check" + FunctionName + " </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                String actualsmsc = MISDATA.get("smscname");
                actualsmsc=ExpectedSMSC;
           if(actualsmsc==null)
           {
               actualsmsc = "BLK";
               ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
               Assert.fail("<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
           }
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if (ExpectedSMSC.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> <font color=green> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b> </font>");
                       // ExtentBASETEST.extentReportsDemo("INFO", "<font color=blue>The MIS data for the same is below --> <br> " + MISDATA+"</font>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> <font color=red>Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b></font>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @DataProvider
    public Object[][] getNTEXTDARSDATA() {

        Object data[][] = ExcelUtils.getTestData("DARS", 0, "TestData_TEXT.xlsx");

        return data;
    }


    @Test(dataProvider = "getNTEXTSPECIFICROWforJUM_10326", priority = 1,  enabled = false, invocationCount = 1)
    public void Check_JUM_10326_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String contertedtext) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_JUM_10326--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check MSG conversion for TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                System.out.println("this is actual  msg  before conversion" + MSG);
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg  before conversion <b>" + MSG + "</b>");

                System.out.println("this is expected converted msg from Excel" + contertedtext);
                ExtentBASETEST.extentReportsDemo("INFO", "this is expected converted msg from Excel <b>" + contertedtext + "</b>");

                System.out.println("this is actual converted msg from live sql table" + MISDATA.get("messagetext"));
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("messagetext") + "</b>");
                try {
                    if (contertedtext.contentEquals(MISDATA.get("messagetext"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The msg conversion is successfull</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The msg conversion is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @DataProvider
    public Object[][] getNTEXTSPECIFICROWforJUM_10326() {

        Object data[][] = ExcelUtils.getTestData("JUM_10326", 0, "TestData_TEXT.xlsx");

        return data;
    }

    @Test(dataProvider = "getCredencedata", priority = 1,  enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_CREDENCE_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String credenceCHECK) {
        try {
            Thread.sleep(10000);
        } catch (Exception e) {

        }

        String ph[]=TO.split("X");
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_CREDENCE CHECK--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", ph[1])
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("s","0");

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the credence system forwarding </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);


                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }

                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                             } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                Thread.sleep(5000);
//test

                if (true) {


                    String credendedata=JedisQueueReader.Getcredenceredisdata(responseid);
                    if(credendedata.isEmpty()&& credenceCHECK.contentEquals("YES"))
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The data is not found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+responseid+" but is was expected to be in Credence Q</b>");

                    }
                    else if(credendedata.isEmpty()&& credenceCHECK.contentEquals("NO"))
                    {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The data is not found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+responseid+" AND  is was ALSO NOT expected to be in Credence Q</b>");

                    }
                    else if((!credendedata.isEmpty()) && credenceCHECK.contentEquals("NO"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b> CREDENCE DATA IS---></b>"+credendedata);

                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The data  is  found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+responseid+" but is was NOT expected to be in Credence Q</b>");

                    }

                    else if((!credendedata.isEmpty()) && credenceCHECK.contentEquals("YES"))
                    {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST HAS BEEN  FORWARDED TO CREDENCE ,DATA IS---></b>"+credendedata);

                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The data is found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+responseid+" AND  is was ALSO  expected to be in Credence Q</b>");

                    }



                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON SMS ROUTER COMPONENT</b>");
                }







            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @DataProvider
    public Object[][] getCredencedata() {

        Object data[][] = ExcelUtils.getTestData("JUM-5768_CREDENCE", 0, "TestData_TEXT.xlsx");

        return data;

    }



    @Test(dataProvider = "getTEXTSHORTforWA", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_WA_TEXTLISTNER_SHORTING(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String s) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_WA_SIMPLE_SHORTING CHECK--> " + FunctionName + "</b>");
        try {
            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            String Ss = "";
            try {
                double stype = Double.parseDouble(s);
                int istype = (int) (Math.round(stype * 100) / 100);
                Ss = String.valueOf(istype);
            } catch (NumberFormatException e) {
                Ss = "";
            }

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request;

            if (Ss.contentEquals("3")) {
                request = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7838787657")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language);
            } else {
                request = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7838787657")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .param("s", Ss);
            }

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the WA SHORTING component</b>");

            Response response = request.post();

            Thread.sleep(2000);

            System.out.println("Request Object: " + request);
            int statusCode = response.getStatusCode();
            System.out.println("Status code: " + statusCode);

            boolean DLRCHECK = false;
            String WARECIEVRTABLENAME = "";

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response received");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");

                if (responseid.startsWith("-")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " response is  " + responseid);
                    Assert.assertTrue(false, " response is  " + responseid);
                }

                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get the receiver data from MIS for response id " + responseid);
                System.out.println("Response Object: " + responseid);

                // WA COMPONENT LOG CHECK
                if (ob.GetProperty("checkWAlog").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), false, "dummy", ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));

                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 207 WA ROUTER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));

                        if (Ss.contentEquals("1")) {
                            String check1 = "\"sto\":\"SHORT_URL_WA_PICKER_INPUT_QUEUE\"";
                            String check2 = "CommonUtility::sendToShortUrlRepository::appId -> " + APPID;

                            if (responseString.contains(check1) && responseString.contains(check2)) {
                                ExtentBASETEST.extentReportsDemo("INFO", "<b>For the request shortening flag was 1 and request successfully sent to SHORT URL component of WA and it has been verified in log. Both strings are found in log</b>"
                                        + " First string: " + check1
                                        + " Second string: " + check2);
                            }
                        }

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Below is the 207 WA COMPONENT log info --></b>" + responseString);

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 207 WA SERVER</b>");
                    }
                }

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String WADLRTABLENAME = Livetablename.get("WADLRTABLENAME");
                WARECIEVRTABLENAME = Livetablename.get("WARECIEVERTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROM_WA_RECIEVERTABLE(500, responseid, WARECIEVRTABLENAME);
                String joinid = "";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {

                    if (Ss.contentEquals("1")) {
                        String originalmessage = MISDATA.get("originalmessage");
                        String messagetext = MISDATA.get("messagetext");
                        Map shorturlresult = UrlShortenerValidator.RETURNSHORTRESULT(originalmessage, messagetext);
                        boolean shortresult = (boolean) shorturlresult.get("isShorteningpass");

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>The shorten URLs from message text are</b> --> " + shorturlresult.get("shortresult"));

                        if (shortresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTENED?</b> --> " + shorturlresult.get("isShorteningpass"));
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "<b>ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTENED?</b> --> " + shorturlresult.get("isShorteningpass"));
                        }
                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA --> " + MISDATA.toString());

                    String submitstatus = MISDATA.get("statusdesc");
                    if (submitstatus.contentEquals("submitted")) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>THE WA REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO WA</b>");
                        DLRCHECK = true;
                        joinid = MISDATA.get("joinid");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", " THE WA REQUEST HAS NOT BEEN SUCCESSFULLY SUBMITTED TO WA and actual status is " + submitstatus);
                        Assert.fail("THE WA REQUEST HAS NOT BEEN SUCCESSFULLY SUBMITTED TO WA and actual status is " + submitstatus);
                    }
                }

                Thread.sleep(10000);

                if (DLRCHECK) {
                    Map<String, String> DLRDATA = SQLPOOL.GETWADATAFROMDLRLIVETABLE(500, joinid, WADLRTABLENAME);

                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The WA DLRDATA could not be pulled from DB ");
                    } else {
                        if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully received and the current status of WA message is <b>SENT, DELIVERED, READ</b>");
                        } else if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully received and the current status of WA message is <b>SENT, DELIVERED</b>");
                        } else if (DLRDATA.containsValue("sent") && !DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully received and the current status of WA message is <b>SENT</b>");
                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "WA_DLRDATA --> " + DLRDATA.toString());
                    }
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
        }
    }

    @DataProvider
    public Object[][] getTEXTSHORTforWA() {

        Object data[][] = ExcelUtils.getTestData("ShortingWA1", 0, "TestData_TEXT.xlsx");

        return data;
    }



    @DataProvider
    public Object[][] getORCHESTRATOR() {
        Object data[][] = ExcelUtils.getTestData("ORCHESTRATOR", 0, "TestData_TEXT.xlsx");
        return data;
    }

    @Test(dataProvider = "getORCHESTRATOR", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_ORCHESTRATER_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String PARELLER, String SMS,String WA, String RCS,String P1,String P2, String P3) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>Orchestrator case--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the postive case for TEXT </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                System.out.println("Response Object  " + responseid);
                if(responseid.startsWith("-"))
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " response is  "+responseid);
                    Assert.assertTrue(false," response is  "+responseid);

                }

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                if(PARELLER.contentEquals("YES")) {

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>THIS IS PARELLEL CASE </b>");

                    if(SMS.contentEquals("SMS"))
                    {

                        ob.handleMessageType1(SMS, responseid);
                    }

                    if(RCS.contentEquals("RCS"))
                    {
                        ob.handleMessageType1(RCS, responseid);
                    }

                    if(WA.contentEquals("WA"))
                    {
                        ob.handleMessageType1(WA, responseid);
                    }
                }

            if(PARELLER.contentEquals("NO")) {
                ExtentBASETEST.extentReportsDemo("INFO", "<b>THIS IS PRIORITY CASE </b>");
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check first priority --> </b>"+P1);
                ob.handleMessageType1(P1, responseid);

                Thread.sleep(30000);
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check second priority --> </b>"+P2);
                ob.handleMessageType1(P2, responseid);
                Thread.sleep(30000);
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check third priority --> </b>"+P3);
                ob.handleMessageType1(P3, responseid);
            }



            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getRCS_NHOTESTDATA", priority = 1,  enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_JUM_13857_RCS_NHO_TEXTLISTNER_2026(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language ,String SHORT, String NHO_CODE) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
        // Reporter.log("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double stype = Double.parseDouble(SHORT);
            int istype = (int) (Math.round(stype * 100) / 100);
            String shortening = String.valueOf(istype);



            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470
            Response response= null;

            RequestSpecification request;

            if(shortening.contentEquals("3"))
            {
                request  = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7838787657")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language);
            } else{

                request   = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7838787657")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .param("s",shortening);

            }


            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the RCS component </b>");
            if(FunctionName.contains("UNICODE"))
            {
                response = request.get();
            }else {
                response = request.post();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String RCSRECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");

                if(responseid.startsWith("-"))
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " response is  "+responseid);
                    Assert.assertTrue(false," response is  "+responseid);

                }
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));

                        String nhoblank="\"nho\":\"\"";
                        if(NHO_CODE.contentEquals("NA") &&  responseString.contains(nhoblank))
                        {
                            ExtentBASETEST.extentReportsDemo("PASS", "<b> blank NHO_CODE "+nhoblank +" </b>"+ "  is present in the 85 RCS log");


                        }
                        else if(responseString.contains(NHO_CODE))
                        {
                            ExtentBASETEST.extentReportsDemo("PASS", "<b> "+NHO_CODE +" </b>"+ "  is present in the 85 RCS log"  );

                        }
                        else
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b> "+NHO_CODE +" </b>"+ "  is NOT present in the 85 RCS log" +responseString );

                        }

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {
                    if(MISDATA.get("templateid").isEmpty())
                    { ExtentBASETEST.extentReportsDemo("FAIL", "Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());
                        Assert.assertTrue(false,"Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());

                    }else {
                        ExtentBASETEST.extentReportsDemo("PASS", " <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());
                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(submitstatus.contentEquals("submitted"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                       if(NHO_CODE.contentEquals("NA"))
                       {
                         boolean b=  MISDATA.get("nho_code").isEmpty();
                         if(b) {
                             ExtentBASETEST.extentReportsDemo("PASS", " THE ACTUAL NHO CODE  " + MISDATA.get("nho_code") + "is matching with expected NHO " + NHO_CODE);
                         }else{
                             ExtentBASETEST.extentReportsDemo("FAIL", " THE ACTUAL NHO CODE  " + MISDATA.get("nho_code") + "is matching with expected NHO " + NHO_CODE);

                         }
                       }
                        else if(MISDATA.get("nho_code").contentEquals(NHO_CODE))
                        {
                            ExtentBASETEST.extentReportsDemo("PASS", " THE ACTUAL NHO CODE  "+MISDATA.get("nho_code")  +"is matching with expected NHO "+ NHO_CODE);


                        }
                        else
                        {
                            ExtentBASETEST.extentReportsDemo("FAIL", " THE ACTUAL NHO CODE  "+MISDATA.get("nho_code")  +"Does not match with expected NHO "+ NHO_CODE);

                        }

                    }
                    else {
                        ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                        Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                    }
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @DataProvider
    public Object[][] getRCS_NHOTESTDATA() {

        Object data[][] = ExcelUtils.getTestData("JUM-13857_RCS_NHO", 0, "TestData_TEXT.xlsx");

        return data;
    }




    @Test(dataProvider = "getTEXTDLTBLACKLIST", priority = 2, enabled = false, invocationCount = 1)
    public void Check_JUM_13854_DLTBALCKLIST_TEXTLISTENER_2026(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String dpi, String tc, String dtm,String Type) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_CHECK--> " + FunctionName + "</b>");
        try {
            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);
            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "8527607709")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE);
            if ("OPEN".equalsIgnoreCase(Type)) {
                request.param("dpi", dpi)
                        .param("tc", tc)
                        .param("dtm", dtm);
            }

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check MSG conversion for TEXT </b>");
            Response response = request.post();
            try {
                Thread.sleep(2000);
            } catch (Exception e) {


            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();


            System.out.println("Status code  " + statusCode);


            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response Object  " + responseid);

                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);



                String Statusdesc = MISDATA.get("statusdesc");

                if("Open".equalsIgnoreCase(Type) && FunctionName.contains("STATUS1")&& Statusdesc.contentEquals("TEMPLATE ID BLACKLISTED_SUBMISSION BLOCKED"))
                {
                    ExtentBASETEST.extentReportsDemo("PASS", "For Request type "+Type +" with DB status as 1 the Statusdec in MIS is " +Statusdesc);


                }
                else if("Open".equalsIgnoreCase(Type) && FunctionName.contains("STATUS0")&& Statusdesc.contentEquals("SUBMITTED TO SMSC"))
                {
                    ExtentBASETEST.extentReportsDemo("PASS", "For Request type "+Type +" with DB status as 1 the Statusdec in MIS is " +Statusdesc);

                }
                else if(!"Open".equalsIgnoreCase(Type) && Statusdesc.contentEquals("SUBMITTED TO SMSC"))
                {
                    ExtentBASETEST.extentReportsDemo("PASS", "For Request type "+Type +" with DB status as 0 the Statusdec in MIS is " +Statusdesc);


                }
                else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "For Request type "+Type +" with "+FunctionName+" the Statusdec in MIS is " +Statusdesc);

                }



            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());
        }
    }


    @DataProvider
    public Object[][] getTEXTDLTBLACKLIST() {
        Object data[][] = ExcelUtils.getTestData("DLTBLACKLIST", 0, "TestData_TEXT.xlsx");
        return data;
    }


    @DataProvider
    public Object[][] getNTEXTdetailsDLRCAMELJUM12867_JUM13886() {
        Object data[][] = ExcelUtils.getTestData("CAMELCASE", 0, "TestData_TEXT.xlsx");
        return data;
    }


    @Test(dataProvider = "getNTEXTdetailsDLRCAMELJUM12867_JUM13886", priority = 1, enabled = false, invocationCount = 1)
    public void getNTEXTDLRCAMELCASEJUM12867_JUM13886_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID,
                                                                  String FROM, String TO, String MSG, String ALERT,
                                                                  String SELFID, String INTFLAG, String Contenttype, String Language,
                                                                  String MSGDETAIL,String MOBILE, String STATUS, String OPERATOR,
                                                                  String SENDERID, String ENTID, String SMSCFLAG,
                                                                  String INTF, String ENO, String B) {

        ExtentBASETEST.STARTTEST("Request URL--> " + ob.GetProperty("QA_AWS_TEXT_BASE_URI") +
                " <b>TEXT Listener Test --> " + FunctionName + "</b>");

        try {

            String SCTYPE = String.valueOf((int) Double.parseDouble(Contenttype));
            String AALERT = String.valueOf((int) Double.parseDouble(ALERT));
            if (Language.equalsIgnoreCase("BLK")) Language = "";

            // ================= TEXT API HIT =================
            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "918130421064")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Hitting TEXT API</b>");

            Response response = request.post();
            int statusCode = response.getStatusCode();

            if (statusCode != 200) {
                ExtentBASETEST.extentReportsDemo("FAIL", "TEXT API failed: " + statusCode);
                Assert.fail("TEXT API failed");
            }

            String responseid = response.asString().replaceAll("[\\n\\t ]", "");


            ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
            System.out.println("Response Object  " + responseid);

            ExtentBASETEST.extentReportsDemo("INFO",
                    "<b style='color:green;'>ResponseId: " + responseid + "</b>");

            String joinId = null;
            String messageId = null;
            String respId = responseid;

            // ================= PROCESSOR LOG CHECK =================
            if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                Thread.sleep(2000);

                boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(
                        responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                if (LISTNERPROCESSORSERVERRESULT) {
                    ExtentBASETEST.extentReportsDemo("INFO",
                            "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                    String logData = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(
                            responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                    joinId = TestBase.extractValue(logData, "joinId");
                    messageId = TestBase.extractValue(logData, "messageId");
                    String extractedRespId1 = TestBase.extractValue(logData, "responseId");

                    if (joinId == null) joinId = "NA";
                    if (messageId == null) messageId = "NA";
                    if (extractedRespId1 != null) respId = extractedRespId1;

                } else {
                    ExtentBASETEST.extentReportsDemo("INFO",
                            "<b>Log info could not be detected on 205 processor SERVER</b>");
                }
            }

            // ================= ORCHESTRATOR LOG CHECK =================
            if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                Thread.sleep(2000);
                boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                if (LISTNERPROCESSORSERVERRESULT) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                    String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));


                    String orchRespId = TestBase.extractValue(responseString, "Responseid");
                    if (orchRespId != null) {
                        ExtentBASETEST.extentReportsDemo("INFO",
                                "<b style='color:green;'>ResponseId (Orchestrator): " + orchRespId + "</b>");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "<b> Orchestrator ResponseId:</b> " + "<span style='background-color:#FFFF00; color:#000000; font-weight:bold; padding:2px 8px;'>" + responseid + "</span>");
            }

            // ================= joinId / messageId VALIDATION =================
            if (joinId == null || joinId.equals("NA") || messageId == null || messageId.equals("NA")) {
                ExtentBASETEST.extentReportsDemo("FAIL",
                        "<b style='color:red;'>joinId/messageId not not found in Processor logs</b>");
                Assert.fail("joinId/messageId not found in Processor logs");
                return;
            }

            Thread.sleep(5000);

            ExtentBASETEST.extentReportsDemo("INFO",
                    "<b style='color:purple;'>MsgDetail (from sheet):</b> " + MSGDETAIL);

            String dlrBaseUrl = ob.GetProperty("DLR_BASE_URL");

            String dlrUrl = dlrBaseUrl + "?"
                    + "joinid=" + joinId
                    + "&msgid=" + messageId
                    + "&responseid=" + respId
                    + "&mobile=" + MOBILE
                    + "&status=" + STATUS
                    + "&operator=" + OPERATOR
                    + "&msgdetail=" + MSGDETAIL
                    + "&senderid=" + SENDERID
                    + "&entid=" + ENTID
                    + "&smscflag=" + SMSCFLAG
                    + "&intf=" + INTF
                    + "&eno=" + ENO
                    + "&b=" + B;

            ExtentBASETEST.extentReportsDemo("INFO",
                    "<b style='color:blue;'>DLR API URL:</b><br>" + dlrUrl);

            Response dlrResponse = RestAssured.get(dlrUrl);

            ExtentBASETEST.extentReportsDemo("INFO",
                    "<b>DLR API Status Code: </b>" + dlrResponse.getStatusCode());


            Thread.sleep(5000);

            boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(
                    responseid, responseid, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), false, "DUMMY", ob.GetProperty("dlrloglocation98"), ob.GetProperty("dlrlogfileName"));
            System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + DLRresult);

            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");

            JSONObject DLRjsonbody = null;

            try {
                DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(
                        responseid,
                        ob.GetProperty("Username98"),
                        ob.GetProperty("Password98"),
                        ob.GetProperty("hostname98"),
                        false, "DUMMY",
                        ob.GetProperty("dlrloglocation98"),
                        ob.GetProperty("dlrlogfileName"));
            } catch (Exception e) {
                System.out.println("GETDLRJSONLOG failed: " + e.getMessage());
            }

            if (DLRresult) {
                ExtentBASETEST.extentReportsDemo("PASS",
                        "<b style='color:green;'>DLR RECEIVED IN LOG</b>");

                if (DLRjsonbody != null) {
                    ExtentBASETEST.extentReportsDemo("INFO",
                            "<b style='color:blue;'>DLR LOG JSON:</b><br><pre>" + DLRjsonbody.toString() + "</pre>");
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO",
                            "<b style='color:orange;'>DLR JSON </b>");
                }
            }


            String allDlrLogs = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(
                    responseid, ob.GetProperty("Username98"), ob.GetProperty("Password98"), ob.GetProperty("hostname98"), ob.GetProperty("dlrloglocation98"), ob.GetProperty("dlrlogfileName"));
            if (!allDlrLogs.isEmpty()) {

                ExtentBASETEST.extentReportsDemo("INFO",
                        "<b style='color:teal;'>===== DLR SERVER LOGS (grep: " + respId + ") =====</b><br><pre>" + allDlrLogs + "</pre>");

                String msgDetailValue = "NOT FOUND";
                String[] logLines = allDlrLogs.split("\n");
                for (String line : logLines) {
                    if (line.contains("DLRRequestListener::DLR REQUEST HANDLER") && line.contains("msgdetail=id%3A")) {
                        java.util.regex.Pattern pattern = java.util.regex.Pattern
                                .compile("msgdetail=(id%3A[^,}]+)");
                        java.util.regex.Matcher matcher = pattern.matcher(line);
                        if (matcher.find()) {
                            msgDetailValue = matcher.group(1).trim();
                        }
                        break;
                    }
                }

                System.out.println("MsgDetail from Sheet --> " + MSGDETAIL);
                System.out.println("MsgDetail from Log   --> " + msgDetailValue);

                if (!msgDetailValue.equals("NOT FOUND")) {

                    ExtentBASETEST.extentReportsDemo("PASS",
                            "<b style='color:green;'>MsgDetail from DLR Log:</b> " +
                                    "<span style='background-color:#FFFF00; color:#000000; font-weight:bold; padding:2px 6px;'>" +
                                    msgDetailValue +
                                    "</span>");

                    if (MSGDETAIL.trim().equals(msgDetailValue.trim())) {
                        ExtentBASETEST.extentReportsDemo("PASS",
                                "<b style='color:green;'>✅ MsgDetail MATCHED — Sheet value and Log value are SAME</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL",
                                "<b style='color:red;'> MsgDetail MISMATCH</b><br>" +
                                        "<b>Sheet Value:</b> <span style='background-color:#FFD700;'>" + MSGDETAIL + "</span><br>" +
                                        "<b>Log Value &nbsp;:</b> <span style='background-color:#FF6347; color:white;'>" + msgDetailValue + "</span>");
                        Assert.fail("MsgDetail mismatch — Sheet: " + MSGDETAIL + " | Log: " + msgDetailValue);
                    }

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL",
                            "<b style='color:red;'> MsgDetail NOT FOUND in DLR logs</b>");
                    Assert.fail("MsgDetail NOT FOUND in DLR logs for respId: " + respId);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("INFO",
                        "<b style='color:orange;'>DLR Logs EMPTY or NOT FOUND for respId: " + respId + "</b>");
                System.out.println("DLR Logs --> EMPTY OR NOT FOUND");
            }

            // ================= DB CHECK =================
            TestBase.setcurrenttime();
            Thread.sleep(2000);

            Map<String, String> tableMap = TestBase.Normal_calculateandsetlivetablename();
            String dlrTable = tableMap.get("DLRTABLENAME");

            boolean dlrReceived = SQLPOOL.CheckMysqlDLRTABLE(respId, dlrTable);

            if (dlrReceived) {

                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(
                        1000, respId, dlrTable);

                if (DLRDATA == null || DLRDATA.isEmpty()) {
                    Assert.fail("DLRDATA empty");
                }

                ExtentBASETEST.extentReportsDemo("PASS",
                        "<b style='color:green;'>DLR FOUND IN DB</b><br>");

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL",
                        "<b style='color:red;'>DLR NOT FOUND IN DB</b>");
                Assert.fail("DLR NOT FOUND IN DB");
            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.toString());
        }

    }

    @Test(dataProvider = "getdlthashiddata",
            priority = 1,
            enabled = false,
            invocationCount = SetandGetGlobalVariable.count)

    public void dlthashid_TEXTLISTNER_JUM_13865_JUM_13864



            (String FunctionName, String UserID, String Passd,
                                      String APPID, String FROM, String TO, String MSG,
                                      String ALERT, String SELFID, String INTFLAG,
                                      String Contenttype, String Language,
                                      String dtm, String dpi, String dlthashid) {
        try {
            Thread.sleep(10000);
            String ph[] = TO.split("X");
            ExtentBASETEST.STARTTEST("Request URL--> " +
                    ob.GetProperty("QA_AWS_NTEXT_BASE_URI") +
                    " <b>TEXTLISTNER_dlthashid request submitted--> "
                    + FunctionName + "</b>");
            // Content Type Conversion
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) Math.round(ctype);
            String SCTYPE = String.valueOf(ictype);

            // Alert Conversion
            double alertType = Double.parseDouble(ALERT);
            int iAlertType = (int) Math.round(alertType);
            String AALERT = String.valueOf(iAlertType);

            double dtmtype = Double.parseDouble(dtm);
            int dtmtype1 = (int) Math.round(dtmtype);
            String dtmtype2 = String.valueOf(dtmtype1);

            double dpitype = Double.parseDouble(dpi);
            int dpitype1 = (int) Math.round(dpitype);
            String dpitype2 = String.valueOf(dpitype1);

           /* double dlthashidtype = Double.parseDouble(dlthashid);
            int dlthashidtype1 = (int) Math.round(dlthashidtype);
            String dlthashidtype2 = String.valueOf(dlthashidtype1);*/

            // Language BLK Handling
            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            // API Request
            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", TO)
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("dltHashId", dlthashid)
                    .param("dtm", dtmtype2)
                    .param("dpi", dpitype2);

            ExtentBASETEST.extentReportsDemo("INFO",
                    "<b>Going to hit the API for text Listener</b>");
            //request.log().uri();
            //request.log().headers();
            //request.log().params();
            System.out.println("API REQUEST SUBMITTED-->"   + RestAssured.baseURI);
            Thread.sleep(2000);
            Response response = request.post();
            Thread.sleep(2000);
            int statusCode = response.getStatusCode();
            //System.out.println("Status code: " + statusCode);

            // Status Code Validation
            if (statusCode == 200) {

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response received");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response received 200 and RESPONSE ID:--> " + responseid);
                // ==========================
                // LISTENER LOG CHECK
                // ==========================
                if (ob.GetProperty("Check98log").contentEquals("true")) {
                    Thread.sleep(2000);
                    //dlthashid verification
                    boolean result1=
                            LinuxLogReader.CheckcommondhsiLOG(
                                    responseid,dlthashid,
                                    ob.GetProperty("Username187"),
                                    ob.GetProperty("Password187"),
                                    ob.GetProperty("hostname187"),
                                    true,
                                    MSG,
                                    ob.GetProperty("commonloglocation187"),
                                    ob.GetProperty("rcvrlogfileName"));

                    if (result1) {
                        ExtentBASETEST.extentReportsDemo("INFO",
                                "dhsi RECEIVED ON 187 Listener SERVER ---> <b>" + dlthashid + "</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO",
                                "dhsi not RECEIVED ON 187 Listener SERVER ---> <b>" + dlthashid + "</b>");
                    }

                }


                // ==========================
                // PROCESSOR LOG CHECK
                // ==========================
                if (ob.GetProperty("Checkprocessorlog")
                        .contentEquals("true")) {

                    Thread.sleep(5000);
                    //dlthashid verification
                    boolean result1 =
                            LinuxLogReader.CheckcommondhsiLOG(
                                    responseid,dlthashid,
                                    ob.GetProperty("Username205"),
                                    ob.GetProperty("Password205"),
                                    ob.GetProperty("hostname205"),
                                    true,
                                    MSG,
                                    ob.GetProperty("commonloglocation205"),
                                    ob.GetProperty("rcvrlogfileName"));

                    if (result1) {
                        ExtentBASETEST.extentReportsDemo("INFO",
                                "dhsi RECEIVED ON 208 processor SERVER ---> <b>" + dlthashid + "</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO",
                                "dhsi not RECEIVED ON 208 processor SERVER ---> <b>" + dlthashid + "</b>");
                    }

                }

                //Router  LOG CHECK
              /*  if (ob.GetProperty("CheckRouterlog").contentEquals("true")) {
                    Thread.sleep(30000);
                    boolean ROUTERSERVERRESULT = LinuxLogReader.CheckROUTERLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    if (ROUTERSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 207 router SERVER</b>");
                        System.out.println("Router Yes");
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 207 router SERVER</b>");
                    }

                }*/

                if (ob.GetProperty("CheckRouterlog").contentEquals("true")) {

                    boolean ROUTERSERVERRESULT = false;
                    int maxWait = 60;      // total seconds
                    int interval = 10;      // check every 10 sec
                    int waited = 0;

                    while (waited < maxWait) {

                        ROUTERSERVERRESULT = LinuxLogReader.CheckcommondhsiLOG(
                                responseid,dlthashid,
                                ob.GetProperty("Username207"),
                                ob.GetProperty("Password207"),
                                ob.GetProperty("hostname207"),
                                true,
                                MSG,
                                ob.GetProperty("commonloglocation207"),
                                ob.GetProperty("rcvrlogfileName")
                        );

                        if (ROUTERSERVERRESULT) {
                            System.out.println("Router Yes (found in " + waited + " sec)");
                            break;  // ✅ mil gaya → exit early
                        }

                        Thread.sleep(interval * 1000); // wait 5 sec
                        waited += interval;
                    }

                    if (ROUTERSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO",
                                "REQUEST RECEIVED ON 207 router SERVER");
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO",
                                "Log not detected ON 207 router SERVER after 40 sec");
                    }
                }

                if (ob.GetProperty("CheckRouterlog").contentEquals("true")) {
                    boolean ROUTERSERVERRESULT = LinuxLogReader.CheckcommondhsiLOG(responseid,dlthashid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    if (ROUTERSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO",  "dhsi RECEIVED ON 207 router SERVER ---> <b>" + dlthashid + "</b>");
                        System.out.println("Router Yes");
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "dhsi not RECEIVED ON 207 router SERVER ---> <b>" + dlthashid + "</b>");
                    }



                    //DLR log check

                    if (ob.GetProperty("CheckDLRlog").contentEquals("true")) {

                        Thread.sleep(2000);
                        // Step 2: DHSI / dlthashid check on DLR

                        boolean result1 =
                                LinuxLogReader.CheckcommondhsiLOG(
                                        responseid,dlthashid,
                                        ob.GetProperty("Username981"),
                                        ob.GetProperty("Password981"),
                                        ob.GetProperty("hostname981"),
                                        true,
                                        MSG,
                                        ob.GetProperty("commonloglocation981"),
                                        ob.GetProperty("DLRFILENAME"));

                        // ✅ Safe extraction from result1
                        if (result1) {
                            ExtentBASETEST.extentReportsDemo("INFO",
                                    "dhsi RECEIVED ON 98 DLR SERVER ---> <b>" + dlthashid + "</b>");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO",
                                    "dhsi not RECEIVED ON 98 DLR SERVER ---> <b>" + dlthashid + "</b>");
                        }

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL",
                                "Status code is not success");
                        Assert.fail("Status code is not success");
                    }

//DLR Retry logs

                    if (ob.GetProperty("CheckDLRlog").contentEquals("true")) {

                        Thread.sleep(2000);

                        // Step 2: DHSI / dlthashid check on DLR RETRY
                        boolean result1 =
                                LinuxLogReader.CheckcommondhsiLOG(
                                        responseid,dlthashid,
                                        ob.GetProperty("Username981"),
                                        ob.GetProperty("Password981"),
                                        ob.GetProperty("hostname981"),
                                        true,
                                        MSG,
                                        ob.GetProperty("commonloglocation982"),
                                        ob.GetProperty("DLRRETRYFILENAME"));

                        // ✅ Safe extraction from result1
                        if (result1) {
                            ExtentBASETEST.extentReportsDemo("INFO",
                                    "dhsi RECEIVED ON 98 DLR RETRY SERVER ---> <b>" + dlthashid + "</b>");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO",
                                    "dhsi not RECEIVED ON 98 DLR RETRY SERVER ---> <b>" + dlthashid + "</b>");
                        }

                        //141 Listener ping
                        if (ob.GetProperty("CheckURLlog").contentEquals("true")) {

                            Thread.sleep(2000);

                            // Step 2: DHSI / dlthashid check on 141
                            boolean result =
                                    LinuxLogReader.CheckcommondhsiLOG(
                                            responseid,dlthashid,
                                            ob.GetProperty("Username1411"),
                                            ob.GetProperty("Password1411"),
                                            ob.GetProperty("hostname1411"),
                                            true,
                                            MSG,
                                            ob.GetProperty("commonloglocation1411"),
                                            ob.GetProperty("URLListenerENAME"));

                            // ✅ Safe extraction from result1
                            if (result) {
                                ExtentBASETEST.extentReportsDemo("INFO",
                                        "dhsi RECEIVED ON 141 URL Listener SERVER ---> <b>" + dlthashid + "</b>");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO",
                                        "dhsi RECEIVED ON 141 URL Listener SERVER ---> <b>" + dlthashid + "</b>");
                            }


                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL",
                                    "Status code is not success");
                            Assert.fail("Status code is not success");
                        }
                    }

                }
//DLR check in MIS TABLE
                boolean DLRCHECK1 = false;
                String DLRLivetablename = "";
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));

                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "MSG", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + responseid + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    System.out.println("pushreceivertablename"+PushRecieverLivetablename);
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    System.out.println("DLRLivetablename"+DLRLivetablename);
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        DLRCHECK1 = true;

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    }
                    System.out.println(MISDATA);
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    System.out.println("pushreceivertablename2"+PushRecieverLivetablename);
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    System.out.println("DLRLivetablename2"+DLRLivetablename);
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                    System.out.println("MISDATA content: " + MISDATA);

                    if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {
                        System.out.println("Loop content:");
                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                        System.out.println("PASS DLRCHECK1");
                        DLRCHECK1 = true;
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    }

                    System.out.println("DLRCHECK: " + DLRCHECK1);
                    System.out.println("ResponseID: '" + responseid + "'");
                    System.out.println("DLR table: " + DLRLivetablename);
                }

                if (DLRCHECK1)
                {
                    //v System.out.println("DLR code check karne jata h kya");
                    boolean result = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username981"), ob.GetProperty("Password981"), ob.GetProperty("hostname981"), false, "DUMMY", ob.GetProperty("commonloglocation981"), ob.GetProperty("DLRFILENAME"));
                    System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + result);

                    if (result) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    } else {
                        System.out.println("DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }

                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            System.out.println("DLR is found in MIS DLR TAble" +DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }


                    }
                }
                ExtentBASETEST.extentReportsDemo("INFO", "DLR TEST EXECUTED");



            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getdlthashiddata() {

        Object data[][] =
                ExcelUtils.getTestData(
                        "JUM-12171_dlthashid",
                        0,
                        "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getTEXTSHORTRouter() {

        Object data[][] = ExcelUtils.getTestData("ShortingRouter", 0, "TestData_TEXT.xlsx");

        return data;
    }

    @Test(dataProvider = "getTEXTSHORTRouter", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_TEXTLISTNER_ROUTERSHORTING_JUM10726_13859_138601(String FunctionName, String UserID, String Passd, String APPID,
                                                                       String FROM, String TO, String MSG, String ALERT, String SELFID,
                                                                       String INTFLAG, String Contenttype, String Language, String s) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") +
                " " + "<b>TEXTLISTNER_ROUTER_SHORTING CHECK--> " + FunctionName + "</b>");

        try {
            // ===== Content Type =====
            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            // ===== Alert =====
            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);


            String Ss = "";
            try {
                double stype = Double.parseDouble(s);
                int istype = (int) (Math.round(stype * 100) / 100);
                Ss = String.valueOf(istype);
            } catch (NumberFormatException e) {
                Ss = "";
            }

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            boolean useShortingParam = "1".equals(Ss) || "0".equals(Ss);


            Response response;

            if (useShortingParam) {

                ExtentBASETEST.extentReportsDemo("INFO", "<b>Hitting API with 'Optional' s param → s=" + Ss + "</b>");
                response = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7838787657")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .param("s", Ss)
                        .post();
            } else {

                ExtentBASETEST.extentReportsDemo("INFO", "<b>Hitting API with 'Default' param</b>");
                response = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7838787657")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .post();
            }


            int statusCode = response.getStatusCode();
            System.out.println("Status code: " + statusCode);

            if (statusCode == 200) {

                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response ID: " + responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "<b>API Response Received | Status Code: 200 | Response ID: " + responseid + "</b>");

                // ===== Processor Log Check =====
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(
                            responseid,
                            ob.GetProperty("Username205"),
                            ob.GetProperty("Password205"),
                            ob.GetProperty("hostname205"),
                            true,
                            MSG,
                            ob.GetProperty("commonloglocation205"),
                            ob.GetProperty("PROCESSORLOGFILENAME")
                    );

                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECEIVED ON 208 PROCESSOR SERVER</b>");
                        String processorLogString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(
                                responseid,
                                ob.GetProperty("Username205"),
                                ob.GetProperty("Password205"),
                                ob.GetProperty("hostname205"),
                                ob.GetProperty("commonloglocation205"),
                                ob.GetProperty("PROCESSORLOGFILENAME")
                        );

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Processor 208 Full Logs:</b><br>" + processorLogString.replace("\n", "<br>"));

                        // SD value extract and validate
                        String[] processorLines = processorLogString.split("\n");
                        for (String pline : processorLines) {
                            if (pline.contains("makeJsonForRedis")) {
                                String sdValue = TestBase.extractFromLog(pline, "sd");
                                if (!sdValue.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Processor Log | Response ID: </b>" + responseid + " | <b>SD Value: </b>" + sdValue);
                                    if (sdValue.contains("Template Not Found at ACL")) {
                                        ExtentBASETEST.extentReportsDemo("FAIL", " In Processor Logs Template Not Found at ACL " + sdValue);
                                        Assert.fail("Processor SD: " + sdValue);
                                    }
                                }
                            }
                        }

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 208 PROCESSOR SERVER</b>");
                    }
                }

                //  Router 207 log =====
                Thread.sleep(5000);

                boolean smscFound = LinuxLogReader.CheckSMSCLOG(
                        responseid,
                        ob.GetProperty("Username207"),
                        ob.GetProperty("Password207"),
                        ob.GetProperty("hostname207"),
                        false,
                        "DUMMY",
                        ob.GetProperty("commonloglocation207"),
                        ob.GetProperty("rcvrlogfileName")
                );

                if (!smscFound) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "ResponseID not found in Router 207 log: " + responseid);
                    Assert.fail("207 log not found for ResponseID: " + responseid);
                }

                ExtentBASETEST.extentReportsDemo("INFO", "<b>ResponseID received on Router 207</b>");


                String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(
                        responseid,
                        ob.GetProperty("Username207"),
                        ob.GetProperty("Password207"),
                        ob.GetProperty("hostname207"),
                        ob.GetProperty("commonloglocation207"),
                        ob.GetProperty("rcvrlogfileName")
                );

                ExtentBASETEST.extentReportsDemo("INFO", "<b>Router 207 Full Logs:</b><br>" + responseString.replace("\n", "<br>"));


                String[] logLines = responseString.split("\n");

                StringBuilder sentToShortUrlLogs = new StringBuilder();
                StringBuilder shortUrlQueueLogs = new StringBuilder();
                StringBuilder mxShortenedLogs = new StringBuilder();
                String detectedQueueName = "";

                for (String line : logLines) {


                    if (line.contains("SentToShorturl")) {
                        sentToShortUrlLogs.append(line).append("<br>");
                    }


                    if (line.contains("SHORTURL_")) {
                        shortUrlQueueLogs.append(line).append("<br>");
                        if (detectedQueueName.isEmpty()) {
                            detectedQueueName = TestBase.extractFromLog(line, "SHORTURL_");
                        }
                    }

                    if (line.contains("JEDIS MIS REQUEST")) {
                        String mxValue = TestBase.extractFromLog(line, "mx");
                        if (!mxValue.isEmpty()) {
                            mxShortenedLogs.append(mxValue).append("<br>");
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>mx value: </b>" + mxValue);
                        }
                    }
                }


                if (sentToShortUrlLogs.length() > 0) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>SentToShorturl log found:</b><br>" + sentToShortUrlLogs);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "SentToShorturl log NOT found in Router 207 logs for ResponseID: " + responseid);
                    Assert.fail("SentToShorturl log not found — Shortening request was not sent");
                }


                if (shortUrlQueueLogs.length() > 0) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Short URL Queue detected: [" + detectedQueueName + "]</b>");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "No SHORTURL_ queue found in Router 207 logs for ResponseID: " + responseid);
                    Assert.fail("SHORTURL_ queue not found in Router 207 logs");
                }


                if (mxShortenedLogs.length() > 0) {
                    ExtentBASETEST.extentReportsDemo("PASS", "Shortening PASSED at Router 207");
                    Assert.assertTrue(true);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Shortened URL  NOT found in mx field for ResponseID: " + responseid);
                    Assert.fail("mx field does not contain shortened URL (acl.cc domain missing)");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "API returned non-200 status code: " + statusCode);
                Assert.fail("Status code is not 200, actual: " + statusCode);
            }

        } catch (Exception e) {
            e.printStackTrace();
            ExtentBASETEST.extentReportsDemo("INFO", "Exception occurred: " + e.toString());
            Assert.fail(e.toString());
        }
    }
    @Test(dataProvider = "get_JUM_12075", priority = 2, enabled = false, invocationCount = 1)
    public void Check_JUM_12075_13885TEXTLISTENER(String FunctionName, String UserID, String Passd, String APPID,
                                                  String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG,
                                                  String Contenttype, String dpi, String dtm, String dltHashId) throws Exception {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " "
                + "<b>TEXTLISTNER_DPI_DTM_TC_CHECK--> " + FunctionName + "</b>");

        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);


            if (dpi == null || dpi.contentEquals("BLK"))             dpi = "";
            if (dtm == null || dtm.contentEquals("BLK"))             dtm = "";
            if (dltHashId == null || dltHashId.contentEquals("BLK")) dltHashId = "";


            RequestSpecification request = RestAssured.given()
                    .param("appid",       APPID)
                    .param("userId",      UserID)
                    .param("pass",        Passd)
                    .param("from",        FROM)
                    .param("to",          "918527607709")
                    .param("text",        MSG)
                    .param("alert",       AALERT)
                    .param("selfid",      SELFID)
                    .param("intflag",     INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("dpi",         dpi)
                    .param("dtm",         dtm);

            if (!dltHashId.isEmpty()) {
                request = request.param("dltHashId", dltHashId);
            }

            ExtentBASETEST.extentReportsDemo("INFO",
                    "<b>Going to hit the API to check MSG conversion for TEXT</b>");

            Response response = request.post();

            Thread.sleep(2000);

            System.out.println("Request Object: " + request);
            int statusCode = response.getStatusCode();
            System.out.println("Status code: " + statusCode);

            // ===== Status 200 Block =====
            if (statusCode == 200) {

                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response ID: " + responseid);
                ExtentBASETEST.extentReportsDemo("INFO",
                        "<b>API Response Received | Status Code: 200 | Response ID: " + responseid + "</b>");

                // ===== Processor (205) Log Check =====
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(
                            responseid,
                            ob.GetProperty("Username205"),
                            ob.GetProperty("Password205"),
                            ob.GetProperty("hostname205"),
                            true,
                            MSG,
                            ob.GetProperty("commonloglocation205"),
                            ob.GetProperty("PROCESSORLOGFILENAME")
                    );

                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO",
                                "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                        String processorLogString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(
                                responseid,
                                ob.GetProperty("Username205"),
                                ob.GetProperty("Password205"),
                                ob.GetProperty("hostname205"),
                                ob.GetProperty("commonloglocation205"),
                                ob.GetProperty("PROCESSORLOGFILENAME")
                        );

                        ExtentBASETEST.extentReportsDemo("INFO",
                                "<b> below is the 205 processor server log info--> </b>" + processorLogString);


                        String[] processorLines = processorLogString.split("\n");
                        String actualProcessorSD = "";

                        for (String pline : processorLines) {
                            if (pline.contains("makeJsonForRedis")) {
                                String sdValue = TestBase.extractFromLog(pline, "sd");
                                if (!sdValue.isEmpty()) {
                                    actualProcessorSD = sdValue;
                                    ExtentBASETEST.extentReportsDemo("INFO",
                                            "<b>Processor 205 Log | Response ID: </b>" + responseid
                                                    + " | <b>SD Value: </b>" + actualProcessorSD);
                                }
                            }
                        }




                        if (actualProcessorSD.contains("DTM not found for HASH ID process")) {
                            ExtentBASETEST.extentReportsDemo("PASS",
                                    "<b>Processor 205 SD: DTM not found for HASH ID process | PASS</b>");
                            return;


                        } else if (actualProcessorSD.contains("DPI not found for HASH ID process")) {
                            ExtentBASETEST.extentReportsDemo("PASS",
                                    "<b>Processor 205 SD: DPI not found for HASH ID process | PASS</b>");
                            return;


                        } else if (actualProcessorSD.contains("Template Not Found at ACL")) {
                            ExtentBASETEST.extentReportsDemo("FAIL",
                                    "<b>Processor 205 SD: Template Not Found at ACL | FAIL</b>");
                            Assert.fail("Processor 205 SD: Template Not Found at ACL | Got: " + actualProcessorSD);
                            return;

                        } else if (actualProcessorSD.contains("SUBMITED TO BUFFER MANAGER")) {
                            ExtentBASETEST.extentReportsDemo("PASS",
                                    "<b>Processor 205 SD: SUBMITED TO BUFFER MANAGER | Going to check Router 207</b>");

                            Thread.sleep(5000);
                            boolean smscFound = LinuxLogReader.CheckSMSCLOG(
                                    responseid,
                                    ob.GetProperty("Username207"),
                                    ob.GetProperty("Password207"),
                                    ob.GetProperty("hostname207"),
                                    false,
                                    "DUMMY",
                                    ob.GetProperty("commonloglocation207"),
                                    ob.GetProperty("rcvrlogfileName")
                            );

                            if (smscFound) {
                                ExtentBASETEST.extentReportsDemo("INFO",
                                        "<b>REQUEST RECIEVED ON 207 ROUTER SERVER</b>");

                                String routerLogString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(
                                        responseid,
                                        ob.GetProperty("Username207"),
                                        ob.GetProperty("Password207"),
                                        ob.GetProperty("hostname207"),
                                        ob.GetProperty("commonloglocation207"),
                                        ob.GetProperty("rcvrlogfileName")
                                );

                                ExtentBASETEST.extentReportsDemo("INFO",
                                        "<b> below is the 207 router server log info--> </b>" + routerLogString);


                                String[] routerLines = routerLogString.split("\n");
                                boolean sdFoundInRouter = false;

                                for (String rline : routerLines) {
                                    if (rline.contains("JEDIS MIS REQUEST")) {
                                        String routerSdValue = TestBase.extractFromLog(rline, "sd");
                                        if (!routerSdValue.isEmpty()) {
                                            sdFoundInRouter = true;
                                            ExtentBASETEST.extentReportsDemo("INFO",
                                                    "<b>Router 207 Log | Response ID: </b>" + responseid
                                                            + " | <b>SD Value: </b>" + routerSdValue);

                                            if (routerSdValue.contains("SUBMITTED TO SMSC")) {
                                                ExtentBASETEST.extentReportsDemo("PASS",
                                                        "<b>Router 207 SD Verified: SUBMITTED TO SMSC | PASS</b>");
                                            } else {
                                                ExtentBASETEST.extentReportsDemo("FAIL",
                                                        "Router 207 SD is NOT 'SUBMITTED TO SMSC'. Got: " + routerSdValue);
                                                Assert.fail("Router 207 SD check failed. Expected: SUBMITTED TO SMSC | Got: " + routerSdValue);
                                            }
                                        }
                                    }
                                }

                                if (!sdFoundInRouter) {
                                    ExtentBASETEST.extentReportsDemo("FAIL",
                                            "SD key not found in Router 207 logs for ResponseID: " + responseid);
                                    Assert.fail("SD not found in Router 207 log for ResponseID: " + responseid);
                                }

                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO",
                                        "<b>Log info could not be detected on 207 ROUTER SERVER</b>");
                            }


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO",
                                    "<b>Processor 205 SD Value: </b>" + actualProcessorSD);
                        }

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO",
                                "<b>Log info could not be detected on 205 processor SERVER</b>");
                    }
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL",
                        "<b>Unexpected Status Code: " + statusCode + "</b>");
                Assert.fail("Status code was not 200. Received: " + statusCode);
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", "Exception occurred: " + e.getMessage());
            Assert.fail("Test failed due to exception: " + e.getMessage());
        }
    }


    @DataProvider
    public Object[][] get_JUM_12075() {
        Object data[][] = ExcelUtils.getTestData("JUM_12075", 0, "TestData_TEXT.xlsx");
        return data;
    }

    @Test(dataProvider = "getRCSTESTDATAFORTTL", priority = 1,  enabled = false, invocationCount = 1)
    public void CHECK_RCS_TEXTLISTNER_JUM_13870_2026(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language ,String SHORT) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK FOR TTL--> " + FunctionName + "</b>");
        // Reporter.log("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double stype = Double.parseDouble(SHORT);
            int istype = (int) (Math.round(stype * 100) / 100);
            String shortening = String.valueOf(istype);



            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470
            Response response= null;

            RequestSpecification request;

            if(shortening.contentEquals("3"))
            {
                request  = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "9918702626")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language);
            } else{

                request   = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "9918702626")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .param("s",shortening);
            }


            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the RCS component </b>");
            if(FunctionName.contains("UNICODE"))
            {
                response = request.get();
            }else {
                response = request.post();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String RCSRECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");

                if(responseid.startsWith("-"))
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " response is  "+responseid);
                    Assert.assertTrue(false," response is  "+responseid);

                }
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                       String ttl="\"ttl\":\"25s\"";

                        if(responseString.contains(ttl))
                        {
                            ExtentBASETEST.extentReportsDemo("PASS", "<b> For the request TTL information is present in log</b>" +" --> "+ ttl );

                        }
                        else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "<b> For the request TTL information is not present in log</b>" +" --> "+ ttl );

                        }
                        if(shortening.contentEquals("1"))
                        {
                            String check1="\"sto\":\"SHORT_URL_PICKER_INPUT_QUEUE\"";
                            String check2="CommonUtility::sendToShortUrlRepository::appId -> "+APPID;
                            if(responseString.contains(check1)&&responseString.contains(check2))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", "<b> For the request shortening flag was 1 and request successfully sent to SHORT URL component of RCS and it has been verified in log   both strings are found in log</b>" +"First string "+ check1 +"Second string "+ check2);

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {
                    if(MISDATA.get("templateid").isEmpty())
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", "Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());
                        Assert.assertTrue(false,"Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());

                    }else {

                        if(shortening.contentEquals("1")) {
                            String originalmessage = MISDATA.get("originalmessage");
                            String messagetext = MISDATA.get("messagetext");
                            Map shorturlresult = UrlShortenerValidator.RETURNSHORTRESULT(originalmessage, messagetext);
                            boolean shortresult=false;
                             shortresult=(boolean)shorturlresult.get("isShorteningpass");


                            ExtentBASETEST.extentReportsDemo("INFO", " <b> The shorten urls from message text are </b> -->" + shorturlresult.get("shortresult"));
                            if(shortresult) {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTED ? </b> -->" + shorturlresult.get("isShorteningpass"));
                            }
                            else
                            {
                                ExtentBASETEST.extentReportsDemo("FAIL", " <b> ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTED ? </b> -->" + shorturlresult.get("isShorteningpass"));

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", " <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());
                    }


                    String submitstatus=MISDATA.get("statusdesc");
                    if(submitstatus.contentEquals("submitted"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        DLRCHECK = true;
                        joinid=MISDATA.get("joinid");
                    }
                    else {
                        ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                        Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }
    @DataProvider
    public Object[][] getRCSTESTDATAFORTTL() {

        Object data[][] = ExcelUtils.getTestData("RCS_DATA_TTL", 4, "TestData_TEXT.xlsx");

        return data;
    }


    @DataProvider
    public Object[][] get_JUM_13862_ORCHESTRATOR() {
        Object data[][] = ExcelUtils.getTestData("QUICKFALLBACK_ORCHESTRATOR", 0, "TestData_TEXT.xlsx");
        return data;
    }

    @Test(dataProvider = "get_JUM_13862_ORCHESTRATOR", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_JUM_13862_IMEDIATEFALLBACK_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String PARELLER, String SMS,String WA, String RCS,String P1,String P2, String P3) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>IMEDIATEFALLBACK case--> " + FunctionName + "</b>");
        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check fallback RCS case  </b>");
            Response response = request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                System.out.println("Response Object  " + responseid);
                if(responseid.startsWith("-"))
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " response is  "+responseid);
                    Assert.assertTrue(false," response is  "+responseid);

                }

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                if(PARELLER.contentEquals("YES")) {

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>THIS IS PARELLEL CASE </b>");

                    if(SMS.contentEquals("SMS"))
                    {

                        ob.handleMessageType1(SMS, responseid);
                    }

                    if(RCS.contentEquals("RCS"))
                    {
                        ob.handleMessageType1(RCS, responseid);
                    }

                    if(WA.contentEquals("WA"))
                    {
                        ob.handleMessageType1(WA, responseid);
                    }
                }

                if(PARELLER.contentEquals("NO")) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>THIS IS PRIORITY CASE </b>");
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check first priority --> </b>"+P1);
                    ob.handleMessageType1(P1, responseid);

                   // Thread.sleep(30000);
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check second priority Immediately --> </b>"+P2);
                    ob.handleMessageType1(P2, responseid);
                    Thread.sleep(30000);
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check third priority --> </b>"+P3);
                    ob.handleMessageType1(P3, responseid);
                }



            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @Test(dataProvider = "getwatddata",
            priority = 1,
            enabled = false,
            invocationCount = SetandGetGlobalVariable.count)

    public void watddata_TEXTLISTNER_JUM_13863_2026(String FunctionName, String UserID, String Passd,
                                              String APPID, String FROM, String TO, String MSG,
                                              String ALERT, String SELFID, String INTFLAG,
                                              String Contenttype, String Language,String watemplateid, String shorten) {
        try {
            Thread.sleep(10000);
            String ph[] = TO.split("X");
            ExtentBASETEST.STARTTEST("Request URL--> " +
                    ob.GetProperty("QA_AWS_NTEXT_BASE_URI") +
                    " <b>TEXTLISTNER request submitted--> "
                    + FunctionName + "</b>");
            // Content Type Conversion
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) Math.round(ctype);
            String SCTYPE = String.valueOf(ictype);

            // Alert Conversion
            double alertType = Double.parseDouble(ALERT);
            int iAlertType = (int) Math.round(alertType);
            String AALERT = String.valueOf(iAlertType);



            // Language BLK Handling
            if (Language.contentEquals("BLK")) {
                Language = "";
            }

            // API Request
            RequestSpecification request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", TO)
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);

            if (shorten != null && !shorten.trim().isEmpty()) {
                try {
                    int shortenValue = (int) Math.round(Double.parseDouble(shorten));

                    if (shortenValue == 0 || shortenValue == 1) {
                        request.param("s", String.valueOf(shortenValue));
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid shorten value: " + shorten);
                }
            }
            request.log().all();
            ExtentBASETEST.extentReportsDemo("INFO",
                    "<b>Going to hit the whats app API for text Listener</b>");
            //request.log().uri();
            //request.log().headers();
            //request.log().params();

            System.out.println("Whats app API REQUEST SUBMITTED-->"   + RestAssured.baseURI);
            Thread.sleep(2000);
            Response response = request.post();

            System.out.println("Response Body : " + response.getBody().asString());
            Thread.sleep(2000);
            int statusCode = response.getStatusCode();
            System.out.println("Status code: " + statusCode);

            // Status Code Validation
            if (statusCode == 200) {

                ExtentBASETEST.extentReportsDemo("INFO", "200 Response received");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                System.out.println("Response received 200 and RESPONSE ID:--> " + responseid);
                // ==========================
                // LISTENER LOG CHECK
                // ==========================
                if (ob.GetProperty("Check98log").contentEquals("true")) {
                    Thread.sleep(2000);
                    //dlthashid verification
                    boolean result1=
                            LinuxLogReader.checkComponentLog(
                                    responseid,
                                    ob.GetProperty("Username187"),
                                    ob.GetProperty("Password187"),
                                    ob.GetProperty("hostname187"),
                                    true,
                                    MSG,
                                    ob.GetProperty("commonloglocation187"),
                                    ob.GetProperty("rcvrlogfileName"));
                    String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGSUDO(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));


                    if (result1) {
                        ExtentBASETEST.extentReportsDemo(
                                "INFO",
                                "<b>REQUEST RECEIVED ON 187 Listener SERVER</b><br>" + responseString
                        );
                    } else {
                        ExtentBASETEST.extentReportsDemo(
                                "INFO",
                                "<b>REQUEST not RECEIVED ON 187 Listener SERVER</b><br>" + responseString
                        );
                    }

                }


                // ==========================
                // PROCESSOR LOG CHECK
                // ==========================
                if (ob.GetProperty("Checkprocessorlog")
                        .contentEquals("true")) {

                    Thread.sleep(5000);
                    //dlthashid verification
                    boolean result1 =
                            LinuxLogReader.checkComponentLog(
                                    responseid,
                                    ob.GetProperty("Username205"),
                                    ob.GetProperty("Password205"),
                                    ob.GetProperty("hostname205"),
                                    true,
                                    MSG,
                                    ob.GetProperty("commonloglocation205"),
                                    ob.GetProperty("rcvrlogfileName"));

                    String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGSUDO(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("rcvrlogfileName"));


                    if (result1) {
                        ExtentBASETEST.extentReportsDemo(
                                "INFO",
                                "<b>REQUEST RECEIVED ON 208 processor SERVER</b><br>" + responseString
                        );
                    } else {
                        ExtentBASETEST.extentReportsDemo(
                                "INFO",
                                "<b>REQUEST not RECEIVED ON 208 processor SERVER</b><br>" + responseString
                        );
                    }

                }

                //Router  LOG CHECK
                if (ob.GetProperty("CheckRouterlog").contentEquals("true")) {
                    Thread.sleep(3000);
                    boolean ROUTERSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), true, MSG, ob.GetProperty("commonloglocation207WASUDO"), ob.GetProperty("rcvrlogfileName"));
                    String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGSUDO(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), ob.GetProperty("commonloglocation207WASUDO"), ob.GetProperty("rcvrlogfileName"));

                    if (ROUTERSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo(
                                "INFO",
                                "<b>REQUEST RECEIVED ON 207 whatsapp router SERVER</b><br>" + responseString
                        );
                    } else {
                        ExtentBASETEST.extentReportsDemo(
                                "INFO",
                                "<b>REQUEST not RECEIVED ON 207 whatsapp router SERVER</b><br>" + responseString
                        );
                    }
                }

                try {
//DLR check in MIS TABLE
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                boolean DLRCHECK1 = false;
                String DLRLivetablename = "";
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), true, MSG, ob.GetProperty("commonloglocation207WASUDO"), ob.GetProperty("rcvrlogfileName"));

                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), false, "MSG", ob.GetProperty("commonloglocation207WASUDO"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + responseid + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("WARECIEVERTABLENAME");
                    System.out.println("WARECIEVERTABLENAME"+PushRecieverLivetablename);
                    DLRLivetablename = Livetablename.get("WADLRTABLENAME");
                    System.out.println("WADLRTABLENAME"+DLRLivetablename);
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROM_WA_RECIEVERTABLE(5000, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        DLRCHECK1 = true;

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    }
                    System.out.println(MISDATA);
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Going to check in DB");
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("WARECIEVERTABLENAME");
                    System.out.println("WARECIEVERTABLENAME"+PushRecieverLivetablename);
                    DLRLivetablename = Livetablename.get("WADLRTABLENAME");
                    System.out.println("DLRLivetablename2"+DLRLivetablename);
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROM_WA_RECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                    System.out.println("MISDATA content: " + MISDATA);

                    if (!MISDATA.isEmpty() && (MISDATA.get("templateid").contentEquals(watemplateid))) {
                        String misTemplateId = MISDATA.get("templateid");
                        // Console logs
                        System.out.println("MIS Template ID : " + misTemplateId);
                        System.out.println("WA Template ID  : " + watemplateid);
                        System.out.println("omx  : " + MISDATA.get("originalmessage"));
                        System.out.println("mx  : " + MISDATA.get("messagetext") );

                        System.out.println("Loop content:");

                        // Extent Report Logs
                        ExtentBASETEST.extentReportsDemo("INFO", "Log check passed, template matched");
                        ExtentBASETEST.extentReportsDemo(
                                "PASS",
                                "Template Matched Successfully<br>" +
                                        "<b>MIS Template ID :</b> " + misTemplateId + "<br>" +
                                        "<b>WA Template ID  :</b> " + watemplateid + "<br>" +
                                        "<b>origional message (omx) :</b> " +  MISDATA.get("originalmessage") + "<br>" +
                                        "<b>message text (mx)  :</b> " + MISDATA.get("messagetext") + "<br>" +
                                        "MISTABLEDATA --> " + MISDATA.toString()
                        );
                        DLRCHECK1 = true;
                    }
                    else {
                        // Optional: failure case bhi add kar lo (good practice ✅)
                        ExtentBASETEST.extentReportsDemo(
                                "FAIL",
                                "Template mismatch\nMIS Template : " + MISDATA.get("templateid") +
                                        "\nWA Template : " + watemplateid
                        );
                    }
                    System.out.println("ResponseID: '" + responseid + "'");
                }

            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }
    @DataProvider
    public Object[][] getwatddata() {

        Object data[][] =
                ExcelUtils.getTestData(
                        "JUM-11394_WATemplateid",
                        0,
                        "TestData_TEXT.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getTEXTSHORTforWA_JUM_13868() {

        Object data[][] = ExcelUtils.getTestData("WA_JUM-13868", 0, "TestData_TEXT.xlsx");

        return data;
    }
    @Test(dataProvider = "getTEXTSHORTforWA_JUM_13868", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_WA_TEXTSHORTforWA_JUM_13868(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String s) throws Exception {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_WA_SHORTING CHECK--> " + FunctionName + "</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(Contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(ALERT);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);

        String Ss = "";
        try {
            double stype = Double.parseDouble(s);
            int istype = (int) (Math.round(stype * 100) / 100);
            Ss = String.valueOf(istype);
        } catch (NumberFormatException e) {
            Ss = "";
        }

        if (Language.contentEquals("BLK")) {
            Language = "";
        }

        RequestSpecification request;

        if (Ss.contentEquals("3")) {
            request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);
        } else {
            request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7838787657")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("s", Ss);
        }

        ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the WA SHORTING component</b>");

        Response response = request.post();

        Thread.sleep(2000);

        System.out.println("Request Object: " + request);
        int statusCode = response.getStatusCode();
        System.out.println("Status code: " + statusCode);

        boolean DLRCHECK = false;
        String WARECIEVRTABLENAME = "";

        if (statusCode == 200) {
            ExtentBASETEST.extentReportsDemo("INFO", "200 Response received");
            String responseid = response.asString().replaceAll("[\\n\\t ]", "");

            if (responseid.startsWith("-")) {
                ExtentBASETEST.extentReportsDemo("FAIL", " response is  " + responseid);
                Assert.assertTrue(false, " response is  " + responseid);
            }

            ExtentBASETEST.extentReportsDemo("INFO", "Now going to get the receiver data from MIS for response id " + responseid);
            System.out.println("Response Object: " + responseid);

            // WA COMPONENT LOG CHECK
            if (ob.GetProperty("checkWAlog").contentEquals("true")) {
                Thread.sleep(10000);
                boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), false, "dummy", ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));

                if (LISTNERPROCESSORSERVERRESULT) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 207 WA ROUTER</b>");

                    String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));

                    if (Ss.contentEquals("1")) {
                        String check1 = "\"sto\":\"SHORT_URL_WA_PICKER_INPUT_QUEUE\"";
                        String check2 = "CommonUtility::sendToShortUrlRepository::appId -> " + APPID;

                        if (responseString.contains(check1) && responseString.contains(check2)) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>For the request shortening flag was 1 and request successfully sent to SHORT URL component of WA and it has been verified in log. Both strings are found in log</b>"
                                    + " First string: " + check1
                                    + " Second string: " + check2);
                        }
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Below is the 207 WA COMPONENT log info --></b>" + responseString);

                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 207 WA SERVER</b>");
                }
            }

            TestBase.setcurrenttime();
            Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
            String WADLRTABLENAME = Livetablename.get("WADLRTABLENAME");
            WARECIEVRTABLENAME = Livetablename.get("WARECIEVERTABLENAME");

            Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROM_WA_RECIEVERTABLE(500, responseid, WARECIEVRTABLENAME);
            String joinid = "";

            if (MISDATA.isEmpty()) {
                ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
            } else {

                if (Ss.contentEquals("1")) {
                    String originalmessage = MISDATA.get("originalmessage");
                    String messagetext = MISDATA.get("messagetext");
                    Map shorturlresult = UrlShortenerValidator.RETURNSHORTRESULT(originalmessage, messagetext);
                    boolean shortresult = (boolean) shorturlresult.get("isShorteningpass");

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>The shorten URLs from message text are</b> --> " + shorturlresult.get("shortresult"));

                    if (shortresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTENED?</b> --> " + shorturlresult.get("isShorteningpass"));
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTENED?</b> --> " + shorturlresult.get("isShorteningpass"));
                    }
                }

                ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA --> " + MISDATA.toString());

                String submitstatus = MISDATA.get("statusdesc");
                if (submitstatus.contentEquals("submitted")) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>THE WA REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO WA</b>");
                    DLRCHECK = true;
                    joinid = MISDATA.get("joinid");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", " THE WA REQUEST HAS NOT BEEN SUCCESSFULLY SUBMITTED TO WA and actual status is " + submitstatus);
                    Assert.fail("THE WA REQUEST HAS NOT BEEN SUCCESSFULLY SUBMITTED TO WA and actual status is " + submitstatus);
                }
            }

            Thread.sleep(10000);

            if (DLRCHECK) {
                Map<String, String> DLRDATA = SQLPOOL.GETWADATAFROMDLRLIVETABLE(500, joinid, WADLRTABLENAME);

                if (DLRDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("INFO", " The WA DLRDATA could not be pulled from DB ");
                } else {
                    if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read")) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully received and the current status of WA message is <b>SENT, DELIVERED, READ</b>");
                    } else if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully received and the current status of WA message is <b>SENT, DELIVERED</b>");
                    } else if (DLRDATA.containsValue("sent") && !DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully received and the current status of WA message is <b>SENT</b>");
                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "WA_DLRDATA --> " + DLRDATA.toString());
                }
            }

        } else {
            ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
            Assert.fail("Status code is not success");
        }
    }



    @DataProvider
    public Object[][] get_SENDER_JUM_13866() {

        Object data[][] = ExcelUtils.getTestData("SENDER_JUM_13866", 0, "TestData_TEXT.xlsx");

        return data;
    }

    @Test(dataProvider = "get_SENDER_JUM_13866", priority = 2, enabled = false, invocationCount = 1)
    public void Check_JUM_13866_TEXTLISTENER(String FunctionName, String UserID, String Passd, String APPID,
                                             String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG,
                                             String Contenttype) throws Exception {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " "
                + "<b>TEXTLISTNER_SENDER_CHECK--> " + FunctionName + "</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(Contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(ALERT);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);

        RequestSpecification request = RestAssured.given()
                .param("appid", APPID)
                .param("userId", UserID)
                .param("pass", Passd)
                .param("from", FROM)
                .param("to", "918527607709")
                .param("text", MSG)
                .param("alert", AALERT)
                .param("selfid", SELFID)
                .param("intflag", INTFLAG)
                .param("contenttype", SCTYPE);

        ExtentBASETEST.extentReportsDemo("INFO",
                "<b>Going to hit the API to check MSG conversion for TEXT</b>");

        Response response = request.post();

        Thread.sleep(2000);

        System.out.println("Request Object: " + request);
        int statusCode = response.getStatusCode();
        System.out.println("Status code: " + statusCode);

        // ===== Status 200 Block =====
        if (statusCode == 200) {

            String responseid = response.asString().replaceAll("[\\n\\t ]", "");
            System.out.println("Response ID: " + responseid);
            ExtentBASETEST.extentReportsDemo("INFO",
                    "<b>API Response Received | Status Code: 200 | Response ID: " + responseid + "</b>");

            // ===== Processor (205) Log Check =====
            if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                Thread.sleep(2000);
                boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(
                        responseid,
                        ob.GetProperty("Username205"),
                        ob.GetProperty("Password205"),
                        ob.GetProperty("hostname205"),
                        true,
                        MSG,
                        ob.GetProperty("commonloglocation205"),
                        ob.GetProperty("PROCESSORLOGFILENAME")
                );

                if (LISTNERPROCESSORSERVERRESULT) {
                    ExtentBASETEST.extentReportsDemo("INFO",
                            "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                    String processorLogString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(
                            responseid,
                            ob.GetProperty("Username205"),
                            ob.GetProperty("Password205"),
                            ob.GetProperty("hostname205"),
                            ob.GetProperty("commonloglocation205"),
                            ob.GetProperty("PROCESSORLOGFILENAME")
                    );

                    ExtentBASETEST.extentReportsDemo("INFO",
                            "<b>Below is the 205 processor server log info --> </b>" + processorLogString);

                    // ===== Sender Validation in Processor Log =====
                    String Expectedsender = "\"misdisplaySender\":\"" + FROM + "\"";
                    System.out.println("Expected Sender String to validate: " + Expectedsender);

                    if (processorLogString.contains(Expectedsender)) {

                        ExtentBASETEST.extentReportsDemo("PASS",
                                "<b>Sender validation PASSED </b> " + " Expected: " + Expectedsender + " Status   : Found in processor log");

                        Assert.assertTrue(
                                processorLogString.contains(Expectedsender),
                                "FROM value validation failed. Expected in log: " + Expectedsender
                        );

                    } else {

                        ExtentBASETEST.extentReportsDemo("FAIL",
                                "<b>Sender validation FAILED </b>"
                                        + " Expected : " + Expectedsender + " Status   : NOT found in processor log"
                                + " Actual Log : " + processorLogString);

                        Assert.fail("Sender validation failed. "
                                + "Expected \"misdisplaySender\":\"" + FROM + "\" not found in processor log.");
                    }

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL",
                            "<b>REQUEST NOT RECEIVED ON 205 processor SERVER</b>");
                    Assert.fail("Processor log check failed — request not found on 205 server.");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("INFO",
                        "<b>Component log check is disabled (checkComponentLog = false)</b>");
            }


            TestBase.setcurrenttime();
            Thread.sleep(6000);
            Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
            String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

            Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
            System.out.println(MISDATA);

            String receivedsender = MISDATA.get("receivedsender");
            String actualsender = MISDATA.get("actualsender");

            System.out.println("Received Sender from MIS  " + receivedsender);
            System.out.println("Actual Sender from MIS  " + actualsender);
            ExtentBASETEST.extentReportsDemo("INFO", "For request " + responseid + " <b>Received Sender from MIS--></b> " + receivedsender + " | <b>Actual Sender from MIS--></b> " + actualsender);


            try {
                if (FROM.equalsIgnoreCase(actualsender) && FROM.equalsIgnoreCase(receivedsender)) {
                    ExtentBASETEST.extentReportsDemo("PASS", "For request " + responseid + " Sender values <b>receivedsender--></b>" + receivedsender + " and <b>actualsender--></b>" + actualsender + " both match with Expected FROM-->" + FROM);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "For request " + responseid + " Sender values <b>receivedsender--></b>" + receivedsender + " and <b>actualsender--></b>" + actualsender + " DO NOT match with Expected FROM-->" + FROM);
                }
            } catch (NullPointerException e) {
                ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table, sender values are null...</b>");
            }

        } else {
            ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
            Assert.fail("Status code is not success");
        }
    }
    @Test(dataProvider = "getRCSTESTDATAFORBRDNAME", priority = 1,  enabled = true, invocationCount = 2)
    public void CHECK_RCS_TEXTLISTNER_JUM_13852_BRD_JUM_13869_2026(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language ,String SHORT,String BRD) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK FOR BRDNAME--> " + FunctionName + "</b>");
        // Reporter.log("Request URL-->"+ob.GetProperty("QA_AWS_TEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
        try {
            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double stype = Double.parseDouble(SHORT);
            int istype = (int) (Math.round(stype * 100) / 100);
            String shortening = String.valueOf(istype);
            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470
            Response response= null;

            RequestSpecification request;

            if(shortening.contentEquals("3"))
            {
                request  = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7838787657")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .param("brd",BRD);
            } else{

                request   = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7838787657")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .param("s",shortening)
                        .param("brd",BRD);

            }


            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the RCS component </b>");
            if(FunctionName.contains("UNICODE"))
            {
                response = request.get();
            }else {
                response = request.post();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String RCSRECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");

                if(responseid.startsWith("-"))
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " response is  "+responseid);
                    Assert.assertTrue(false," response is  "+responseid);

                }
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                        String BRDNAME="POST body -> {\"metadata\":{\"brd\":\""+BRD+"\"";
                        if(responseString.contains(BRDNAME))
                        {
                            ExtentBASETEST.extentReportsDemo("PASS", "<b> For the request BRD information is present in log</b>" +" --> "+ BRD );

                        }
                        else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "<b> For the request BRD information is not present in log</b>" +" --> "+ BRD );

                        }

                        if(shortening.contentEquals("1"))
                        {
                            String check1="\"sto\":\"SHORT_URL_PICKER_INPUT_QUEUE\"";
                            String check2="CommonUtility::sendToShortUrlRepository::appId -> "+APPID;
                            if(responseString.contains(check1)&&responseString.contains(check2))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", "<b> For the request shortening flag was 1 and request successfully sent to SHORT URL component of RCS and it has been verified in log   both strings are found in log</b>" +"First string "+ check1 +"Second string "+ check2);

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString );
                        responseString=null;
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }

                }

                //

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {
                    if(MISDATA.get("templateid").isEmpty())
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", "Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());
                        Assert.assertTrue(false,"Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());

                    }else {

                        if(shortening.contentEquals("1")) {
                            String originalmessage = MISDATA.get("originalmessage");
                            String messagetext = MISDATA.get("messagetext");
                            Map shorturlresult = UrlShortenerValidator.RETURNSHORTRESULT(originalmessage, messagetext);
                            boolean shortresult=false;
                            shortresult=(boolean)shorturlresult.get("isShorteningpass");


                            ExtentBASETEST.extentReportsDemo("INFO", " <b> The shorten urls from message text are </b> -->" + shorturlresult.get("shortresult"));
                            if(shortresult) {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTED ? </b> -->" + shorturlresult.get("isShorteningpass"));
                            }
                            else
                            {
                                ExtentBASETEST.extentReportsDemo("FAIL", " <b> ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTED ? </b> -->" + shorturlresult.get("isShorteningpass"));

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", " <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());
                    }


                    String submitstatus=MISDATA.get("statusdesc");
                    if(submitstatus.contentEquals("submitted"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        DLRCHECK = true;
                        joinid=MISDATA.get("joinid");
                    }
                    else {
                        ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                        Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }

responseid=null;
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }
    @DataProvider
    public Object[][] getRCSTESTDATAFORBRDNAME() {

        Object data[][] = ExcelUtils.getTestData("RCS_BRDNAME", 0, "TestData_TEXT.xlsx");

        return data;
    }



    @Test(dataProvider = "getTEXTSHORTforWA_JUM_13861", priority = 1, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_WA_TEXTSHORTforWANEW2_JUM_13861(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String s) throws Exception {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_TEXT_BASE_URI") + " " + "<b>TEXTLISTNER_WA_SHORTING CHECK--> " + FunctionName + "</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(Contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(ALERT);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);

        String Ss = "";
        try {
            double stype = Double.parseDouble(s);
            int istype = (int) (Math.round(stype * 100) / 100);
            Ss = String.valueOf(istype);
        } catch (NumberFormatException e) {
            Ss = "";
        }

        if (Language.contentEquals("BLK")) {
            Language = "";
        }

        RequestSpecification request;

        if (Ss.contentEquals("3")) {
            request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "9873194089")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);
        } else {
            request = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "9873194089")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language)
                    .param("s", Ss);
        }

        ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the WA SHORTING component</b>");

        Response response = request.post();

        Thread.sleep(2000);

        System.out.println("Request Object: " + request);
        int statusCode = response.getStatusCode();
        System.out.println("Status code: " + statusCode);

        boolean DLRCHECK = false;
        String WARECIEVRTABLENAME = "";
        String wadrtEquivalent = "";      // wadrt (verified) OR owadrt (orphan) value, extracted from full log line
        String wadrtFullLogLine = "";     // full matching log line, extracted from WA component log

        if (statusCode == 200) {
            ExtentBASETEST.extentReportsDemo("INFO", "200 Response received");
            String responseid = response.asString().replaceAll("[\\n\\t ]", "");

            if (responseid.startsWith("-")) {
                ExtentBASETEST.extentReportsDemo("FAIL", " response is  " + responseid);
                Assert.assertTrue(false, " response is  " + responseid);
            }

            ExtentBASETEST.extentReportsDemo("INFO", "Now going to get the receiver data from MIS for response id " + responseid);
            System.out.println("Response Object: " + responseid);

            // WA COMPONENT LOG CHECK
            if (ob.GetProperty("checkWAlog").contentEquals("true")) {
                Thread.sleep(10000);
                boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), false, "dummy", ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));

                if (LISTNERPROCESSORSERVERRESULT) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 207 WA ROUTER</b>");

                    String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));

                    if (Ss.contentEquals("1")) {
                        String check1 = "\"sto\":\"SHORT_URL_WA_PICKER_INPUT_QUEUE\"";
                        String check2 = "CommonUtility::sendToShortUrlRepository::appId -> " + APPID;

                        if (responseString.contains(check1) && responseString.contains(check2)) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>For the request shortening flag was 1 and request successfully sent to SHORT URL component of WA and it has been verified in log. Both strings are found in log</b>"
                                    + " First string: " + check1
                                    + " Second string: " + check2);
                        }
                    }

                    String verifiedCheck = "WAVerifiedReceiptRedisClient::pushToWAVerifiedReceiptOutputQueue::Verified Receipt ->";
                    String orphanCheck = "WAOrphanRedisClient::pushToWAOrphanOutputQueue:";

                    String[] lines = responseString.split("\\r?\\n");

                    if (responseString.contains(verifiedCheck)) {


                        for (String line : lines) {
                            if (line.contains(verifiedCheck)) {
                                wadrtFullLogLine = line;
                            }
                        }

                        System.out.println("Full VerifiedReceipt log line --> " + wadrtFullLogLine);
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>WAVerifiedReceiptRedisClient::pushToWAVerifiedReceiptOutputQueue log line --></b> " + wadrtFullLogLine);

                        if (wadrtFullLogLine.contains("\"wadrt\"")) {
                            String wadrtTag = "\"wadrt\":\"";
                            int startIndex = wadrtFullLogLine.indexOf(wadrtTag) + wadrtTag.length();
                            int endIndex = wadrtFullLogLine.indexOf("\"", startIndex);
                            wadrtEquivalent = wadrtFullLogLine.substring(startIndex, endIndex);
                        }

                    } else if (responseString.contains(orphanCheck)) {

                        for (String line : lines) {
                            if (line.contains(orphanCheck)) {
                                wadrtFullLogLine = line;
                            }
                        }

                        System.out.println("Full Orphan log line --> " + wadrtFullLogLine);
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>WAOrphanRedisClient::pushToWAOrphanOutputQueue log line (Orphan case) --></b> " + wadrtFullLogLine);

                        if (wadrtFullLogLine.contains("\"owadrt\"")) {
                            String owadrtTag = "\"owadrt\":\"";
                            int startIndex = wadrtFullLogLine.indexOf(owadrtTag) + owadrtTag.length();
                            int endIndex = wadrtFullLogLine.indexOf("\"", startIndex);
                            wadrtEquivalent = wadrtFullLogLine.substring(startIndex, endIndex);
                        }

                    } else {
                        System.out.println("Neither VerifiedReceipt nor Orphan log line found for responseid --> " + responseid);
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>Neither WAVerifiedReceiptRedisClient::pushToWAVerifiedReceiptOutputQueue nor WAOrphanRedisClient::pushToWAOrphanOutputQueue log line found for responseid --></b> " + responseid);
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Below is the 207 WA COMPONENT log info --></b>" + responseString);

                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 207 WA SERVER</b>");
                }
            }

            TestBase.setcurrenttime();
            Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
            String WADLRTABLENAME = Livetablename.get("WADLRTABLENAME");
            WARECIEVRTABLENAME = Livetablename.get("WARECIEVERTABLENAME");

            Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROM_WA_RECIEVERTABLE(500, responseid, WARECIEVRTABLENAME);
            String joinid = "";

            if (MISDATA.isEmpty()) {
                ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
            } else {

                if (Ss.contentEquals("1")) {
                    String originalmessage = MISDATA.get("originalmessage");
                    String messagetext = MISDATA.get("messagetext");
                    Map shorturlresult = UrlShortenerValidator.RETURNSHORTRESULT(originalmessage, messagetext);
                    boolean shortresult = (boolean) shorturlresult.get("isShorteningpass");

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>The shorten URLs from message text are</b> --> " + shorturlresult.get("shortresult"));

                    if (shortresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTENED?</b> --> " + shorturlresult.get("isShorteningpass"));
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>ALL THE LONG URLS IN MESSAGE TEXT ARE SHORTENED?</b> --> " + shorturlresult.get("isShorteningpass"));
                    }
                }

                ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA --> " + MISDATA.toString());

                String submitstatus = MISDATA.get("statusdesc");
                if (submitstatus.contentEquals("submitted")) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>THE WA REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO WA</b>");
                    DLRCHECK = true;
                    joinid = MISDATA.get("joinid");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", " THE WA REQUEST HAS NOT BEEN SUCCESSFULLY SUBMITTED TO WA and actual status is " + submitstatus);
                    Assert.fail("THE WA REQUEST HAS NOT BEEN SUCCESSFULLY SUBMITTED TO WA and actual status is " + submitstatus);
                }
            }

            Thread.sleep(15000);

            if (DLRCHECK) {
                Map<String, String> DLRDATA = SQLPOOL.GETWADATAFROMDLRLIVETABLE(500, joinid, WADLRTABLENAME);

                if (DLRDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("INFO", " The WA DLRDATA could not be pulled from DB ");
                } else {
                    if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read")) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully received and the current status of WA message is <b>SENT, DELIVERED, READ</b>");
                    } else if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully received and the current status of WA message is <b>SENT, DELIVERED</b>");
                    } else if (DLRDATA.containsValue("sent") && !DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully received and the current status of WA message is <b>SENT</b>");
                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "WA_DLRDATA --> " + DLRDATA.toString());
                }
            }


            if (!wadrtEquivalent.isEmpty()) {
                ExtentBASETEST.extentReportsDemo("PASS", "<b>Final wadrt/owadrt value (from log) --></b> " + wadrtEquivalent);
                System.out.println("Final wadrt/owadrt value (from log) --> " + wadrtEquivalent);
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "<b>wadrt/owadrt value could not be extracted from log for responseid --></b> " + responseid);
                System.out.println("wadrt/owadrt not found in log for responseid --> " + responseid);
            }

        } else {
            ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
            Assert.fail("Status code is not success");
        }
    }

    @Test(
            dataProvider = "getMSISDN_DLR_FETCH_DATA",
            priority = 1,
            enabled = true
    )
    public void JUM_13887_MSISDNDLRFETCH(
            String FunctionName,
            String UserID1,
            String Pass1,
            String MSISDN1,
            String channel1,
            String FromDate1,
            String ToDate1,
            String expectedStatus) {

        String responseBody = "";
        int statusCode = 0;
        int expectedStatusCode = 200;

        try {
            ExtentBASETEST.STARTTEST(
                    "MSISDN DLR FETCH API : " + FunctionName);
            System.out.println("Test Case       : " + FunctionName);
            System.out.println("Username        : " + UserID1);
            System.out.println("Password        : " + Pass1);
            System.out.println("MSISDN          : " + MSISDN1);
            System.out.println("Channel         : " + channel1);
            System.out.println("FromDate        : " + FromDate1);
            System.out.println("ToDate          : " + ToDate1);
            System.out.println("Expected Result : " + expectedStatus);
            UserID1 = convertBLKToBlank(UserID1);
            Pass1 = convertBLKToBlank(Pass1);
            MSISDN1 = convertBLKToBlank(MSISDN1);
            channel1 = convertBLKToBlank(channel1);
            FromDate1 = convertBLKToBlank(FromDate1);
            ToDate1 = convertBLKToBlank(ToDate1);
            if (MSISDN1 != null
                    && !MSISDN1.isEmpty()
                    && MSISDN1.matches("\\d+(\\.\\d+)?([Ee][+-]?\\d+)?")) {

                MSISDN1 = String.valueOf(
                        (long) Double.parseDouble(MSISDN1));
            }
            JSONObject requestBody = new JSONObject();
            requestBody.put("username", UserID1);
            requestBody.put("password", Pass1);
            requestBody.put("msisdn", MSISDN1);
            requestBody.put("channel", channel1);
            requestBody.put("FromDate", FromDate1);
            requestBody.put("ToDate", ToDate1);

            System.out.println("Request Body : "
                    + requestBody.toJSONString());
            String apiUrl = ob.GetProperty(
                    "QA_AWS_MSISDNDLRFETCH_URI");
            System.out.println("Request URL : " + apiUrl);
            RequestSpecification request = RestAssured
                    .given()
                    .header(
                            "Content-Type",
                            "application/json"
                    )
                    .body(requestBody.toJSONString());
            ExtentBASETEST.extentReportsDemo(
                    "INFO",
                    "Request URL : " + apiUrl);

            ExtentBASETEST.extentReportsDemo(
                    "INFO",
                    "Request Body : <pre>"
                            + requestBody.toJSONString()
                            + "</pre>");

            Response response = request.post(apiUrl);
            statusCode = response.getStatusCode();
            responseBody = response
                    .getBody()
                    .asString();
            System.out.println("Status Code : " + statusCode);
            System.out.println("Response    : " + responseBody);
            ExtentBASETEST.extentReportsDemo(
                    "INFO",
                    "Response Body : <pre>"
                            + responseBody
                            + "</pre>");
            ExtentBASETEST.extentReportsDemo(
                    "INFO",
                    "<b>Expected Status Code :</b> "
                            + expectedStatusCode);
            ExtentBASETEST.extentReportsDemo(
                    "INFO",
                    "<b>Actual Status Code :</b> "
                            + statusCode);
            Assert.assertEquals(
                    statusCode,
                    expectedStatusCode,
                    "Status Code Validation Failed"
            );
            ExtentBASETEST.extentReportsDemo(
                    "PASS",
                    "Status Code Validation Passed");
            ExtentBASETEST.extentReportsDemo(
                    "INFO",
                    "<b>Expected Response :</b> "
                            + expectedStatus);

            ExtentBASETEST.extentReportsDemo(
                    "INFO",
                    "<b>Actual Response :</b><br><pre>"
                            + responseBody
                            + "</pre>");




            Assert.assertTrue(
                    responseBody.contains(expectedStatus),
                    "Expected value not found in response."
                            + "\nExpected : " + expectedStatus
                            + "\nActual   : " + responseBody
            );


            ExtentBASETEST.extentReportsDemo(
                    "PASS",
                    "Response Validation Passed");


            //========================================================
            // Test Passed
            //========================================================

            ExtentBASETEST.extentReportsDemo(
                    "PASS",
                    "Test Case Passed Successfully");

            System.out.println(
                    "TEST METHOD COMPLETED SUCCESSFULLY");

        }


        //============================================================
        // Assertion Failure
        //============================================================

        catch (AssertionError ae) {

            ExtentBASETEST.extentReportsDemo(
                    "FAIL",
                    "<b>Expected Status Code :</b> "
                            + expectedStatusCode);

            ExtentBASETEST.extentReportsDemo(
                    "FAIL",
                    "<b>Actual Status Code :</b> "
                            + statusCode);

            ExtentBASETEST.extentReportsDemo(
                    "FAIL",
                    "<b>Expected Response :</b> "
                            + expectedStatus);

            ExtentBASETEST.extentReportsDemo(
                    "FAIL",
                    "<b>Actual Response :</b><br><pre>"
                            + responseBody
                            + "</pre>");

            ExtentBASETEST.extentReportsDemo(
                    "FAIL",
                    ae.getMessage());

            throw ae;
        }


        //============================================================
        // Other Exception
        //============================================================

        catch (Exception e) {

            e.printStackTrace();

            ExtentBASETEST.extentReportsDemo(
                    "FAIL",
                    e.getMessage());

            throw new RuntimeException(e);
        }
    }

    @DataProvider(name = "getMSISDN_DLR_FETCH_DATA")
    public Object[][] getMSISDN_DLR_FETCH_DATA() {

        return ExcelUtils.getTestData(
                "DLR_FETCH_JUM-13057",
                0,
                "TestData_TEXT.xlsx"
        );
    }

    private String convertBLKToBlank(String value) {

        if (value == null) {
            return "";
        }

        if ("BLK".equalsIgnoreCase(value.trim())) {
            return "";
        }

        return value;
    }
}










