import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Map;
public class Bajaj_SFTP_TEST {
    TestBase ob;

    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
    }


    @Test(dataProvider = "getBajajdataNEW", priority = 1, enabled = true, invocationCount =2)
    public void Check_SFTP_BAJAJUNIFIED_JUM_13881_JUM_13855_2026(String FunctionName, String MessageID, String Data,String PARELLER, String SMS,String WA, String RCS,String P1,String P2, String P3) {
      ExtentBASETEST.STARTTEST("BAJAJSFTP RCS TEST-->" + FunctionName + "</b>");
        try {

            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to RPUSH this data in bajajunified Queue-->"+Data);


            String value="NODATA";
            Thread.sleep(1000);
            JedisQueueReader.LPUSH_bajajunified_redisdata(Data);
            Thread.sleep(5000);
           String value1 = LinuxLogReader.GET_RESPONSEID_FROM_PROCESSORLOG(MessageID, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"),  ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
           value= value1.replace("\"", "");
            ExtentBASETEST.extentReportsDemo("INFO", "<b>This is responseid fetched from processor --></b>"+value+ " for the MessageID "+MessageID);


            if (!value.contentEquals("NODATA")) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 208 processor SERVER</b>");
                           } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Log info could not be detected on  208 processor SERVER</b>");
                }

            if (!value.contentEquals("NODATA")) {

                if(PARELLER.contentEquals("YES")) {

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>THIS IS PARELLEL CASE </b>");

                    if(SMS.contentEquals("SMS"))
                    {

                        ob.handleMessageType1(SMS, value);
                    }

                    if(RCS.contentEquals("RCS"))
                    {
                        ob.handleMessageType1(RCS, value);
                    }

                    if(WA.contentEquals("WA"))
                    {
                        ob.handleMessageType1(WA, value);
                    }
                }

                if(PARELLER.contentEquals("NO")) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>THIS IS PRIORITY CASE </b>");
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check first priority --> </b>"+P1);
                    ob.handleMessageType1(P1, value);

                    Thread.sleep(30000);
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check second priority --> </b>"+P2);
                    ob.handleMessageType1(P2, value);
                    Thread.sleep(30000);
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check third priority --> </b>"+P3);
                    ob.handleMessageType1(P3, value);
                }


                //END


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }




    @DataProvider
    public Object[][] getBajajdataNEW() {
        Object data[][] = ExcelUtils.getTestData("bajajdata", 0, "Bajaj.xlsx");
        return data;
    }

}







