import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class TEST_CONSUMER_CSV extends JSONENCYPTER {

    Map<String, String> requestHeaders = new HashMap<>();
    String sheetName = "data";
    TestBase ob;

//test

    @BeforeTest
   public void setHeader() {
        requestHeaders.put("content-type", "application/Json");
    

                            }

    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
      //  ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST TO CHECK CONSUMER CSV FILE</b></h5>");
        String env = ob.GetProperty("EnvironmentV2");
        if (env.contentEquals("QA94")) {
            RestAssured.baseURI = ob.GetProperty("QA_V2_BASE_URI");

        }  else {
            throw new Exception("Envioenment name in Property is not valid");
        }

    }

    @Test(priority = 0, enabled = true,invocationCount =SetandGetGlobalVariable.count)
    public void Check_ConsumerCSV() {
        ExtentBASETEST.STARTTEST("<b>Check Consumer CSV </b>");
        try {
             Thread.sleep(5000);
               TestJSONENCRYPTION("CONSUMERCSV.json","V2","testdlt301291009","sbhdlt");
          
            File jsonDataInFile = new File(System.getProperty("user.dir")+"/src/main/resources/Util/JSON_REPOSITORY_V2/POST_ENCRYPTION/messages.json");
            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);
            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO","Going to Hit API");
            Response response = request.post();
            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO","200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();
                String responseid = jsonObject.get("respid").toString();
                if ("true".contentEquals(AcceptanceResult)) {
                    System.out.println("Request is accepted");
                   
                 boolean isCSVgenerated=LinuxLogReader.CHECKCONSUMERCSV();

                 if(isCSVgenerated)
                 {
                     ExtentBASETEST.extentReportsDemo("PASS","ResponseID "+responseid+" CSV file has been generated after API hit");
                 }
                 else
                 {
                     ExtentBASETEST.extentReportsDemo("FAIL","ResponseID "+responseid+" CSV file could't get generated...please check the consumer");
                 }
                 Assert.assertTrue(isCSVgenerated,"CSV file not generated");

                } else if ("false".contentEquals(AcceptanceResult)) {
                    ExtentBASETEST.extentReportsDemo("FAIL","Request is not accepted");
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL","Something is wrong");
                    Assert.fail("Something is wrong");

                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL","Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL",e.toString());
            Assert.fail(e.toString());

        }
    }

}