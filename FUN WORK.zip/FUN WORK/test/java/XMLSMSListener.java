import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class XMLSMSListener {
    Response response;
    Map<String, String> requestHeaders = new HashMap<>();

    Map<String, String> ErrorcodesMAP = new HashMap<>();
    String sheetName = "data";
    TestBase ob;


    @BeforeTest

    public void setHeader() {
        requestHeaders.put("content-type", "application/xml");


    }

    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
        // ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST FOR XMLLanguageAPI LISTNERS</b></h5>");
        String env = ob.GetProperty("Environment");

            RestAssured.baseURI = ob.GetProperty("BASEURI_XMLSMSListener");


    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLTemplatedata")
    public void Check_Templates_XMLSMSListener_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("<b>XMLSMSListener_Listener_TEMPLATEMATCHING--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_XMLSMSListener") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");
           /* if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }*/
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            Response response = request.post();

           /* if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }*/


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println("this is response "+response.body().asString());
                String temp = response.body().asString();

                String responseid = temp;
                System.out.println(responseid);
                boolean DLRCHECK = false;
                String DLRLivetablename = "";
                Thread.sleep(2000);

                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, "TestMSG", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + responseid + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(2000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);
                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        DLRCHECK = true;

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    }

                    System.out.println(MISDATA);
                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                        DLRLivetablename = Livetablename.get("DLRTABLENAME");
                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            DLRCHECK = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + responseid);

                    }

                }
//DLR
                if (DLRCHECK) {
                    boolean result = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                    System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + result);

                    if (result) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    } else {
                        System.out.println("DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }

                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }

                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }


                    }
                }
                ExtentBASETEST.extentReportsDemo("INFO", "DLR TEST EXECUTED");

                //END

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

   



    @DataProvider
    public Object[][] getXMLTemplatedata() {
        Object data[][] = ExcelUtils.getTestData("Templatecases", 0, "TestData_XMLSMSListener.xlsx");
        return data;
    }
    @Test(priority = 2, enabled = true, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSMSCOUNTdata")
    public void Check_SMSCOUNT_XMLSMSListener_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String smscount) {
        ExtentBASETEST.STARTTEST("<b>XMLSMSListener_Listener_SMSCOUNT MATCHING--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_XMLSMSListener") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the SMSCOUNT matching<b>");
            Response response = request.post();


            double b = Double.parseDouble(smscount);
            int SMSCOUNTroundOff = (int) (Math.round(b * 100) / 100);
            System.out.println("Expected sms count is " + SMSCOUNTroundOff);


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                String temp = response.body().asString();

                String responseid = temp;
                System.out.println(responseid);
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), false, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 207 router SERVER</b>");
                    ExtentBASETEST.extentReportsDemo("INFO", "<b> ROUTER COMPONENT COMPLETE REDIS JSON DETAILS--></b>" + jsonbody.toString());

                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }

                    System.out.println(MISDATA);
                    // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                    if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);

                        if (MISDATA.isEmpty()) {
                            ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                            Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                        }

                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                                ExtentBASETEST.extentReportsDemo("PASS", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                            } else {
                                ExtentBASETEST.extentReportsDemo("FAIL", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                            }
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");

                            Thread.sleep(Retry_Waiting_period);

                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + responseid);

                    }


                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSMSCOUNTdata() {
        Object data[][] = ExcelUtils.getTestData("SMSCOUNT", 0, "TestData_XMLSMSListener.xlsx");
        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforInternational")
    public void International_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the International Feature <b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;

                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");


                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                try {
                    if (jsonbody.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("ERROR ", "The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                } catch (Exception e) {

                    ExtentBASETEST.extentReportsDemo("ERROR ", e.toString());

                }

                String smsc = String.valueOf(jsonbody.get("sn"));
                if (smsc.contains("-inter")) {

                    ExtentBASETEST.extentReportsDemo("PASS", "Request " + response_id + " is successfully submitted to SMSC & smsc selected is " + smsc);


                } else if (smsc.contains("NOT SUBMITTED TO SMSC")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + response_id + " Request has not been submitted to SMSC");
                    Assert.assertTrue(false, "FOR Request " + response_id + " SMSC is not matched for international request---> " + smsc);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + response_id + " SMSC is not matched for international request---> " + smsc);
                    Assert.assertTrue(false, "FOR Request " + response_id + " SMSC is not matched for international request--->" + smsc);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforInternational() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 8, "TestData_XMLSMSListener.xlsx");

        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSecondaryAccount")
    public void Check_Secondary_Account_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XMLSMSLISTNER --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Secondary Account Feature<b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());

                String temp = response.body().asString();

                String response_id = temp;
                System.out.println(response_id);
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "Dummy", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "Dummy", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "Dummy", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "Dummy", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + response_id + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(5000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                    System.out.println(MISDATA);
                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getSecondaryAccount() {
        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 22, "TestData_XMLSMSListener.xlsx");
        return data;
    }




    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforDUPLICATEMSG")
    public void Check_Duplicate_Message_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XMLSMSListener_Check_Duplicate_Message--> " + FunctionName + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Duplicate Message Feature <b>");
            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                response = request.post();
                hitcount++;
            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {

                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);

                Response response = request.post();
                if (FunctionName.contains("blank_language")) {
                    XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
                }
                System.out.println("Request Object  " + request);
                System.out.println("Status code  " + statusCode);
                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    System.out.println(statusCode);
                    System.out.println(response.body().asString());
                    String temp = response.body().asString();

                    String response_id = temp;
                    System.out.println(response_id);

                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + response_id + "</b>");

                    TestBase.setcurrenttime();
                    Thread.sleep(3000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(6000, response_id, PushRecieverLivetablename);
                    if(MISDATA.isEmpty())
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                    }

                    String dbstatus = MISDATA.get("statusdesc");


                    try {
                        if (dbstatus.contentEquals("DUPLICATE MESSAGE FOUND")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");

                            //DLR
                            boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                            if (DLRresult) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                                JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                                ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                                boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                                if (dlrrecieved) {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                    Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                                    if (DLRDATA.isEmpty()) {
                                        ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                        Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                    }
                                    ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                    ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                                } else {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                                }

                            }

                            ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                            //DLREND

                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } catch (Exception e) {
                        System.out.println("Please check the live table...");
                        ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                    }


                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");

                }

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforDUPLICATEMSG() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 23, "TestData_XMLSMSListener.xlsx");
        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforALERTDND")
    public void ALERTDNDERROR_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "InvalidDND.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/InvalidDND.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the International Feature <b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());


                String Errorcode = response.body().asString();

                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");

                if (Errorcode.contentEquals("-73")) {
                    System.out.println(FunctionName + " Passed");
                    ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Errorcode + " matched with Expected Response " + "-73");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Errorcode + " did not match with Expected Response " + "-73");

                    Assert.assertEquals(Errorcode, "-73", "Response code not matched for " + FunctionName);

                    System.out.println("Actual response " + Errorcode + " matched with Expected Response " + "-73");


                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforALERTDND() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 24, "TestData_XMLSMSListener.xlsx");

        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforInvalidMSG")
    public void INVALIDMESSAGE_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the International Feature <b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;


                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());
                try {
                    if ("INVALID MESSAGE".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID msg check is successfull</b>");

                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID msg check NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforInvalidMSG() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 11, "TestData_XMLSMSListener.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXmlLangaugeAPIListenerforTilta")
    public void TILTAHANDLING_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the International Feature <b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;
                Thread.sleep(6000);
                TestBase.setcurrenttime();

                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);
                System.out.println(MISDATA);
                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());

                String actualmsg = ob.GetProperty("SPECIALCHAR_TILTA_TEXT");

                String newLineExpectedmsg = actualmsg.replace('~', '\n');

                String newLineActualmsg = MISDATA.get("messagetext");
                if (newLineExpectedmsg.contentEquals(newLineActualmsg)) {
                    String aar[] = newLineActualmsg.split("\n");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Replaced text with new line ---><b>" + Arrays.deepToString(aar) + "</b>");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Text with ~ char ---><b>" + actualmsg + "</b>");
                    ExtentBASETEST.extentReportsDemo("PASS", " <b>The ~  is successfully  converted into new line charracter </b>");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The ~ in the Actual message " + newLineActualmsg + " is not converted into new line charracter ....Please see Expected text --->" + newLineExpectedmsg);

                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforTilta() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 5, "TestData_XMLSMSListener.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getdatafordefaultsender")
    public void DEFAULTSENDER_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,String Expected_sender) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the DEFAULT SENDER<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "Dummy", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "Dummy", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "Dummy", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 206 orchestrator SERVER</b>");
                    }
                }

                //

                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "Dummy", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    // String actualsender=jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (Expected_sender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + response_id + "  Recieved sender is " + recievedsender + "  matching with expected sender " + Expected_sender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + response_id + "   Recieved sender is " + recievedsender + " NOT matching with expected sender " + Expected_sender);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + response_id + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + response_id + "  is not sent to SMSC");
                }



            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getdatafordefaultsender() {
        Object data[][] = ExcelUtils.getTestData("DEFAULT_SENDER_TEST", 0, "TestData_XMLSMSListener.xlsx");
        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSOIPDATA")
    public void Check_SOIP_CASES_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,String ExpectedStatusdesc, String ExpectedSMSC) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the DEFAULT SENDER<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;
                Thread.sleep(2000);
                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);
                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                String actualsmsc = MISDATA.get("smscname");
                String actualstatusdesc = MISDATA.get("statusdesc");
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if ((ExpectedStatusdesc.contentEquals(actualstatusdesc)) && actualsmsc.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }



    @DataProvider
    public Object[][] getSOIPDATA() {

        Object data[][] = ExcelUtils.getTestData("SOIP_TEST", 0, "TestData_XMLSMSListener.xlsx");

        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSPECIFICROWforTemplateCONVERSION")
    public void Check_Templateconversion_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,String contertedtext) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the TEMPLATECONVERSTION<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;
                Thread.sleep(2000);

                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + response_id + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                System.out.println("this is actual  msg  before conversion" + MSG);
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg  before conversion <b>" + MSG + "</b>");

                System.out.println("this is expected converted msg from Excel" + contertedtext);
                ExtentBASETEST.extentReportsDemo("INFO", "this is expected converted msg from Excel <b>" + contertedtext + "</b>");

                System.out.println("this is actual converted msg from live sql table" + MISDATA.get("messagetext"));
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("messagetext") + "</b>");
                try {
                    if (contertedtext.contentEquals(MISDATA.get("messagetext"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The msg conversion is successfull</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The msg conversion is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }



    @DataProvider
    public Object[][] getSPECIFICROWforTemplateCONVERSION() {

        Object data[][] = ExcelUtils.getTestData("TEMPLATECONVERSTION", 0, "TestData_XMLSMSListener.xlsx");

        return data;
    }



    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSPECIFICROWforshortening")
    public void Check_SHORTENING_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlSMSListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");
            XML_OPERATIONS.ADD_NODE("shorten", "1", "XmlSmsListener.xml");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the TEMPLATECONVERSTION<b>");
            Response response = request.post();

            XML_OPERATIONS.REMOVE_NODE("shorten", "XmlSmsListener.xml");
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;
                System.out.println("Response Object  " + response_id);
                Thread.sleep(2000);


                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + response_id);


                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);


                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                boolean shortresult = SQLPOOL.checkshortstageDB(response_id, PushRecieverLivetablename, ShortstageLiveBeetablename);

                if (shortresult) {
                    System.out.println("Shortening passed");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(500, response_id, PushRecieverLivetablename);


                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        ExtentBASETEST.extentReportsDemo("PASS", "SHORTENING PASSED");

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA with shortening -->" + MISDATA.toString());
                    }

                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                    //ENDDLR
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "SHORTENING FAILED");
                    Assert.assertTrue(shortresult, "Shortening Failed");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }



    @DataProvider
    public Object[][] getSPECIFICROWforshortening() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 6, "TestData_XMLSMSListener.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSPECIFICROWforinsufficentcredit")
    public void INSUFFICIENT_CREDIT_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlSMSListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Insufficent credit test<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                boolean DLRCHECKFLAG = false;
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = 	response.body().asString();

                String response_id = temp;
                Thread.sleep(2000);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), false, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), false, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                //

                boolean result = LinuxLogReader.CheckPrepaidbalance(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), false, "DUMMY", ob.GetProperty("commonloglocation205"),ob.GetProperty("PROCESSORLOGFILENAME"));

                if (result) {
                    DLRCHECKFLAG = true;
                    ExtentBASETEST.extentReportsDemo("PASS", FunctionName + " PASSED for " + response_id);

                } else {

                    ExtentBASETEST.extentReportsDemo("FAIL", FunctionName + " FAILED for " + response_id);


                }
                if (DLRCHECKFLAG) {
                    TestBase.setcurrenttime();
                    Thread.sleep(1000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }




    @DataProvider

    public Object[][] getSPECIFICROWforinsufficentcredit() {

        Object data[][] = ExcelUtils.getTestData("INSUFFICIENT_CREDIT", 0, "TestData_XMLSMSListener.xlsx");
        return data;
    }



    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforCLIYES")
    public void CLIYES_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlSMSListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the OPENCLI YES<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = 	response.body().asString();

                String responseid = temp;
                Thread.sleep(2000);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                Thread.sleep(2000);


                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"),ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + responseid);

                    }

                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforCLIYES() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 9, "TestData_XMLSMSListener.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforCLINO")
    public void CLINO_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlSMSListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the OPEN CLI NO<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = 	response.body().asString();

                String responseid = temp;
                Thread.sleep(2000);

                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"),ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (!actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforCLINO() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 10, "TestData_XMLSMSListener.xlsx");

        return data;
    }





    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void OPENTEMPLATE_XMLSMSListener() {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlSMSListner --> " + "OPENTEMPLATE" + "</b>");
        try {
            String dtm = "676767";
            String dpi = "84343556";
            String tc = "0";


            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListnerOPENTEMPLATE.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the OPEN CLI NO<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = 	response.body().asString();

                String responseid = temp;
                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "this is Expected tc -->  <b>" + tc + "</b>" + " dpi --> <b>" + dpi + "</b>" + "dtm --> <b>" + dtm + "</b>");

                ExtentBASETEST.extentReportsDemo("INFO", "this is Actual --> tc from DB  --> <b>" + MISDATA.get("tempid_category") + "</b>" + " dpi from DB  --> <b>" + MISDATA.get("dlt_peid") + "</b>" + " dtm from DB  --><b>" + MISDATA.get("dlt_tempid") + "</b>");


                String act_tc = MISDATA.get("tempid_category");
                String act_dpi = MISDATA.get("dlt_peid");
                String act_dtm = MISDATA.get("dlt_tempid");


                try {
                    if (tc.contentEquals(act_tc) && dpi.contentEquals(act_dpi) && dtm.contentEquals(act_dtm)) {
                        System.out.println("Message is passed with dtm dpi tc");
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The actual and expected  tc , dpi and dtm are matching</b>");
                    } else {
                        System.out.println("Message is not passed with dtm ,dpi & tc parameter");
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The actual and expected  tc , dpi and dtm are Not matching</b>");
                    }
                } catch (NullPointerException e) {
                    System.out.println("Please check the live table...");
                    ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                }



            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @Test(priority = 2, enabled = false, invocationCount = 1)
    public void Check_TEMP_XMLSMSListener() {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>TEMP --> </b>");
        try {


            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");


           FileReader read=new FileReader(XMLDataInFile);
            //BufferedReader br = new BufferedReader(new FileReader(XMLDataInFile));
            String xmldata="";
int i;
            while ((i = read.read()) != -1)
            {
                xmldata=xmldata+(char)i;
                // Print all the content of a file

        }

            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(xmldata);


            System.out.println("XMLDATA IS  " + "xmlStr="+xmldata);
            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the TEMPLATECONVERSTION<b>");
            Response response = request.post();

            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Response ID " + response.body().asString());



        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }



    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_XMLSMSListener() {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlSMSListner -->RCS "+"</b>");
        try {
            // Specify the base URL to the RESTful web service

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XMLSMSLISTENER_RCS.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the OPEN CLI NO<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = 	response.body().asString();

                String responseid = temp;
                Thread.sleep(2000);

                boolean DLRCHECK = false;
                String RCSRECIEVRTABLENAME = "";
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //


                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {


                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(submitstatus.contentEquals("submitted"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        DLRCHECK = true;
                        joinid=MISDATA.get("joinid");
                    }
                    else {
                        ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                        Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }



    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_XMLSMSListener_CAPABILITY_YES() {

        String   ph[]=new String[10];
        ph[1]="7838787657";
        String capability="YES";

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlSMSListner -->RCS "+"</b>");
        try {
            // Specify the base URL to the RESTful web service

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XMLSMSLISTENER_RCSCAPABLE_YES.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the RCS Capability YES<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                boolean DLRCHECK = false;
                String RCSRECIEVRTABLENAME = "";
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(5000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                        if(capability.contentEquals("YES")) {

                            if (responseString.contains("RCS capable mobile list -> [+91" + ph[1] + "]")) {
                                ExtentBASETEST.extentReportsDemo("PASS", "<b> Capability check is passed "+"RCS capable mobile list -> [+91" + ph[1] + "]");

                            } else {
                                ExtentBASETEST.extentReportsDemo("FAIL", "<b> Capability check is NOT Passed for number</b>");

                            }
                        }


//RCS capable mobile list -> [+919971498470]

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {


                    ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(capability.contentEquals("YES")) {
                        if (submitstatus.contentEquals("submitted")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                            DLRCHECK = true;
                            joinid = MISDATA.get("joinid");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);
                            Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);

                        }
                    } else if(capability.contentEquals("NO"))
                    {
                        if (submitstatus.contentEquals("notCapable") ) {
                            ExtentBASETEST.extentReportsDemo("PASS", " DB has updated with status "+"<b>"+submitstatus+"</b>");
                            String expectedQname="RCS_NOT_CAPABLE_+91" + ph[1];
                            ExtentBASETEST.extentReportsDemo("INFO", " <b> Now going to check not capable redis Q..</b>");

                            String Qdata=JedisQueueReader.GetRedisdata(ob.GetProperty("redis_server_ip"),ob.GetProperty("redis_server_user"),ob.GetProperty("redis_server_pass"),ob.GetProperty("redis_server_host"),ob.GetProperty("redis_server_port"),ob.GetProperty("redis_host_pass"),expectedQname);
                            //  ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);


                            if(Qdata.contentEquals("1"))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);

                            }
                            else
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has NOT  been set..Please check Redis property and investigate Manually ");


                            }
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " NOT CAPABLE CHECK IS FAILED AND RCS status in DB is "+"<b>"+submitstatus+"</b>");

                        }
                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_XMLSMSListener_CAPABILITY_NO() {

        String  ph[]=new String[10];
        ph[1]="9838301908";
        String capability="NO";

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XmlSMSListner -->RCS "+"</b>");
        try {
            // Specify the base URL to the RESTful web service

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XMLSMSLISTENER_RCSCAPABLE_NO.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the RCS Capability YES<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                boolean DLRCHECK = false;
                String RCSRECIEVRTABLENAME = "";
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(5000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                        if(capability.contentEquals("YES")) {

                            if (responseString.contains("RCS capable mobile list -> [+91" + ph[1] + "]")) {
                                ExtentBASETEST.extentReportsDemo("PASS", "<b> Capability check is passed "+"RCS capable mobile list -> [+91" + ph[1] + "]");

                            } else {
                                ExtentBASETEST.extentReportsDemo("FAIL", "<b> Capability check is NOT Passed for number</b>");

                            }
                        }


//RCS capable mobile list -> [+919971498470]

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {


                    ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(capability.contentEquals("YES")) {
                        if (submitstatus.contentEquals("submitted")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                            DLRCHECK = true;
                            joinid = MISDATA.get("joinid");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);
                            Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);

                        }
                    } else if(capability.contentEquals("NO"))
                    {
                        if (submitstatus.contentEquals("notCapable") ) {
                            ExtentBASETEST.extentReportsDemo("PASS", " DB has updated with status "+"<b>"+submitstatus+"</b>");
                            String expectedQname="RCS_NOT_CAPABLE_+91" + ph[1];
                            ExtentBASETEST.extentReportsDemo("INFO", " <b> Now going to check not capable redis Q..</b>");

                            String Qdata=JedisQueueReader.GetRedisdata(ob.GetProperty("redis_server_ip"),ob.GetProperty("redis_server_user"),ob.GetProperty("redis_server_pass"),ob.GetProperty("redis_server_host"),ob.GetProperty("redis_server_port"),ob.GetProperty("redis_host_pass"),expectedQname);
                            //  ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);


                            if(Qdata.contentEquals("1"))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);

                            }
                            else
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has NOT  been set..Please check Redis property and investigate Manually ");


                            }
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " NOT CAPABLE CHECK IS FAILED AND RCS status in DB is "+"<b>"+submitstatus+"</b>");

                        }
                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }
    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLDARSdata")
    public void Check_DARS_XMLSMSListener_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,String ExpectedSMSC) {
        ExtentBASETEST.STARTTEST("<b>XMLSMSListener_Listener_DARS--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_XMLSMSListener") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the SMSCOUNT matching<b>");
            Response response = request.post();



            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                String temp = response.body().asString();

                String responseid = temp;
                System.out.println(responseid);
                Thread.sleep(2000);

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                String actualsmsc = MISDATA.get("smscname");
                if (actualsmsc == null) {
                    actualsmsc = "BLK";
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
                    Assert.fail("<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
                }
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if (ExpectedSMSC.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> <font color=green> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b> </font>");
                        ExtentBASETEST.extentReportsDemo("INFO", "<font color=blue>The MIS data for the same is below --> <br> " + MISDATA + "</font>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> <font color=red>Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b></font>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLDARSdata() {
        Object data[][] = ExcelUtils.getTestData("DARS", 0, "TestData_XMLSMSListener.xlsx");
        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getJUM_10326")
    public void Check_getJUM_10326_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String contertedtext) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_XMLSMSListener") + " " + "<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the TEMPLATECONVERSTION<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;
                Thread.sleep(2000);

                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + response_id + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                System.out.println("this is actual  msg  before conversion" + MSG);
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg  before conversion <b>" + MSG + "</b>");

                System.out.println("this is expected converted msg from Excel" + contertedtext);
                ExtentBASETEST.extentReportsDemo("INFO", "this is expected converted msg from Excel <b>" + contertedtext + "</b>");

                System.out.println("this is actual converted msg from live sql table" + MISDATA.get("messagetext"));
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("messagetext") + "</b>");
                try {
                    if (contertedtext.contentEquals(MISDATA.get("messagetext"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The msg conversion is successfull</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The msg conversion is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            Assert.fail(e.toString());

        }
    }
    //test
    @DataProvider
    public Object[][] getJUM_10326() {

        Object data[][] = ExcelUtils.getTestData("JUM_10326", 0, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");

        return data;
    }




    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLCredencedata")
    public void Check_Credence_XMLSMSListener_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,String credenceCHECK) {
        ExtentBASETEST.STARTTEST("<b>XMLSMSListener_Listener_TEMPLATEMATCHING--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_XMLSMSListener") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XmlSmsListener.xml", "BLK");
           /* if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }*/
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Crdedence data<b>");
            Response response = request.post();

           /* if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }*/


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println("this is response "+response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;
                System.out.println(response_id);
                boolean DLRCHECK = false;
                String DLRLivetablename = "";
                Thread.sleep(2000);

                //start
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }

                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(1500);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(1500);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                Thread.sleep(5000);
//test

                if (true) {


                    String credendedata=JedisQueueReader.Getcredenceredisdata(response_id);
                    if(credendedata.isEmpty()&& credenceCHECK.contentEquals("YES"))
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The data is not found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+response_id+" but is was expected to be in Credence Q</b>");

                    }
                    else if(credendedata.isEmpty()&& credenceCHECK.contentEquals("NO"))
                    {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The data is not found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+response_id+" AND  is was ALSO NOT expected to be in Credence Q</b>");

                    }
                    else if((!credendedata.isEmpty()) && credenceCHECK.contentEquals("NO"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b> CREDENCE DATA IS---></b>"+credendedata);

                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The data  is  found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+response_id+" but is was NOT expected to be in Credence Q</b>");

                    }

                    else if((!credendedata.isEmpty()) && credenceCHECK.contentEquals("YES"))
                    {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST HAS BEEN  FORWARDED TO CREDENCE ,DATA IS---></b>"+credendedata);

                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The data is found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+response_id+" AND  is was ALSO  expected to be in Credence Q</b>");

                    }



                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON SMS ROUTER COMPONENT</b>");
                }

                //end

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getXMLCredencedata() {
        Object data[][] = ExcelUtils.getTestData("JUM-5768_CREDENCE", 0, "TestData_XMLSMSListener.xlsx");
        return data;
    }




    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getORCHESTRATOR")
    public void Check_Orchestrator_XMLSMSListener_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,String PARELLER, String SMS,String WA, String RCS,String P1,String P2, String P3) {
        ExtentBASETEST.STARTTEST("<b>XMLSMSListener_Listener_Orchestrator--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_XMLSMSListener") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetXMLSMSListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XMLSMSORC.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XMLSMSORC.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Crdedence data<b>");
            Response response = request.post();



            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println("this is response "+response.body().asString());
                String temp = response.body().asString();

                String response_id = temp;
                System.out.println(response_id);
                boolean DLRCHECK = false;
                String DLRLivetablename = "";
                Thread.sleep(2000);

                //start
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                if(PARELLER.contentEquals("YES")) {

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>THIS IS PARELLEL CASE </b>");

                    if(SMS.contentEquals("SMS"))
                    {

                        ob.handleMessageType1(SMS, response_id);
                    }

                    if(RCS.contentEquals("RCS"))
                    {
                        ob.handleMessageType1(RCS, response_id);
                    }

                    if(WA.contentEquals("WA"))
                    {
                        ob.handleMessageType1(WA, response_id);
                    }
                }

                if(PARELLER.contentEquals("NO")) {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>THIS IS PRIORITY CASE </b>");
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check first priority --> </b>"+P1);
                    ob.handleMessageType1(P1, response_id);

                    Thread.sleep(30000);
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check second priority --> </b>"+P2);
                    ob.handleMessageType1(P2, response_id);
                    Thread.sleep(30000);
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to check third priority --> </b>"+P3);
                    ob.handleMessageType1(P3, response_id);

                }
                //end

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getORCHESTRATOR() {
        Object data[][] = ExcelUtils.getTestData("ORCHESTRATOR", 0, "TestData_XMLSMSListener.xlsx");
        return data;
    }


    @DataProvider
    public Object[][] getRCSTESTDATA() {

        Object data[][] = ExcelUtils.getTestData("RCS_TEST_DATA", 0, "TestData_XMLSMSListener.xlsx");

        return data;
    }


    @Test(priority = 26, enabled = false, invocationCount = SetandGetGlobalVariable.count,dataProvider = "getXMLRCSdata")
    public void CHECK_RCS_XMLSMSListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String SHORT)
    {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_XMLSMSListener")+" "+"<b>XMLSMSListener_RCS--></b>");
        try {
            String ShortTYPE = "";

            double shorttype = Double.parseDouble(SHORT);
            int ishorttype = (int) (Math.round(shorttype * 100) / 100);
            ShortTYPE = String.valueOf(ishorttype);

            XML_OPERATIONS.setXMLSMSLISTENERFORRCSANDWA(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "XMLLANGUAGERCS.xml", "BLK",SHORT);

            // Specify the base URL to the RESTful web service

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XMLLANGUAGE/XMLLANGUAGERCS.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the RCS functionality<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                boolean DLRCHECK = false;
                String RCSRECIEVRTABLENAME = "";
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                        if(ShortTYPE.contentEquals("1"))
                        {
                            String check1="\"sto\":\"SHORT_URL_PICKER_INPUT_QUEUE\"";
                            String check2="CommonUtility::sendToShortUrlRepository::appId -> "+APPID;
                            if(responseString.contains(check1)&&responseString.contains(check2))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", "<b> For the request shortening flag was 1 and request successfully sent to SHORT URL component of RCS and it has been verified in log   both strings are found in log</b>" +"First string "+ check1 +"Second string "+ check2);

                            }

                            TestBase.setcurrenttime();
                            Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                            String RCSRecieverLivetablename = Livetablename.get("RCSRECIEVERTABLENAME");
                            String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
                            String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                            boolean shortresult = SQLPOOL.checkshortstageDB(responseid, RCSRecieverLivetablename, ShortstageLiveBeetablename);

                            if (shortresult) {
                                System.out.println("Shortening passed");
                                Map<String, String> BEEMISDATA = SQLPOOL.GETMISDATA_FROM_SHORTSTAGE_RECIEVERTABLE( responseid, RCSRecieverLivetablename,ShortstageLiveBeetablename,"routing_channel");

                                ExtentBASETEST.extentReportsDemo("INFO", " The Routing channel for RCS request in Short bee table  is  "+BEEMISDATA.get("routing_channel"));

                                if (BEEMISDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                                } else {
                                    ExtentBASETEST.extentReportsDemo("INFO", "SHORTENING PASSED");

                                }


                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "SHORTENING FAILED");
                            }
                        }

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //


                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";
                ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA  from DB "+MISDATA);

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {
                    if(MISDATA.get("templateid").isEmpty())
                    { ExtentBASETEST.extentReportsDemo("FAIL", "Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());
                        Assert.assertTrue(false,"Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());

                    }else {
                        ExtentBASETEST.extentReportsDemo("PASS", " <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());
                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(submitstatus.contentEquals("submitted"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        DLRCHECK = true;
                        joinid=MISDATA.get("joinid");
                    }
                    else {
                        ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                        Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }



            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            Assert.fail(e.toString());

        }
    }
    @DataProvider
    public Object[][] getXMLRCSdata() {
        Object data[][] = ExcelUtils.getTestData("RCS_TEST_DATA", 0, "TestData_XMLSMSListener.xlsx");
        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLWAdata")
    public void CHECK_WA_XMLSMSListener(
            String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO,
            String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype,
            String Language, String SHORT) {

        ExtentBASETEST.STARTTEST("Request URL --> " + ob.GetProperty("BASEURI_XMLSMSListener")
                + " <b>XMLSMSListener_WA --> " + FunctionName + "</b>");

        try {

            String ShortTYPE = "0";
            try {
                double shorttype = Double.parseDouble(SHORT);
                ShortTYPE = String.valueOf((int) Math.round(shorttype));
            } catch (Exception e) {
                ExtentBASETEST.extentReportsDemo("INFO", "Invalid SHORT param, defaulting to 0");
            }


            XML_OPERATIONS.setXMLSMSLISTENERFORRCSANDWA(
                    FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG,
                    Contenttype, Language, "XMLSMSLISTENER_WA", "BLK", ShortTYPE);

            //  File XMLDataInFile = new File(System.getProperty("user.dir")+ "/src/main/resources/Util/XML_REPOSITORY/XMLSMSLISTENER_WA.xml");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListener.xml");

            RequestSpecification request = RestAssured.given()
                    .contentType(ContentType.XML)
                    .headers(requestHeaders)
                    .body(XMLDataInFile);

            ExtentBASETEST.extentReportsDemo("INFO",
                    "<b style='background-color:orange;'>Sending WA XML Listener Request...</b>");

            Response response = request.post(ob.GetProperty("BASEURI_XMLSMSListener"));
            int statusCode = response.getStatusCode();
            ExtentBASETEST.extentReportsDemo("INFO", "Response Code: " + statusCode);

            if (statusCode != 200) {
                ExtentBASETEST.extentReportsDemo("FAIL", "Non-200 Response: " + statusCode);
                Assert.fail("API did not return 200 OK");
                return;
            }


            String responseBody = response.body().asString();
            XmlPath xmlPath = new XmlPath(responseBody);
            String responseId = xmlPath.getString("push.response-id");
            ExtentBASETEST.extentReportsDemo("INFO", "Response ID Received: <b>" + responseId + "</b>");
            Thread.sleep(2000);


            TestBase.setcurrenttime();
            Map<String, String> liveTable = TestBase.Normal_calculateandsetlivetablename();
            String WARECEIVER_TABLE = liveTable.get("WARECIEVERTABLENAME");
            String WADLR_TABLE = liveTable.get("WADLRTABLENAME");

            Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROM_WA_RECIEVERTABLE(5000, responseId, WARECEIVER_TABLE);

            if (MISDATA.isEmpty()) {
                ExtentBASETEST.extentReportsDemo("FAIL", "No data found in WA Receiver table for ID: " + responseId);
                Assert.fail("No data found in WA Receiver table");
            }

            ExtentBASETEST.extentReportsDemo("INFO", "WA Receiver Table Data: " + MISDATA.toString());

            String status = MISDATA.getOrDefault("statusdesc", "null");
            if (status.equalsIgnoreCase("submitted")) {
                ExtentBASETEST.extentReportsDemo("PASS", "Message successfully submitted to WA");
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Message not submitted to WA; status: " + status);
                Assert.fail("Message not submitted to WA; status: " + status);
            }


            String joinId = MISDATA.get("joinid");
            if (joinId != null && !joinId.isEmpty()) {
                Map<String, String> DLRDATA = SQLPOOL.GETWADATAFROMDLRLIVETABLE(5000, joinId, WADLR_TABLE);
                if (DLRDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("INFO", "DLR Data not found yet for joinid: " + joinId);
                } else {
                    ExtentBASETEST.extentReportsDemo("PASS", "DLR Data Found: " + DLRDATA.toString());
                }
            } else {
                ExtentBASETEST.extentReportsDemo("INFO", "JoinID not available for DLR check");
            }


            ExtentBASETEST.extentReportsDemo("INFO", "Message Sent: <b>" + MSG + "</b>");
            ExtentBASETEST.extentReportsDemo("PASS", "<b>WA XML Listener Test Passed Successfully</b>");

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            Assert.fail(e.toString());
        }
    }

    @DataProvider
    public Object[][] getXMLWAdata() {
        Object data[][] = ExcelUtils.getTestData("ShortingWA1", 7, "TestData_XML_LANGUAGE_API_LISTENER.xlsx");
        return data;
    }
}





