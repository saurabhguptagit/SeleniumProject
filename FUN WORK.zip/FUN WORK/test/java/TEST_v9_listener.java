import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;

import io.restassured.http.ContentType;

import java.util.*;

import org.testng.annotations.DataProvider;

public class TEST_v9_listener extends JSONENCYPTER {

    Map<String, String> requestHeaders = new HashMap<>();
    String sheetName = "V9Templatecases";
    TestBase ob;
    //test
    @BeforeTest

    public void setHeader() {
        requestHeaders.put("content-type", "application/Json");
        requestHeaders.put("x-message-id", "c75e17d5-e160-4649-a2a8-2621e2ew8f2e");
        requestHeaders.put("x-context-id", "EM-trx_a28a6bqwwe6a02");
        requestHeaders.put("x-client-id", "reachout");
        requestHeaders.put("x-stencil-id", "STNIU7SQA");
        requestHeaders.put("x-app-name", "flipkart");
        requestHeaders.put("x-be-id", "default");
    }

    @BeforeTest
    public void setBaseURI() throws Exception {
        ob = new TestBase();
        // ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST FOR V9 LISTNERS</b></h5>");
        String env = ob.GetProperty("Environment");
        if (env.contentEquals("QA_AWS")) {

            RestAssured.baseURI = ob.GetProperty("QA_AWS_BASE_URI");

        } else if (env.contentEquals("QA_142_Direct")) {
            RestAssured.baseURI = ob.GetProperty("142_BASE_URI");
        } else {
            throw new Exception("Envioenment name in Property is not valid");
        }

    }


    @Test(priority = 1, enabled = false, dataProvider = "getCRMTestData", invocationCount = SetandGetGlobalVariable.count)
    public void Check_TemplateMatching_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_TEMPLATEMATCHING</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
           TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", AppID);  //sinchdemo1020200

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();
                boolean DLRCHECK = false;
                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    System.out.println("Request is accepted");
                    // LISTNER LOG FETCH CODE
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, TestMSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                        if (LISTNER98SERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                        }
                    }
                    //

                    //PROCESSOR LOG CHECK
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, TestMSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                        }
                    }

                    //


                    //ORECHESTRATOR  LOG CHECK
                    if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, TestMSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                        }
                    }

                    //
                    boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, TestMSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    String DLRLivetablename = "";
                    if (SMSCRESULT) {
                        JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                        ExtentBASETEST.extentReportsDemo("PASS", "TEMPLATE MATCHING TEST HAS BEEN  PASSED with below remarks<ol>\n" +
                                "  <li>Request " + responseid + " was successfully sent to SMSC</li>\n" +
                                "  <li>The template text was matching with the expected testmessage</li>\n" +
                                "  <li>Template ID is matching</li>\n" +
                                "  <li>Text Used " + TestMSG + "</li>\n" +
                                "</ol>");

                        TestBase.setcurrenttime();
                        Thread.sleep(2000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                        DLRLivetablename = Livetablename.get("DLRTABLENAME");
                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(500, responseid, PushRecieverLivetablename);

                        if (MISDATA.isEmpty()) {
                            ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                        } else {
                            DLRCHECK = true;

                            ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                        }
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                        int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                        int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                        boolean retrypassed = false;
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                        for (int k = 0; k < DBretrytimes; k++) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                            TestBase.setcurrenttime();
                            Thread.sleep(1000);
                            Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                            String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                            DLRLivetablename = Livetablename.get("DLRTABLENAME");
                            Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);


                            if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                                ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                                retrypassed = true;
                                DLRCHECK = true;
                                break;
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                                Thread.sleep(Retry_Waiting_period);
                            }

                        }

                        if (!retrypassed) {
                            ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + responseid);

                        }

                    }


                    //DLR
                    if (DLRCHECK) {
                        boolean result = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + result);

                        if (result) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                            boolean dlrrecieved = false;
                            try {
                                dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            } catch (Exception e) {
                                ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                                System.out.println("There is some issue with DLR fetch " + e);
                            }
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        } else {
                            System.out.println("DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = false;
                            try {
                                dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            } catch (Exception e) {
                                ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                                System.out.println("There is some issue with DLR fetch " + e);
                            }

                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }

                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }


                        }
                    }
                    ExtentBASETEST.extentReportsDemo("INFO", "DLR TEST EXECUTED");

                    //END
                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");

                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @Test(priority = 2, enabled = false, dataProvider = "getV9dataNegative", invocationCount = SetandGetGlobalVariable.count)

    public void Check_Error_Codes_V9(String Testname, String JSONfilename, String status_code, String Appid) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_ERRORCASE</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Negative case-->" + Testname + "</b>");
            // Specify the base URL to the RESTful web service
            TestJSONENCRYPTION(JSONfilename, "V9", "testdlt301291009", Appid);
            double a = Double.parseDouble(status_code);
            int STATUSCODE = (int) (Math.round(a * 100) / 100);
            String scode = String.valueOf(STATUSCODE);
            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));


            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();
            // Response response = request1.request(Method.POST);
            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                try {
                    String AcceptanceResult = jsonObject.get("accepted").toString();
                    String errorcode = jsonObject.get("errorcode").toString();
                    if (AcceptanceResult.contentEquals("false") && errorcode.contentEquals(scode)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "Expected Error code "+scode +"  matched with actual errorcode "+errorcode+" for FUNCTION " + Testname);
                        System.out.println("Error code matched for FUNCTION " + Testname);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "Error code not matched for FUNCTION " + Testname + " Actual Errorcode is = " + errorcode + "  but Expected was = " + scode);
                        Assert.fail("Error code not matched for FUNCTION " + Testname + " Actual Errorcode is = " + errorcode + "  but Expected was = " + scode);

                    }
                } catch(Exception e)
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Response id "+ jsonObject.toString()+" generated instead off getting Error code for Test " + Testname);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success for " + Testname);
                Assert.fail("Status code is not success for " + Testname);
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }

    }

    @Test(priority = 2, enabled = false, dataProvider = "getV9LOGERRORCHECK", invocationCount = SetandGetGlobalVariable.count)

    public void Check_ERRORCASEINLOG_V9(String functionname, String Jsonfilename, String Appid, String Expectedmsg) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_ERRORLOG CASE</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Negative LOG case-->" + functionname + "</b>");
            // Specify the base URL to the RESTful web service
            TestJSONENCRYPTION(Jsonfilename, "V9", "testdlt301291009", Appid);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));


            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();
            // Response response = request1.request(Method.POST);
            int statusCode = response.getStatusCode();



            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if ("true".contentEquals(AcceptanceResult)) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");

                    //PROCESSOR LOG CHECK
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                        }
                    }

                    //

                    boolean result = LinuxLogReader.CheckLOGERRORMESSAGE(Expectedmsg, responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), false, "DUMMY", ob.GetProperty("commonloglocation205"),ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (result) {
                        ExtentBASETEST.extentReportsDemo("PASS", functionname + " TEST  PASSED for " + responseid + "<br> below message found in log " + Expectedmsg);
                        //DLR
                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String DLRLivetablename=Livetablename.get("DLRTABLENAME");
                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"),ob.GetProperty("dlrlogfileName"));

                        if(DLRresult)
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"),ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                        }
                        else
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved=SQLPOOL.CheckMysqlDLRTABLE(responseid,DLRLivetablename);
                            if(dlrrecieved)
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA= SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000,responseid,DLRLivetablename);
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            }
                            else
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //DLREND

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", functionname + "TEST  FAILED for " + responseid);

                    }

                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is "+jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success for " + functionname);
                Assert.fail("Status code is not success for " + functionname);
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }

    }

    @DataProvider
    public Object[][] getV9LOGERRORCHECK() {
        Object data[][] = ExcelUtils.getTestData("V9dataNegativeLOG", 0, "TestData-V9.xlsx");
        return data;
    }
    @Test(priority = 3, enabled = false, dataProvider = "getV9TemplateNotMatched", invocationCount = SetandGetGlobalVariable.count)
    public void Check_TemplateNOTMatching_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_TEMPLATENOTMATCHING</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template Not matching Case V9<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();
            System.out.println("Respnsebody" + response.body().asString());

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    System.out.println("Request is accepted");

                    TestBase.setcurrenttime();

                    Thread.sleep(2000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }
                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());


                    if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("TEMPLATE NOT FOUND AT ACL"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "DLT TEMPID NOT FOUND case  is passed");
                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                        //DLREND

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLT TEMPID NOT FOUND case is not passed");
                    }
                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());
        }
    }
//not done
    @Test(priority = 3, enabled = false, dataProvider = "getV9International", invocationCount = SetandGetGlobalVariable.count)
    public void Check_International_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_International_Case</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the International case for V9</b>");
            Response response = request.post();
            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                System.out.println(statusCode);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if ("true".contentEquals(AcceptanceResult)) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                   /*
                    Thread.sleep(5000);
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("commonloglocation94"), ob.GetProperty("rcvrlogfileName"));
                    try {
                        if (jsonbody.isEmpty()) {
                            ExtentBASETEST.extentReportsDemo("ERROR ", "The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
                        }

                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    } catch (Exception e) {

                        ExtentBASETEST.extentReportsDemo("ERROR ", e.toString());

                    } */
                    TestBase.setcurrenttime();
                    Thread.sleep(2000);
                    Map <String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename=Livetablename.get("PUSHTABLENAME");

                    Map <String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000,responseid, PushRecieverLivetablename);
                    System.out.println(MISDATA);
                    String smsc=MISDATA.get("smscname");
                   // String smsc = String.valueOf(jsonbody.get("sn"));
                    if (smsc.contains("-inter")) {

                        ExtentBASETEST.extentReportsDemo("PASS", "Request " + responseid + " is successfully submitted to SMSC & smsc selected is " + smsc);


                    } else if (smsc.contains("NOT SUBMITTED TO SMSC")) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + " Request has not been submitted to SMSC");
                        Assert.assertTrue(false, "FOR Request " + responseid + " SMSC is not matched for international request---> " + smsc);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + responseid + " SMSC is not matched for international request---> " + smsc);
                        Assert.assertTrue(false, "FOR Request " + responseid + " SMSC is not matched for international request--->" + smsc);
                    }
                    // Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                } else if ("false".contentEquals(AcceptanceResult)) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO ", "The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
            ExtentBASETEST.extentReportsDemo("ERROR ", e.toString());
            Assert.fail(e.toString());

        }
    }

    @Test(priority = 3, enabled = false, dataProvider = "getV9CLIYES", invocationCount = SetandGetGlobalVariable.count)
    public void Check_OpenCLI_YES_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_CLIYES_Case</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the OPEN CLI YES case for V9</b>");
            Response response = request.post();
            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                System.out.println(statusCode);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if ("true".contentEquals(AcceptanceResult)) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");

                    // LISTNER LOG FETCH CODE
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "Dummy", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                        if (LISTNER98SERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                        }
                    }
                    //

                    //PROCESSOR LOG CHECK
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "Dummy", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 205 processor SERVER</b>");
                        }
                    }

                    //


                    //ORECHESTRATOR  LOG CHECK
                    if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "Dummy", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 206 orchestrator SERVER</b>");
                        }
                    }

                    //
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                    boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "Dummy", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    if (SMSCRESULT) {
                        JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        String actualsender = jsonbody.get("l").toString();
                        String recievedsender = jsonbody.get("as").toString();
                        if (actualsender.contentEquals(recievedsender)) {
                            ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " is matching with  Recieved sender is " + recievedsender);

                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is not matching with  Recieved sender is " + recievedsender);

                        }
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    }
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                } else if ("false".contentEquals(AcceptanceResult)) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("ERROR", e.toString());
            Assert.fail(e.toString());

        }
    }

    @Test(priority = 3, enabled = false, dataProvider = "getV9CLINO", invocationCount = SetandGetGlobalVariable.count)
    public void Check_OpenCLI_NO_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_CLINO_Case</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the OPEN CLI NO case for V9</b>");
            Response response = request.post();
            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                System.out.println(statusCode);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if ("true".contentEquals(AcceptanceResult)) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");

                    // LISTNER LOG FETCH CODE
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "DUMMY", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                        if (LISTNER98SERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                        }
                    }
                    //

                    //PROCESSOR LOG CHECK
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "DUMMY", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 205 processor SERVER</b>");
                        }
                    }

                    //


                    //ORECHESTRATOR  LOG CHECK
                    if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "DUMMY", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 206 orchestrator SERVER</b>");
                        }
                    }

                    //
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                    boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "Dummy", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    if (SMSCRESULT) {
                        JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "Dummy", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        String actualsender = jsonbody.get("l").toString();
                        String recievedsender = jsonbody.get("as").toString();
                        if (!actualsender.contentEquals(recievedsender)) {
                            ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                        }
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    }
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                } else if ("false".contentEquals(AcceptanceResult)) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("ERROR", e.toString());
            Assert.fail(e.toString());

        }
    }

    @Test(priority = 3, enabled = false, dataProvider = "getV9InsufficientCredit", invocationCount = SetandGetGlobalVariable.count)
    public void Check_Insufficient_Credit_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_Insufficient_Credit_Case</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Insufficient Credit case for V9</b>");
            Response response = request.post();

            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                boolean DLRCHECKFLAG = false;
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if ("true".contentEquals(AcceptanceResult)) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");

                    // LISTNER LOG FETCH CODE
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), false, "dummy", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                        if (LISTNER98SERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                        }
                    }
                    //

                    //PROCESSOR LOG CHECK
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                        }
                    }

                    //
                    boolean result = LinuxLogReader.CheckLOGERRORMESSAGE("Insufficient Credits", responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), false, "DUMMY", ob.GetProperty("commonloglocation205"),ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (result) {
                        ExtentBASETEST.extentReportsDemo("PASS", "PREPAIDBALANCE  PASSED for " + responseid);
                        DLRCHECKFLAG = true;
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "PREPAIDBALANCE  PASSED for " + responseid);

                    }


                    //DLR
                    if (DLRCHECKFLAG) {
                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                    }

                    //END
                } else if ("false".contentEquals(AcceptanceResult)) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    Assert.fail("Something is wrong");

                }
            } else {
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            Assert.fail(e.toString());

        }
    }

    Response response;

    @Test(priority = 3, enabled = false, dataProvider = "getV9DuplicateMessage", invocationCount = SetandGetGlobalVariable.count)
    public void Check_DuplicateMessage_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_DuplicateMessage_Case</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", AppID);
        } catch (Exception e) {
        }

        File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

        RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

        RestAssured.given().headers(requestHeaders);
        ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Duplicate Messages Check for V9</b>");
        int hitcount = 0;

        for (int i = 1; i < 3; i++) {
            response = request.post();
            hitcount++;
        }
        System.out.println("HIT count  " + hitcount);

        if (hitcount == 2) {
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                System.out.println(statusCode);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(response.body().asString());

                JSONParser jsonParser = new JSONParser();
                try {
                    JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                    String AcceptanceResult = jsonObject.get("accepted").toString();

                    if ("true".contentEquals(AcceptanceResult)) {
                        String responseid = jsonObject.get("respid").toString();
                        System.out.println("Request is accepted");
                        ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                        ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                        System.out.println("Response Object  " + responseid);
                        TestBase.setcurrenttime();
                        Thread.sleep(6000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                        String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                        if (MISDATA.isEmpty()) {
                            ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                            Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                        }

                        System.out.println(MISDATA);
                        String dbstatus = MISDATA.get("statusdesc");
                        if (dbstatus.contentEquals("DUPLICATE MESSAGE FOUND")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");

                            //DLR
                            boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                            if (DLRresult) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                                JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                                ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                                boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                                if (dlrrecieved) {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                    Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                    if (DLRDATA.isEmpty()) {
                                        ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                        Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                    }
                                    ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                    ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                                } else {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                                }

                            }

                            ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                            //DLREND
                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } else if ("false".contentEquals(AcceptanceResult)) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                        Assert.fail("Request is not accepted");

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                        Assert.fail("Something is wrong");
                    }
                } catch (Exception e) {
                    System.out.println("Please check the live table...");
                    ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                }
            }
        }
    }

    @Test(priority = 3, enabled = false, dataProvider = "getV9SecondaryAccount", invocationCount = SetandGetGlobalVariable.count)
    public void Check_SecondaryAccount_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_SecondaryAccount</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the SecondaryAccount Case V9<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);
            Response response = request.post();
            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                System.out.println(statusCode);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if ("true".contentEquals(AcceptanceResult)) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");

                    // LISTNER LOG FETCH CODE
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "Dummy", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                        if (LISTNER98SERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                        }
                    }
                    //

                    //PROCESSOR LOG CHECK
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "Dummy", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 205 processor SERVER</b>");
                        }
                    }

                    //


                    //ORECHESTRATOR  LOG CHECK
                    if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "Dummy", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 206 orchestrator SERVER</b>");
                        }
                    }

                    //
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                    boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "Dummy", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    if (SMSCRESULT) {
                        JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                        ExtentBASETEST.extentReportsDemo("PASS", "Request " + responseid + " is successfully submitted to SMSC");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    }
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                } else if ("false".contentEquals(AcceptanceResult)) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("ERROR", e.toString());
            Assert.fail(e.toString());

        }
    }

    @Test(priority = 3, enabled = false, dataProvider = "getV9OptionalParam", invocationCount = SetandGetGlobalVariable.count)
    public void Check_OptionalParameters_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        String auth = "lopdlt1";
        String subauth = "lopdlt1";
        String brd = "lopdlt1_test";
        String subappid = "lopdlt1";
        String acc = "0";
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_Optional_Parameters_Check</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Optional Parameters Case V9<b>");
            TestJSONENCRYPTION("Optional_Parameters.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Optional Parameters Check for V1</b>");
            Response response = request.post();
            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                System.out.println(statusCode);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if ("true".contentEquals(AcceptanceResult)) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                    System.out.println("Response Object  " + responseid);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);

                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }
                    System.out.println(MISDATA);

                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Actual  optional parameters values from DB---> <br>auth : " + MISDATA.get("author") + ",<br> brd :" + MISDATA.get("broadcastname") + ",<br> subappid : " + MISDATA.get("subenterprisename") + ",  <br>subauth : " + MISDATA.get("subauthor") + ", <br> acc : " + MISDATA.get("acc_id") + "</b>");


                    if ((auth.contentEquals(MISDATA.get("author"))) && brd.contentEquals(MISDATA.get("broadcastname")) && subappid.contentEquals(MISDATA.get("subenterprisename")) && subauth.contentEquals(MISDATA.get("subauthor")) && acc.contentEquals(MISDATA.get("acc_id"))) {

                        ExtentBASETEST.extentReportsDemo("PASS", "<b>Actual  optional parameters values from DB is correctly matching with Expected and Request status is <b>" + MISDATA.get("statusdesc"));

                        //DLR
                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                        //DLREND

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Expected  optional parameters values AUTH= " + auth + "  brd= " + brd + " subappid=  " + subappid + " subaurthor =" + subauth + " acc =" + acc + "<br>" + "Actual  optional parameters values AUTH= " + MISDATA.get("author") + "  brd= " + MISDATA.get("broadcastname") + " subappid=  " + MISDATA.get("subenterprisename") + " subaurthor =" + MISDATA.get("subauthor") + " acc =" + MISDATA.get("acc_id"));
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>Actual  optional parameters values from DB is not  matching with Expected and Request status is <b> " + MISDATA.get("statusdesc"));


                    }

                } else if ("false".contentEquals(AcceptanceResult)) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("ERROR", e.toString());
            Assert.fail(e.toString());

        }
    }

    @Test(priority = 3, enabled = false, dataProvider = "getV9Shortening", invocationCount = SetandGetGlobalVariable.count)
    public void Check_Shortening_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String contenttype, String language) {
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_Shortening</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, TestMSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Shortening Case V9<b>");
            TestJSONENCRYPTION("Shortening.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();
            System.out.println("Respnsebody" + response.body().asString());

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();



                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    System.out.println("Request is accepted");
                    // LISTNER LOG FETCH CODE
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "DUMMY", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                        if (LISTNER98SERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                        }
                    }
                    //

                    //PROCESSOR LOG CHECK
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "DUMMY", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 205 processor SERVER</b>");
                        }
                    }

                    //


                    //ORECHESTRATOR  LOG CHECK
                    if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "DUMMY", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 206 orchestrator SERVER</b>");
                        }
                    }

                    //

                    TestBase.setcurrenttime();
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    boolean shortresult = SQLPOOL.checkshortstageDB(responseid, PushRecieverLivetablename, ShortstageLiveBeetablename);

                    if (shortresult) {
                        System.out.println("Shortening passed");
                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(500, responseid, PushRecieverLivetablename);


                        if (MISDATA.isEmpty()) {
                            ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                        } else {
                            ExtentBASETEST.extentReportsDemo("PASS", "SHORTENING PASSED");

                            ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA with shortening -->" + MISDATA.toString());
                        }

                        // String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), ob.GetProperty("commonloglocation207"),ob.GetProperty("rcvrlogfileName"));
                        //JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                        // ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        // ExtentBASETEST.extentReportsDemo("INFO", "LOG DETAILS-->" + responseString);
                        //ExtentBASETEST.extentReportsDemo("PASS", "SHORTENING PASSED");
                        //Assert.assertEquals(AcceptanceResult,shortresult,"shoret pass");
                        // Assert.assertTrue(shortresult, "Shortening passed");

//DLR


                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR

                    }else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "SHORTENING FAILED");
                        Assert.assertTrue(shortresult, "Shortening Failed");
                    }
                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());
        }
    }

    @Test(priority = 3, enabled = false, dataProvider = "getV9TemplateCONVERSION", invocationCount = SetandGetGlobalVariable.count)
    public void Check_Templateconversion_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String MSG, String alert, String selfID, String Intflag, String contenttype, String language, String contertedtext) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_Templateconversion</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(functionname, userid, passwd, AppID, from, to, MSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9");

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template Conversion Case V9<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();
            System.out.println("Respnsebody" + response.body().asString());
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();


                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Response Object  " + responseid);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                    TestBase.setcurrenttime();
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }
                    System.out.println("this is actual  msg  before conversion" + MSG);
                    ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg  before conversion <b>" + MSG + "</b>");

                    System.out.println("this is expected converted msg from Excel" + contertedtext);
                    ExtentBASETEST.extentReportsDemo("INFO", "this is expected converted msg from Excel <b>" + contertedtext + "</b>");

                    System.out.println("this is actual converted msg from live sql table" + MISDATA.get("messagetext"));
                    ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("messagetext") + "</b>");
                    try {
                        if (contertedtext.contentEquals(MISDATA.get("messagetext"))) {
                            ExtentBASETEST.extentReportsDemo("PASS", "<b>The msg conversion is successfull</b>");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "<b>The msg conversion is NOT successfull</b>");

                        }
                    } catch (NullPointerException e) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                    }


                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());
        }
    }

    @Test(priority = 3, enabled = false, dataProvider = "getV9OpenTemplate", invocationCount = SetandGetGlobalVariable.count)
    public void Check_OpenTemplate_V9(String functionname, String userid, String passwd, String AppID, String from, String to, String MSG, String alert, String selfID, String Intflag, String contenttype, String language, String dtm, String dpi, String tc) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_OpenTemplate</b>");

        String SCTYPE = "";
        double ctype = Double.parseDouble(contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(alert);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);
        TestBase.SETMSGTEXTANDCONTENTTYPE_Open_Template_V9(functionname, userid, passwd, AppID, from, to, MSG, AALERT, selfID, Intflag, SCTYPE, language, "text", "JSON_REPOSITORY_V9", dtm, dpi, tc);

        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Open Template  Case V9<b>");
            TestJSONENCRYPTION("OpenTemplate.json", "V9", "testdlt301291009", AppID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();
            System.out.println("Respnsebody" + response.body().asString());
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    System.out.println("Request is accepted");
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                    TestBase.setcurrenttime();
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "this is Expected tc -->  <b>" + tc + "</b>" + " dpi --> <b>" + dpi + "</b>" + "dtm --> <b>" + dtm + "</b>");

                    ExtentBASETEST.extentReportsDemo("INFO", "this is Actual --> tc from DB  --> <b>" + MISDATA.get("tempid_category") + "</b>" + " dpi from DB  --> <b>" + MISDATA.get("dlt_peid") + "</b>" + " dtm from DB  --><b>" + MISDATA.get("dlt_tempid") + "</b>");

                    String act_tc = MISDATA.get("tempid_category");
                    String act_dpi = MISDATA.get("dlt_peid");
                    String act_dtm = MISDATA.get("dlt_tempid");

                    if (tc.contentEquals(act_tc) && dpi.contentEquals(act_dpi) && dtm.contentEquals(act_dtm)) {
                        System.out.println("Message is passed with dtm dpi tc");
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The actual and expected  tc , dpi and dtm are matching</b>");
                    } else {
                        System.out.println("Message is not passed with dtm ,dpi & tc parameter");
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The actual and expected  tc , dpi and dtm are Not matching</b>");
                    }

                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            }
        } catch (Exception e) {
            System.out.println("Please check the live table...");
            ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
        }
    }

    @Test(priority = 3, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_DTMDPITC_V9() {
        String dtm = "565656";
        String dpi = "565666";
        String tc = "0";
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_DTMDPITC</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the DTM DPI TC  Case V9<b>");
            TestJSONENCRYPTION("DTMDTPTC.json", "V9", "testdlt301291009", "lopdlt1");

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();
            System.out.println("Respnsebody" + response.body().asString());
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    System.out.println("Request is accepted");
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                    TestBase.setcurrenttime();
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }
                    ExtentBASETEST.extentReportsDemo("INFO", "this is Expected tc -->  <b>" + tc + "</b>" + " dpi --> <b>" + dpi + "</b>" + "dtm --> <b>" + dtm + "</b>");

                    ExtentBASETEST.extentReportsDemo("INFO", "this is Actual --> tc from DB  --> <b>" + MISDATA.get("tempid_category") + "</b>" + " dpi from DB  --> <b>" + MISDATA.get("dlt_peid") + "</b>" + " dtm from DB  --><b>" + MISDATA.get("dlt_tempid") + "</b>");

                    String act_tc = MISDATA.get("tempid_category");
                    String act_dpi = MISDATA.get("dlt_peid");
                    String act_dtm = MISDATA.get("dlt_tempid");

                    if (tc.contentEquals(act_tc) && dpi.contentEquals(act_dpi) && dtm.contentEquals(act_dtm)) {
                        System.out.println("Message is passed with dtm dpi tc");
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The actual and expected  tc , dpi and dtm are matching</b>");
                    } else {
                        System.out.println("Message is not passed with dtm ,dpi & tc parameter");
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The actual and expected  tc , dpi and dtm are Not matching</b>");
                    }

                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            }
        } catch (Exception e) {
            System.out.println("Please check the live table...");
            ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
        }
    }

    @Test(priority = 3, enabled = true, dataProvider = "getV9SCOUNTTemplateData", invocationCount = SetandGetGlobalVariable.count)
    public void Check_SMSCOUNT_V9(String FunctionName, String UserID, String Passd, String APPID, String
            FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String
                                          Language, String smscount) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_CHECKSMSCOUNT</b>");
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        String SCTYPE = "";
        double ctype = Double.parseDouble(Contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(ALERT);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);


        double b = Double.parseDouble(smscount);
        int SMSCOUNTroundOff = (int) (Math.round(b * 100) / 100);
        System.out.println("Expected sms count is " + SMSCOUNTroundOff);

        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, AALERT, SELFID, INTFLAG, SCTYPE, Language, "text", "JSON_REPOSITORY_V9");


        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", APPID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");

                    // LISTNER LOG FETCH CODE
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                        if (LISTNER98SERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                        }
                    }
                    //

                    //PROCESSOR LOG CHECK
                    if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                        }
                    }

                    //


                    //ORECHESTRATOR  LOG CHECK
                    if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                        }
                    }

                    //
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));


                    if (SMSCRESULT) {
                        JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 207 router SERVER</b>");
                        ExtentBASETEST.extentReportsDemo("INFO", "<b> ROUTER COMPONENT COMPLETE REDIS JSON DETAILS--></b>" + jsonbody.toString());


                        TestBase.setcurrenttime();
                        Thread.sleep(6000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                        if (MISDATA.isEmpty()) {
                            ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                            Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                        }
                        System.out.println(MISDATA);
                        // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                        if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                            ExtentBASETEST.extentReportsDemo("PASS", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                        }
                    } else {

                        TestBase.setcurrenttime();
                        Thread.sleep(6000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {
                            System.out.println(MISDATA);
                            // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                            if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                                ExtentBASETEST.extentReportsDemo("PASS", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                            } else {
                                ExtentBASETEST.extentReportsDemo("FAIL", "For request " + responseid + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                            }
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                        }
                    }
                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");

                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @Test(dataProvider = "getSOIPDATA", priority = 1, enabled = false, invocationCount = 1)
    public void Check_SOIP_CASES_V9(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String ExpectedStatusdesc, String ExpectedSMSC) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_SOIP-> " + FunctionName + "</b>");
        try {
            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }


            TestBase.SETMSGTEXTANDCONTENTTYPE_V9(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, AALERT, SELFID, INTFLAG, SCTYPE, Language, "text", "JSON_REPOSITORY_V9");

            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", APPID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), true, MSG, ob.GetProperty("commonloglocation94"), ob.GetProperty("rcvrlogfileName"));
                    TestBase.setcurrenttime();
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);
                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }
                    String actualsmsc = MISDATA.get("smscname");
                    String actualstatusdesc = MISDATA.get("statusdesc");
                    if (actualsmsc.isEmpty()) {
                        actualsmsc = "BLK";
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                    try {
                        if ((ExpectedStatusdesc.contentEquals(actualstatusdesc)) && actualsmsc.contentEquals(ExpectedSMSC)) {
                            ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                        }
                    } catch (NullPointerException e) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                    }


                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }

    @Test(priority = 3, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_RCS_V9() {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_DTMDPITC</b>");
        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check RSC V9<b>");
            TestJSONENCRYPTION("/RCS/Case1.json", "V9", "testdlt301291009", "rcsdlt");

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();
            System.out.println("Respnsebody" + response.body().asString());
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();
                boolean DLRCHECK = false;
                String RCSRECIEVRTABLENAME = "";
                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    System.out.println("Request is accepted");
                    //RCS COMPONENT  LOG CHECK
                    if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                        Thread.sleep(10000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString );
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                        }
                    }

                    //

                    TestBase.setcurrenttime();
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                    RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                    String joinid="";

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    } else {
                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());

                        String submitstatus=MISDATA.get("statusdesc");
                        if(submitstatus.contentEquals("submitted"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                            DLRCHECK = true;
                            joinid=MISDATA.get("joinid");
                        }
                        else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                            Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                        }
                    }
                    Thread.sleep(10000);

                    if(DLRCHECK)
                    {
                        Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                        if (DLRDATA.isEmpty()) {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                        } else {
                            if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                            }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                            }
                            else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                            }


                            ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                        }

                    }


                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            }
        } catch (Exception e) {
            System.out.println("Please check the live table...");
            ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
        }
    }
    @DataProvider
    public Object[][] getSOIPDATA() {

        Object data[][] = ExcelUtils.getTestData("SOIP_TEST", 0, "TestData-V9.xlsx");

        return data;
    }

    @DataProvider
    public Object[][] getV9SCOUNTTemplateData() {
        Object data[][] = ExcelUtils.getTestData("V9SMSCOUNTCheck", 0, "TestData-V9.xlsx");
        return data;


    }

    @DataProvider
    public Object[][] getV9OpenTemplate() {
        Object data[][] = ExcelUtils.getTestData("V9JSONOPENTEMPLATE", 0, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9TemplateCONVERSION() {
        Object data[][] = ExcelUtils.getTestData("V9TEMPLATECONVERSTION", 0, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9Shortening() {
        Object data[][] = ExcelUtils.getTestData("V9SPECIFICDATA", 6, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9OptionalParam() {
        Object data[][] = ExcelUtils.getTestData("V9SPECIFICDATA", 12, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9SecondaryAccount() {
        Object data[][] = ExcelUtils.getTestData("V9SPECIFICDATA", 22, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9dataNegative() {
        Object data[][] = ExcelUtils.getTestData("V9dataNegative", 0, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9DuplicateMessage() {
        Object data[][] = ExcelUtils.getTestData("V9SPECIFICDATA", 23, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9InsufficientCredit() {
        Object data[][] = ExcelUtils.getTestData("V9SPECIFICDATA", 7, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9International() {
        Object data[][] = ExcelUtils.getTestData("V9SPECIFICDATA", 8, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9TemplateNotMatched() {
        Object data[][] = ExcelUtils.getTestData("V9SPECIFICDATA", 14, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9CLIYES() {
        Object data[][] = ExcelUtils.getTestData("V9SPECIFICDATA", 9, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getV9CLINO() {
        Object data[][] = ExcelUtils.getTestData("V9SPECIFICDATA", 10, "TestData-V9.xlsx");
        return data;
    }

    @DataProvider
    public Object[][] getCRMTestData() {
        Object data[][] = ExcelUtils.getTestData(sheetName, 4, "TestData-V9.xlsx");
        return data;
    }
    @Test(priority = 6, enabled= false, invocationCount = 1)
    public void Check_WA_V9() {
        ExtentBASETEST.STARTTEST(ob.GetProperty("QA_AWS_BASE_URI") + "<b>V9_WA_MIS</b>");
        try {
            // Specify the base URL to the RESTful web service
            TestJSONENCRYPTION("/WA/Case1.json", "V9", "testdlt301291009", "sinchsms");
            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));
            //  File jsonDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/JSON_REPOSITORY_V1/WA/Case1.json");


            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);
            RestAssured.given().headers(requestHeaders);
            Response response = request.post();

            int statusCode = response.getStatusCode();
            boolean DLRCHECK = false;
            String WARECIEVRTABLENAME = "";
            if (statusCode == 200) {
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();
                //String joinid = "";
                //String WADLRTABLENAME = "";


                if ("true".contentEquals(AcceptanceResult)) {
                    String responseid = jsonObject.get("respid").toString();

                    //WA ROUTER  LOG CHECK
                    if (ob.GetProperty("checkWAlog").contentEquals("true")) {
                        Thread.sleep(10000);
                        boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), false, "dummy", ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));
                        if (LISTNERPROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 207 WA ROUTER </b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username207WA"), ob.GetProperty("Password207WA"), ob.GetProperty("hostname207WA"), ob.GetProperty("commonloglocation207WA"), ob.GetProperty("WArcvrlogfileName"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 207 WA server log info--> </b>" + responseString);
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 207 WA SERVER</b>");
                        }
                    }

                    //

                    System.out.println("Request is accepted");

                    TestBase.setcurrenttime();
                    TestBase.setcurrenttime();
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String WADLRTABLENAME = Livetablename.get("WADLRTABLENAME");
                    WARECIEVRTABLENAME = Livetablename.get("WARECIEVERTABLENAME");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROM_WA_RECIEVERTABLE(500, responseid, WARECIEVRTABLENAME);
                    String joinid = "";


                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The WA MISDATA could not be pulled from DB ");
                    } else {
                        DLRCHECK = true;

                        ExtentBASETEST.extentReportsDemo("PASS", "WA_MISTABLEDATA-->" + MISDATA.toString());
                        joinid = MISDATA.get("joinid");

                    }


                    if (DLRCHECK) {

                        Map<String, String> DLRDATA = SQLPOOL.GETWADATAFROMDLRLIVETABLE(500, joinid, WADLRTABLENAME);


                        if (DLRDATA.isEmpty()) {

                            ExtentBASETEST.extentReportsDemo("INFO", " The WA DLRDATA could not be pulled from DB ");

                        } else {

                            if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read")) {

                                ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully recieved and the current status of WA message is  <b>SENT, DELIVERED, READ</b>");

                            } else if (DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {

                                ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully recieved and the current status of WA message is  <b>SENT, DELIVERED </b>");

                            } else if (DLRDATA.containsValue("sent") && !DLRDATA.containsValue("delivered") && !DLRDATA.containsValue("read")) {

                                ExtentBASETEST.extentReportsDemo("INFO", " The WA Webhook has been successfully recieved and the current status of WA message is  <b>SENT </b>");

                            }


                            ExtentBASETEST.extentReportsDemo("PASS", "WA_DLRDATA-->" + DLRDATA.toString());
                        }

                    }


                } else if ("false".contentEquals(AcceptanceResult)) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");

                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @Test(priority = 3, enabled = false, dataProvider = "getV9DARSData", invocationCount = SetandGetGlobalVariable.count)
    public void Check_DARS_V9(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,  String ExpectedSMSC) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("QA_AWS_BASE_URI") + " " + "<b>V9_DARS</b>");
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        String SCTYPE = "";
        double ctype = Double.parseDouble(Contenttype);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SCTYPE = String.valueOf(ictype);

        String AALERT = "";
        double ALERTtype = Double.parseDouble(ALERT);
        int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
        AALERT = String.valueOf(iALERTtype);




        TestBase.SETMSGTEXTANDCONTENTTYPE_V9(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, AALERT, SELFID, INTFLAG, SCTYPE, Language, "text", "JSON_REPOSITORY_V9");


        try {
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            TestJSONENCRYPTION("ALLMESSAGE.json", "V9", "testdlt301291009", APPID);

            File jsonDataInFile = new File(System.getProperty("user.dir") + "/" + ob.GetProperty("encrptedjsonpathV9"));

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("accepted").toString();

                if (AcceptanceResult.contentEquals("true")) {
                    String responseid = jsonObject.get("respid").toString();
                    System.out.println("Request is accepted");
                    System.out.println("Request is accepted");

                    System.out.println("Response Object  " + responseid);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                    TestBase.setcurrenttime();
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                    String actualsmsc = MISDATA.get("smscname");
                    if (actualsmsc == null) {
                        actualsmsc = "BLK";
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
                        Assert.fail("<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
                    }
                    if (actualsmsc.isEmpty()) {
                        actualsmsc = "BLK";
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                    try {
                        if (ExpectedSMSC.contentEquals(ExpectedSMSC)) {
                            ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> <font color=green> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b> </font>");
                            ExtentBASETEST.extentReportsDemo("INFO", "<font color=blue>The MIS data for the same is below --> <br> " + MISDATA + "</font>");

                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> <font color=red>Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b></font>");
                        }
                    } catch (NullPointerException e) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                    }


                } else if (AcceptanceResult.contentEquals("false")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");

                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getV9DARSData() {
        Object data[][] = ExcelUtils.getTestData("DARS", 0, "TestData-V9.xlsx");
        return data;


    }

}
