import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class V1_listener_Scheduling {

    Map<String, String> requestHeaders = new HashMap<>();
    String sheetName = "data";
    TestBase ob;

    // private static final int count = 5;
    @BeforeTest

    public void setHeader() {
        requestHeaders.put("content-type", "application/Json");

    }
    //test
    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
       // ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST TO API SCHEDULING FFEATURE</b></h5>");
        String env = ob.GetProperty("Environment");

        RestAssured.baseURI = ob.GetProperty("V1SCHEDULE_API");

    }

    @Test(priority = 1, enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void Check_SCheduling_V1() {

        ExtentBASETEST.STARTTEST("<b>API_SCHEDULING</b>");
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }

        TestBase.SETSCHEDULINGPARAMETERS(5, "text", "JSON_REPOSITORY_V1");
        Map <String, String> Livetablename = TestBase.Scheduling_calculateandsetlivetablename();

        String PushRecieverLivetablename=Livetablename.get("PUSHTABLENAME");
        String DLRLivetablename=Livetablename.get("DLRTABLENAME");
        System.out.println("Push reciever live table name is-->" + PushRecieverLivetablename);
        System.out.println("DLR live table name is-->" + DLRLivetablename);

        try {


            File jsonDataInFile = new File("src/main/resources/Util/JSON_REPOSITORY_V1/SCH.json");

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();
            System.out.println("Respnsebody" + response.body().asString());
            System.out.println("Respnsebodylength" + response.body().asString().length());
            if ((statusCode == 200) && (response.body().asString().length() > 4)) {
                ExtentBASETEST.extentReportsDemo("INFO","200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String responseid = response.body().asString();
                ExtentBASETEST.extentReportsDemo("INFO","ResponseID "+responseid+" Going to check Mysql to verify scheduling request recieved in DB");
                boolean result = SQLPOOL.CheckMysqlSCHEDULING_1(responseid);
                 if(result)
                 {
                     ExtentBASETEST.extentReportsDemo("PASS","Scheduling job has been successfully scheduled");
                 }
                 else
                 {
                     ExtentBASETEST.extentReportsDemo("FAIL","Scheduling job NOT scheduled");
                 }
                Assert.assertTrue(result, "Scheduling did not happen in DB");
                ExtentBASETEST.extentReportsDemo("INFO","System is now going to wait for 5 min till the scheduled time");
                System.out.println("Now sleeping for 5 min");
                Thread.sleep(429000);
                //commented the reciever table checking part for some time as with reciever table I am facing some intermittant issues
                System.out.println("Now wokeup and going to check Push Reciever....");
                ExtentBASETEST.extentReportsDemo("INFO","Now wokeup and going to check Push Reciever Live table....");
                boolean Recieverresult = SQLPOOL.CheckMysqlPUSHRECIEVERTABLE(responseid, PushRecieverLivetablename);

                if(Recieverresult)
                {
                    ExtentBASETEST.extentReportsDemo("PASS","Reciever recieved MSG successfully on the scheduled time.");

                }
                else
                {
                    ExtentBASETEST.extentReportsDemo("FAIL","Reciever did not recieve MSG OR Was not successfully sent to SMSC. For more details please check the Reciever logs..");
                }
                Assert.assertTrue(Recieverresult, "Reciever did not recieve MSG OR Was not successfully sent to SMSC. For more details please check the Reciever logs..");

                System.out.println("Now wokeup and going to check DLR table...."+DLRLivetablename);

                ExtentBASETEST.extentReportsDemo("INFO","Going to check DLR Live table....");

                boolean DLRresult = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);

                if(DLRresult)
                {
                    ExtentBASETEST.extentReportsDemo("PASS","DLR  recieved MSG successfully on the scheduled time.");
                }
                else
                {
                    ExtentBASETEST.extentReportsDemo("FAIL","DLR did not recieve MSG . For more details please check the DLR logs..\"");
                }
                Assert.assertTrue(DLRresult, "DLR did not recieve MSG . For more details please check the DLR logs..");


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL","Scheduling Error code recieved");
                Assert.fail("Scheduling Error code recieved");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL",e.toString());
            Assert.fail(e.toString());

        }
    }
}