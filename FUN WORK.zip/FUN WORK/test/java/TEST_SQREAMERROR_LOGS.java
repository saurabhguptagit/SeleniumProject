import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;

public class TEST_SQREAMERROR_LOGS extends JSONENCYPTER {

    //test
    @Test(priority = 0, enabled = true)
    public void CHECK_SQREAMERROR_LOGS() {
        ExtentBASETEST.STARTTEST("<b>Check SQREAM LOG</b>");
        try {
            String responsestring1 = LinuxLogReader.CHECKSQREAMLOG("pushlive_push_receiver", "27-4-2025");

            String responsestring2 = LinuxLogReader.CHECKSQREAMLOG("pushlive_rcs_receiver", "27-4-2025");

            String responsestring3 = LinuxLogReader.CHECKSQREAMLOG("pushlive_whatsapp_receiver", "27-4-2025");
            checksqreamlog(responsestring1, "push");
            checksqreamlog(responsestring2, "RCS");
            checksqreamlog(responsestring3, "WHATSAPP");


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            Assert.fail(e.toString());

        }
    }

    public void checksqreamlog(String responseString, String channel) {
        System.out.println("hello");
        System.out.println(responseString);
        if (responseString.contains("No such file or directory") || responseString.isEmpty()) {
            ExtentBASETEST.extentReportsDemo("ERROR", "There is no file present in the directory for <b>" + channel + "</b>");
        } else {
            String arr[] = responseString.split("\n");
            Boolean sqreamerror = false;
            ArrayList errorfileindex = new ArrayList();

            for (int i = 0; i < arr.length; i++) {

                String filesize = arr[i].substring(27, 28);
                if (!filesize.contentEquals("0")) {
                    sqreamerror = true;
                    errorfileindex.add(arr[i]);
                }

            }

            String ar[] = responseString.split("\n");

            if (sqreamerror) {


                ExtentBASETEST.extentReportsDemo("FAIL", "<h2><b> There is an error in " + channel + "  in Sqream .Check below list </b><h2>");

                for (int j = 0; j < errorfileindex.size(); j++) {
                    ExtentBASETEST.extentReportsDemo("INFO", errorfileindex.get(j).toString());
                }


            } else {
                ExtentBASETEST.extentReportsDemo("PASS", "<h2><b> There is NO error in Sqream file for " + channel + " </b></h2> ");
            }
        }

    }

}