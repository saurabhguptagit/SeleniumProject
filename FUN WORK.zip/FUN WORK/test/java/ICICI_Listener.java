import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class ICICI_Listener {
    Response response;
    Map<String, String> requestHeaders = new HashMap<>();

    Map<String, String> ErrorcodesMAP = new HashMap<>();
    String sheetName = "data";
    TestBase ob;

    //test
    @BeforeTest

    public void setHeader() {
        requestHeaders.put("content-type", "application/xml");


    }

    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
        // ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST FOR XMLLanguageAPI LISTNERS</b></h5>");
        String env = ob.GetProperty("Environment");
        if (env.contentEquals("QA_AWS")) {
            RestAssured.baseURI = ob.GetProperty("BASEURI_ICICI_Listener");

        } else if (env.contentEquals("QA_142_Direct")) {
            RestAssured.baseURI = ob.GetProperty("BASEURI_ICICI_Listener");
        } else {
            throw new Exception("Envioenment name in Property is not valid");
        }

    }


    @Test(priority = 2,    enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLTemplatedata")
    public void ACheck_Templates_ICICIBroadcastListener_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("<b>ICICIBroadcastListener_TEMPLATEMATCHING--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_ICICI_Listener") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("ICICIRes.responseID");
                System.out.println(response_id);
                Thread.sleep(2000);

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK

                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");

                    }

                }


                //


                //ORECHESTRATOR  LOG CHECK

                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");

                    }

                }


                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + response_id + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(2000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);
                    System.out.println(MISDATA);
                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getXMLTemplatedata() {
        Object data[][] = ExcelUtils.getTestData("Templatecases", 6, "TestData_ICICI_API_LISTENER.xlsx");
        return data;
    }

    @Test(priority = 2,    enabled = true, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSMSCOUNTdata")
    public void Check_SMSCOUNT_ICICIBroadcastListener_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String smscount) {
        ExtentBASETEST.STARTTEST("<b>ICICIBroadcastListener_SMSCOUNT MATCHING--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_ICICI_Listener") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the SMSCOUNT matching<b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }
            double b = Double.parseDouble(smscount);
            int SMSCOUNTroundOff = (int) (Math.round(b * 100) / 100);
            System.out.println("Expected sms count is " + SMSCOUNTroundOff);


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");
                System.out.println(response_id);
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK

                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");

                    }

                }


                //


                //ORECHESTRATOR  LOG CHECK

                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");

                    }

                }


                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);
                    System.out.println(MISDATA);
                    // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                    if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                                ExtentBASETEST.extentReportsDemo("PASS", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                            } else {
                                ExtentBASETEST.extentReportsDemo("FAIL", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                            }
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");

                            Thread.sleep(Retry_Waiting_period);

                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }


                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSMSCOUNTdata() {
        Object data[][] = ExcelUtils.getTestData("SMSCOUNT", 0, "TestData_ICICI_API_LISTENER.xlsx");
        return data;
    }

    @Test(priority = 2,    enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforInternational")
    public void International_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICIinternational.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICIinternational.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the International Feature <b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");

                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");


                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK

                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");

                    }

                }


                //


                //ORECHESTRATOR  LOG CHECK

                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");

                    }

                }


                //
                JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), false, "DUMMY", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                try {
                    if (jsonbody.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("ERROR ", "The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                } catch (Exception e) {

                    ExtentBASETEST.extentReportsDemo("ERROR ", e.toString());

                }

                String smsc = String.valueOf(jsonbody.get("sn"));
                if (smsc.contains("-inter")) {

                    ExtentBASETEST.extentReportsDemo("PASS", "Request " + response_id + " is successfully submitted to SMSC & smsc selected is " + smsc);


                } else if (smsc.contains("NOT SUBMITTED TO SMSC")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + response_id + " Request has not been submitted to SMSC");
                    Assert.assertTrue(false, "FOR Request " + response_id + " SMSC is not matched for international request---> " + smsc);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + response_id + " SMSC is not matched for international request---> " + smsc);
                    Assert.assertTrue(false, "FOR Request " + response_id + " SMSC is not matched for international request--->" + smsc);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforInternational() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 8, "TestData_ICICI_API_LISTENER.xlsx");

        return data;
    }

    @Test(priority = 2,    enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSecondaryAccount")
    public void Check_Secondary_Account_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>ICICIBroadcastListener--> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");


            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Secondary Account Feature<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");

                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK

                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");

                    }

                }


                //


                //ORECHESTRATOR  LOG CHECK

                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");

                    }

                }
                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + response_id + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(5000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                    System.out.println(MISDATA);
                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getSecondaryAccount() {
        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 22, "TestData_ICICI_API_LISTENER.xlsx");
        return data;
    }

    @Test(priority = 2,   enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforDUPLICATEMSG")
    public void Check_Duplicate_Message_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>ICICIBroadcastListener_Check_Duplicate_Message--> " + FunctionName + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Duplicate Message Feature <b>");
            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                response = request.post();
                hitcount++;
            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {

                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);

                Response response = request.post();
                if (FunctionName.contains("blank_language")) {
                    XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
                }
                System.out.println("Request Object  " + request);
                System.out.println("Status code  " + statusCode);
                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    System.out.println(statusCode);
                    System.out.println(response.body().asString());
                    String temp = response.body().asString();
                    XmlPath xmlPath = new XmlPath(temp);
                    // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                    String response_id = xmlPath.get("ICICIRes.responseID");

                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + response_id + "</b>");

                    TestBase.setcurrenttime();
                    Thread.sleep(3000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(6000, response_id, PushRecieverLivetablename);
                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }

                    String dbstatus = MISDATA.get("statusdesc");


                    try {
                        if (dbstatus.contentEquals("DUPLICATE MESSAGE FOUND")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");

                            //DLR
                            boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                            if (DLRresult) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                                JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                                ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                                boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                                if (dlrrecieved) {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                    Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                                    if (DLRDATA.isEmpty()) {
                                        ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                        Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                    }
                                    ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                    ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                                } else {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                                }

                            }

                            ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                            //DLREND

                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } catch (Exception e) {
                        System.out.println("Please check the live table...");
                        ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                    }


                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");

                }

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforDUPLICATEMSG() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 23, "TestData_ICICI_API_LISTENER.xlsx");
        return data;
    }


    @Test(dataProvider = "getXmlLangaugeAPIListenerforTilta", priority = 1,    enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void SPECIALCHAR_TILTA_HANDLING__ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>ICICIBroadcastListener--> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);
            RestAssured.given().headers(this.requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Tilta handling  <b>");
            Response response = (Response) request.post();
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);

                Thread.sleep(6000);
                TestBase.setcurrenttime();


                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK

                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");

                    }

                }


                //


                //ORECHESTRATOR  LOG CHECK

                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");

                    }

                }
                //

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);
                System.out.println(MISDATA);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());

                String actualmsg = ob.GetProperty("SPECIALCHAR_TILTA_TEXT");

                String newLineExpectedmsg = actualmsg.replace('~', '\n');

                String newLineActualmsg = MISDATA.get("messagetext");
                if (newLineExpectedmsg.contentEquals(newLineActualmsg)) {
                    String aar[] = newLineActualmsg.split("\n");

                    // ExtentBASETEST.extentReportsDemo("INFO", "Please see Replaced text with new line ---><b>" + Arrays.deepToString(aar) + "</b>");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Text with ~ char ---><b>" + actualmsg + "</b>");
                    ExtentBASETEST.extentReportsDemo("PASS", " <b>The ~  is successfully  converted into new line charracter </b>");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The ~ in the Actual message " + newLineActualmsg + " is not converted into new line charracter ....Please see Expected text --->" + newLineExpectedmsg);

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }
        } catch (Exception var25) {
            ExtentBASETEST.extentReportsDemo("FAIL", var25.toString());
            Assert.fail(var25.toString());
        }

    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforTilta() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 5, "TestData_ICICI_API_LISTENER.xlsx");

        return data;
    }

    @Test(dataProvider = "ICICIBroadcastListenerforINVALIDMESSAGE", priority = 1,    enabled = false, invocationCount = 1)
    public void Check_INVALID_MESSAGE_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {

        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>getXmlLangaugeAPIListenerforINVALIDMESSAGE--> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);
            RestAssured.given().headers(this.requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Tilta handling  <b>");
            Response response = (Response) request.post();

            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK

                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");

                    }

                }


                //


                //ORECHESTRATOR  LOG CHECK

                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");

                    }

                }
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + response_id + "  " + MISDATA.toString());
                try {
                    if ("INVALID MESSAGE".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID msg check is successfull</b>");

                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID msg check NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }

    @DataProvider
    public Object[][] ICICIBroadcastListenerforINVALIDMESSAGE() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 11, "TestData_ICICI_API_LISTENER.xlsx");

        return data;

    }

    @Test(priority = 2,    enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getdatafordefaultsender")
    public void DEFAULTSENDER_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String Expected_sender) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>ICICIBroadcastListener --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the DEFAULT SENDER<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");

                // String response_id = temp;
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK

                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");

                    }

                }


                //


                //ORECHESTRATOR  LOG CHECK

                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");

                    }

                }
                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    // String actualsender=jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (Expected_sender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + response_id + "  Recieved sender is " + recievedsender + "  matching with expected sender " + Expected_sender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + response_id + "   Recieved sender is " + recievedsender + " NOT matching with expected sender " + Expected_sender);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + response_id + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + response_id + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getdatafordefaultsender() {
        Object data[][] = ExcelUtils.getTestData("DEFAULT_SENDER_TEST", 0, "TestData_ICICI_API_LISTENER.xlsx");
        return data;
    }

    @Test(priority = 2,    enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSOIPDATA")
    public void Check_SOIP_CASES_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String ExpectedStatusdesc, String ExpectedSMSC) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>ICICIBroadcastListener --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the DEFAULT SENDER<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");
                Thread.sleep(2000);
                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                String actualsmsc = MISDATA.get("smscname");
                String actualstatusdesc = MISDATA.get("statusdesc");
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if ((ExpectedStatusdesc.contentEquals(actualstatusdesc)) && actualsmsc.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getSOIPDATA() {

        Object data[][] = ExcelUtils.getTestData("SOIP_TEST", 0, "TestData_XMLSMSListener.xlsx");

        return data;
    }

    @Test(priority = 2,   enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSPECIFICROWforTemplateCONVERSION")
    public void Check_Templateconversion_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String contertedtext) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>ICICIBroadcastListener --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the TEMPLATECONVERSTION<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");
                Thread.sleep(2000);

                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + response_id + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, response_id, PushRecieverLivetablename);

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                System.out.println("this is actual  msg  before conversion" + MSG);
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg  before conversion <b>" + MSG + "</b>");

                System.out.println("this is expected converted msg from Excel" + contertedtext);
                ExtentBASETEST.extentReportsDemo("INFO", "this is expected converted msg from Excel <b>" + contertedtext + "</b>");

                System.out.println("this is actual converted msg from live sql table" + MISDATA.get("messagetext"));
                ExtentBASETEST.extentReportsDemo("INFO", "this is actual converted msg from live sql table <b>" + MISDATA.get("messagetext") + "</b>");
                try {
                    if (contertedtext.contentEquals(MISDATA.get("messagetext"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The msg conversion is successfull</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The msg conversion is NOT successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getSPECIFICROWforTemplateCONVERSION() {

        Object data[][] = ExcelUtils.getTestData("TEMPLATECONVERSTION", 0, "TestData_ICICI_API_LISTENER.xlsx");

        return data;
    }

    @Test(priority = 2,   enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSPECIFICROWforshortening")
    public void Check_SHORTENING_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>ICICIBroadcastListener --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");
            XML_OPERATIONS.ADD_NODE("shorten", "1", "ICICI.xml");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the TEMPLATECONVERSTION<b>");
            Response response = request.post();

            XML_OPERATIONS.REMOVE_NODE("shorten", "ICICI.xml");
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");

                System.out.println("Response Object  " + response_id);
                Thread.sleep(2000);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + response_id);


                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);


                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                boolean shortresult = SQLPOOL.checkshortstageDB(response_id, PushRecieverLivetablename, ShortstageLiveBeetablename);

                if (shortresult) {
                    System.out.println("Shortening passed");
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), false, "DUMMY", ob.GetProperty("commonloglocation205"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    ExtentBASETEST.extentReportsDemo("PASS", "SHORTENING PASSED");
                    Assert.assertTrue(shortresult, "Shortening passed");
                    //DLR

                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                    //ENDDLR
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "SHORTENING FAILED");
                    Assert.assertTrue(shortresult, "Shortening Failed");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getSPECIFICROWforshortening() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 6, "TestData_ICICI_API_LISTENER.xlsx");

        return data;
    }

    @Test(priority = 2,    enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSPECIFICROWforinsufficentcredit")
    public void INSUFFICIENT_CREDIT_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>ICICIBroadcastListener --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Insufficent credit test<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                boolean DLRCHECKFLAG = false;
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");

                Thread.sleep(2000);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 98 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 98 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 98 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK

                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {

                    Thread.sleep(2000);

                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, "TestMSG", ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                    if (LISTNERPROCESSORSERVERRESULT) {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));


                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);

                    } else {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");

                    }

                }


                //

                //
                boolean result = LinuxLogReader.CheckPrepaidbalance(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), false, "DUMMY", ob.GetProperty("commonloglocation205"), ob.GetProperty("rcvrlogfileName"));

                if (result) {
                    DLRCHECKFLAG = true;
                    ExtentBASETEST.extentReportsDemo("PASS", FunctionName + " PASSED for " + response_id);

                } else {

                    ExtentBASETEST.extentReportsDemo("FAIL", FunctionName + " FAILED for " + response_id);


                }
                if (DLRCHECKFLAG) {
                    TestBase.setcurrenttime();
                    Thread.sleep(1000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider

    public Object[][] getSPECIFICROWforinsufficentcredit() {

        Object data[][] = ExcelUtils.getTestData("INSUFFICIENT_CREDIT", 0, "TestData_XMLSMSListener.xlsx");
        return data;
    }


    @Test(priority = 2,    enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforCLIYES")
    public void CLIYES_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_XMLSMSListener") + " " + "<b>ICICIBroadcastListener --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the OPENCLI YES<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                boolean DLRCHECKFLAG = false;
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String responseid = xmlPath.get("ICICIRes.responseID");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //


                Thread.sleep(2000);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                Thread.sleep(2000);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + responseid);

                    }

                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforCLIYES() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 9, "TestData_ICICI_API_LISTENER.xlsx");

        return data;
    }





    @Test(priority = 1,   enabled = false, dataProvider = "getXMLdataNegative_AlertDND", invocationCount = SetandGetGlobalVariable.count)
    public void Check_Alert_DND_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String ExpecResponse, String language, String shortflag, String drflag, String msgid, String alertdnd) {
        if (!FunctionName.contentEquals("Test_DuplicateMessageID")) {
            ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_ICICI_Listener") + " " + "<b>ERRORCase_ICICIBroadcastListener_Check_Alert_DND_Cases " + FunctionName + "</b>");

            try {
                ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the Negative case-->" + FunctionName + "</b>");
                // Specify the base URL to the RESTful web service

                XML_OPERATIONS.ADD_NODE("alertdnd", alertdnd, "XmlLangaugeAPIListenerNegative_alertdnd.xml");
                XML_OPERATIONS.setXML(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, language, "ICICIBroadcastListenerNegative_alertdnd.xml", msgid);
                double Eresponse = Double.parseDouble(ExpecResponse);
                int Ecode = (int) (Math.round(Eresponse * 100) / 100);
                String ExpecetdNResponse = String.valueOf(Ecode);

                File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICIBroadcastListenerNegative_alertdnd.xml");
                RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

                RestAssured.given().headers(requestHeaders);

                Response response = request.post();
                XML_OPERATIONS.REMOVE_NODE("alertdnd", "ICICIBroadcastListenerNegative_alertdnd.xml");
                if (UserID.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("userid", "defaultvalue", "ICICIBroadcastListenerNegative_alertdnd.xml");
                }
                if (Passd.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("pass", "defaultvalue", "ICICIBroadcastListenerNegative_alertdnd.xml");
                }

                if (APPID.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("appid", "defaultvalue", "ICICIBroadcastListenerNegative_alertdnd.xml");
                }

                if (Contenttype.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("content-type", "defaultvalue", "ICICIBroadcastListenerNegative_alertdnd.xml");
                }
                if (FROM.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("from", "defaultvalue", "ICICIBroadcastListenerNegative_alertdnd.xml");
                }
                if (ALERT.contentEquals("MISS")) {
                    XML_OPERATIONS.ADD_NODE("alert", "1", "ICICIBroadcastListenerNegative_alertdnd.xml");
                }

                if (FunctionName.contains("MESSAGEID_TAGMISS")) {
                    XML_OPERATIONS.ADD_NODE("msgid", "defaultvalue", "ICICIBroadcastListenerNegative_alertdnd.xml");
                }
                int statusCode = response.getStatusCode();

                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    System.out.println(statusCode);
                    System.out.println(response.body().asString());
                    String temp = response.body().asString();
                    XmlPath xmlPath = new XmlPath(temp);
                    // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                    String Errorcode = xmlPath.get("ICICIRes.responseID");
                    ;
                    // XmlPath xmlPath = new XmlPath(temp);
                    String errorcode = xmlPath.get("push.error.code");
                    if (Errorcode.contentEquals(ExpecetdNResponse)) {
                        System.out.println(FunctionName + " Passed");
                        ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Errorcode + " matched with Expected Response " + ExpecetdNResponse);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Errorcode + " did not match with Expected Response " + ExpecetdNResponse);

                        Assert.assertEquals(Errorcode, ExpecetdNResponse, "Response code not matched for " + FunctionName);

                        System.out.println("Actual response " + Errorcode + " matched with Expected Response " + ExpecetdNResponse);


                    }

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");
                }

            } catch (Exception e) {
                ExtentBASETEST.extentReportsDemo("INFO", e.toString());
                Assert.fail(e.toString());

            }
        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforALERTDND() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 24, "TestData_ICICI_API_LISTENER.xlsx");

        return data;
    }

    @Test(priority = 2,    enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforCLINO")
    public void CLINO_ICICIBroadcastListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_XMLSMSListener") + " " + "<b>ICICIBroadcastListener --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the OPENCLI YES<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                boolean DLRCHECKFLAG = false;
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String responseid = xmlPath.get("ICICIRes.responseID");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //


                Thread.sleep(2000);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                Thread.sleep(2000);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + responseid);

                    }

                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getXMLSPECIFICROWforCLINO() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 10, "TestData_ICICI_API_LISTENER.xlsx");

        return data;
    }


    @Test(priority = 2,    enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLDARSdata")
    public void Check_DARS_ICICIBroadcastListener_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String ExpectedSMSC) {
        ExtentBASETEST.STARTTEST("<b>ICICIBroadcastListener_DARS MATCHING--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_ICICI_Listener") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.setXML_ICICI(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "ICICI.xml", "BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/ICICI.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the SMSCOUNT matching<b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }



            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                // String response_id = xmlPath.get("ICICIRes.response_id") + "-1";
                String response_id = xmlPath.get("ICICIRes.responseID");
                System.out.println(response_id);
                Thread.sleep(2000);
                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, response_id, PushRecieverLivetablename);

                String actualsmsc = MISDATA.get("smscname");
                if (actualsmsc == null) {
                    actualsmsc = "BLK";
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
                    Assert.fail("<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
                }
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if (ExpectedSMSC.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> <font color=green> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b> </font>");
                        ExtentBASETEST.extentReportsDemo("INFO", "<font color=blue>The MIS data for the same is below --> <br> " + MISDATA + "</font>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> <font color=red>Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b></font>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getXMLDARSdata() {
        Object data[][] = ExcelUtils.getTestData("DARS", 6, "TestData_ICICI_API_LISTENER.xlsx");
        return data;
    }
}



