import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class TEST_SBI_BULK_JSON_listener {

    Map<String, String> requestHeaders = new HashMap<>();
    String sheetName = "data";
    TestBase ob;

    @BeforeTest
    public void setHeader() {
        requestHeaders.put("content-type", "application/Json");
    }

    @BeforeTest
    public void setBaseURI() throws Exception {
        ob = new TestBase();
        RestAssured.baseURI = ob.GetProperty("QA_SBI_BULK_BASE_URI");
    }

    @Test(priority = 3, enabled = true, dataProvider = "getSBIBULKTemplateData", invocationCount = 5)
    public void Check_TemplateMatching_SBI_BULK(String functionname, String username, String password, String feedid, String mobile, String messages, String jobname, String SHORT) {
        ExtentBASETEST.STARTTEST(ob.GetProperty("QA_SBI_BULK_BASE_URI") + "<b>SBI_BULK_TEMPLATEMATCHING--> " + functionname + "</b>");
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        String SHORTCTYPE = "";
        double ctype = Double.parseDouble(SHORT);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SHORTCTYPE = String.valueOf(ictype);

        TestBase.SETMSGTEXTANDCONTENTTYPE_SBIBULK(functionname, username, password, feedid, mobile, messages, jobname, SHORTCTYPE, "JSON_REPOSITORY_SBI_BULK");

        try {

            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching for BULK<b>");
            File jsonDataInFile = new File("src/main/resources/Util/JSON_REPOSITORY_SBI_BULK/ALLMESSAGE.json");

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();
            System.out.println("Response body: " + response.body().asString());

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response received");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("status").toString();
                boolean DLRCHECK = false;

                if (AcceptanceResult.contentEquals("success")) {
                    String responseid = jsonObject.get("req_id").toString();
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted");
                    System.out.println("Request is accepted");

                    // LISTENER LOG FETCH CODE
                    if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, messages, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                        if (LISTNER98SERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECEIVED ON 187 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listener SERVER</b>");
                        }
                    }

                    // PROCESSOR LOG FETCH CODE
                    if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean PROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, messages, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                        if (PROCESSORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECEIVED ON 205 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 server log info--> </b>" + responseString);
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 205 Processor SERVER</b>");
                        }
                    }

                    // ORCHESTRATOR LOG FETCH CODE
                    if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                        Thread.sleep(2000);
                        boolean ORCHESTRATORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, messages, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                        if (ORCHESTRATORSERVERRESULT) {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECEIVED ON 206 SERVER</b>");
                            String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                            ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 server log info--> </b>" + responseString);
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 206 Orchestrator SERVER</b>");
                        }
                    }

                    // DATABASE MIS TABLE LOOKUP
                    TestBase.setcurrenttime();
                    Map<String, String> Pushlivetablename = TestBase.Normal_calculateandsetlivetablename();
                    String MISLivetablename = Pushlivetablename.get("PUSHTABLENAME");
                    String DLRLivetablename = Pushlivetablename.get("DLRTABLENAME");

                    ExtentBASETEST.extentReportsDemo("INFO", "MIS Live table name is: " + MISLivetablename);
                    ExtentBASETEST.extentReportsDemo("INFO", "DLR Live table name is: " + DLRLivetablename);

                    try {
                        Thread.sleep(3000);
                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, MISLivetablename);

                        if (MISDATA.isEmpty()) {
                            ExtentBASETEST.extentReportsDemo("INFO", "The MIS DATA could not be pulled from DB");
                            Assert.assertEquals(false, true, "The MIS DATA could not be pulled from DB");
                        }
                        ExtentBASETEST.extentReportsDemo("INFO", MISDATA.toString());
                        ExtentBASETEST.extentReportsDemo("INFO", "MIS DB  is passed");
                    } catch (Exception e) {
                        ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with MIS fetch " + e);
                        System.out.println("There is some issue with MIS fetch " + e);
                    }

                    // DLR
                    if (DLRCHECK) {
                        boolean result = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + result);

                        if (result) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECEIVED IN LOG");
                            JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                            boolean dlrrecieved = false;
                            try {
                                dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            } catch (Exception e) {
                                ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                                System.out.println("There is some issue with DLR fetch " + e);
                            }
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECEIVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECEIVED in DB");
                            }
                        } else {
                            System.out.println("DLR NOT RECEIVED IN LOG GOING TO CHECK IN DB");
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECEIVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = false;
                            try {
                                dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            } catch (Exception e) {
                                ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                                System.out.println("There is some issue with DLR fetch " + e);
                            }

                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECEIVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }

                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECEIVED in DB");
                            }
                        }
                    }
                    ExtentBASETEST.extentReportsDemo("INFO", "DLR TEST EXECUTED");

                } else if (AcceptanceResult.contentEquals("fail")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());
        }
    }

    Response response;

    @DataProvider
    public Object[][] getSBI_BULKSCOUNTTemplateData() {
        Object data[][] = ExcelUtils.getTestData("SMSCOUNTCheck", 0, "TestData-SBI_BULK.xlsx");
        return data;
    }

    @Test(priority = 3, enabled = true, dataProvider = "getSBI_BULKSCOUNTTemplateData", invocationCount = 5)
    public void Check_SMSCOUNT_SBI_BULK(String functionname, String username, String password, String feedid, String mobile, String messages, String jobname, String SHORT, String smscount) {
        ExtentBASETEST.STARTTEST(ob.GetProperty("QA_SBI_BULK_BASE_URI") + "<b>SBI_BULK_CHECKSMSCOUNT</b>");
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        String SHORTCTYPE = "";
        double ctype = Double.parseDouble(SHORT);
        int ictype = (int) (Math.round(ctype * 100) / 100);
        SHORTCTYPE = String.valueOf(ictype);

        TestBase.SETMSGTEXTANDCONTENTTYPE_SBIBULK(functionname, username, password, feedid, mobile, messages, jobname, SHORTCTYPE, "JSON_REPOSITORY_SBI_BULK");

        try {

            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the SMS count for BULK<b>");
            File jsonDataInFile = new File("src/main/resources/Util/JSON_REPOSITORY_SBI_BULK/ALLMESSAGE.json");

            RequestSpecification request = RestAssured.given().contentType(ContentType.JSON).body(jsonDataInFile);

            RestAssured.given().headers(requestHeaders);

            Response response = request.post();

            int statusCode = response.getStatusCode();
            System.out.println("Response body: " + response.body().asString());

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response received");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(response.body().asString());
                String AcceptanceResult = jsonObject.get("status").toString();

                if (AcceptanceResult.contentEquals("success")) {
                    String responseid = jsonObject.get("req_id").toString();
                    ExtentBASETEST.extentReportsDemo("INFO", "Request is accepted for SMS count verification");
                    System.out.println("Request is accepted");

                    TestBase.setcurrenttime();
                    Map<String, String> Pushlivetablename = TestBase.Normal_calculateandsetlivetablename();
                    String MISLivetablename = Pushlivetablename.get("PUSHTABLENAME");

                    try {
                        Thread.sleep(3000);
                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, MISLivetablename);

                        if (MISDATA.isEmpty()) {
                            ExtentBASETEST.extentReportsDemo("INFO", "The MIS DATA could not be pulled from DB");
                            Assert.assertEquals(false, true, "The MIS DATA could not be pulled from DB");
                        }

                        String SMSCOUNTFromDB = MISDATA.get("smscount");
                        double SMSCOUNTroundOff = Double.parseDouble(SMSCOUNTFromDB);
                        int iSMSCOUNT = (int) (Math.round(SMSCOUNTroundOff * 100) / 100);
                        String SMSCOUNTFINALFromDB = String.valueOf(iSMSCOUNT);

                        double expectedSMSCount = Double.parseDouble(smscount);
                        int iexpectedSMSCOUNT = (int) (Math.round(expectedSMSCount * 100) / 100);
                        String expectedSMSCOUNTFINAL = String.valueOf(iexpectedSMSCOUNT);

                        ExtentBASETEST.extentReportsDemo("INFO", "Expected SMS Count: " + expectedSMSCOUNTFINAL);
                        ExtentBASETEST.extentReportsDemo("INFO", "Actual SMS Count from DB: " + SMSCOUNTFINALFromDB);

                        if (SMSCOUNTFINALFromDB.equals(expectedSMSCOUNTFINAL)) {
                            ExtentBASETEST.extentReportsDemo("PASS", "SMS Count matched successfully");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", "SMS Count does not match");
                            Assert.fail("SMS Count does not match. Expected: " + expectedSMSCOUNTFINAL + " But got: " + SMSCOUNTFINALFromDB);
                        }

                    } catch (Exception e) {
                        ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with MIS fetch " + e);
                        System.out.println("There is some issue with MIS fetch " + e);
                    }

                } else if (AcceptanceResult.contentEquals("fail")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Request is not accepted and response is " + jsonObject);
                    Assert.fail("Request is not accepted");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Something is wrong");
                    Assert.fail("Something is wrong");
                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());
        }
    }

    @DataProvider
    public Object[][] getSBIBULKTemplateData() {
        Object data[][] = ExcelUtils.getTestData("Templatecases", 0, "TestData-SBI_BULK.xlsx");
        return data;
    }

}

