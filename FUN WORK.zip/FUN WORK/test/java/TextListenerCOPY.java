import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Map;

public class TextListenerCOPY {
    TestBase ob;

    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
        //ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST FOR NTEXT LISTNERS</b></h5>");
        String env = ob.GetProperty("Environment");
        if (env.contentEquals("QA_AWS")) {
            RestAssured.baseURI = ob.GetProperty("QA_AWS_TEXT_BASE_URI");

        } else if (env.contentEquals("QA_142_Direct")) {
            RestAssured.baseURI = ob.GetProperty("QA_AWS_DIRECT_TEXT_BASE_URI");
        } else {
            throw new Exception("Envioenment name in Property is not valid");
        }

    }


   


    @Test(dataProvider = "getRCSTESTDATA", priority = 1,  enabled = true)
    public void CHECK_RCS_TEXTLISTNER(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language ,String SHORT) {

       // ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_NTEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
        Reporter.log("</br>Request URL-->"+ob.GetProperty("QA_AWS_NTEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");



        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double stype = Double.parseDouble(SHORT);
            int istype = (int) (Math.round(stype * 100) / 100);
            String shortening = String.valueOf(istype);



            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470
            Response response= null;

            RequestSpecification request;

            if(shortening.contentEquals("3"))
            {
                request  = RestAssured.given()
                    .param("appid", APPID)
                    .param("userId", UserID)
                    .param("pass", Passd)
                    .param("from", FROM)
                    .param("to", "7906665842")
                    .param("text", MSG)
                    .param("alert", AALERT)
                    .param("selfid", SELFID)
                    .param("intflag", INTFLAG)
                    .param("contenttype", SCTYPE)
                    .param("language", Language);
            } else{

                request   = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7906665842")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .param("s",shortening);

            }


           // ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the RCS component </b>");
            Reporter.log("</br><b>Going to hit the API to check the RCS component </b>");


            if(FunctionName.contains("UNICODE"))
            {
                 response = request.get();
            }else {
                 response = request.post();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String RCSRECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
               // ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                Reporter.log("</br>200 Response recieved");

                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
               // ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);
                Reporter.log("</br>Now going to get  the reciever data from mis for response id " + responseid);
                System.out.println("Response Object  " + responseid);
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                       // ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        Reporter.log("</br><b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
if(shortening.contentEquals("1"))
{
    String check1="\"sto\":\"SHORT_URL_PICKER_INPUT_QUEUE\"";
    String check2="CommonUtility::sendToShortUrlRepository::appId -> "+APPID;
    if(responseString.contains(check1)&&responseString.contains(check2))
    {
       // ExtentBASETEST.extentReportsDemo("INFO", "<b> For the request shortening flag was 1 and request successfully sent to SHORT URL component of RCS and it has been verified in log   both strings are found in log</b>" +"First string "+ check1 +"Second string "+ check2);
        Reporter.log("</br><b> For the request shortening flag was 1 and request successfully sent to SHORT URL component of RCS and it has been verified in log   both strings are found in log</b>\" +\"First string \"+ check1 +\"Second string \"+ check2");
    }

    TestBase.setcurrenttime();
    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
    String RCSRecieverLivetablename = Livetablename.get("RCSRECIEVERTABLENAME");
    String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
    boolean shortresult = SQLPOOL.checkshortstageDB(responseid, RCSRecieverLivetablename, ShortstageLiveBeetablename);

    if (shortresult) {
        System.out.println("Shortening passed");
        Map<String, String> BEEMISDATA = SQLPOOL.GETMISDATA_FROM_SHORTSTAGE_RECIEVERTABLE( responseid, RCSRecieverLivetablename,ShortstageLiveBeetablename,"routing_channel");

      //  ExtentBASETEST.extentReportsDemo("INFO", " The Routing channel for RCS request in Short bee table  is  "+BEEMISDATA.get("routing_channel"));

        if (BEEMISDATA.isEmpty()) {
            //ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
            Reporter.log("</br>The MISDATA could not be pulled from DB");

        } else {
          //  ExtentBASETEST.extentReportsDemo("INFO", "SHORTENING PASSED");

            Reporter.log("</br>SHORTENING PASSED");


        }


    } else {
        //ExtentBASETEST.extentReportsDemo("INFO", "SHORTENING FAILED");
        Reporter.log("</br>SHORTENING FAILED");
    }
}

                       // ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString );
                        Reporter.log("</br><b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString);
                    } else {
                       // ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                        Reporter.log("</br><b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");


                    }
                }

                //



                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    //ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Reporter.log("</br> The MISDATA could not be pulled from DB ");
                } else {
                    if(MISDATA.get("templateid").isEmpty())
                    { //ExtentBASETEST.extentReportsDemo("FAIL", "Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());


                     Assert.assertTrue(false,"Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());

                    }else {
                        //ExtentBASETEST.extentReportsDemo("PASS", " <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());

                        Reporter.log("</br> <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());
                    }

                  //  ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    Reporter.log( "MISTABLEDATA-->" + MISDATA.toString());


                    String submitstatus=MISDATA.get("statusdesc");
                    if(submitstatus.contentEquals("submitted"))
                    {
                        //ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        Reporter.log( " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        DLRCHECK = true;
                        joinid=MISDATA.get("joinid");
                    }
                    else {
                        //ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                        Reporter.log("</br>THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        //ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                           // ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            //ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                           // ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        //ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                //ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            //ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }

    @Test(dataProvider = "getRCSTESTDATA", priority = 1,  enabled = true, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_TEXTLISTNER1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language ,String SHORT) {

        // ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("QA_AWS_NTEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");
        Reporter.log("</br>Request URL-->"+ob.GetProperty("QA_AWS_NTEXT_BASE_URI")+" "+"<b>TEXTLISTNER_RCS CHECK--> " + FunctionName + "</b>");



        try {

            String SCTYPE = "";
            double ctype = Double.parseDouble(Contenttype);
            int ictype = (int) (Math.round(ctype * 100) / 100);
            SCTYPE = String.valueOf(ictype);

            double stype = Double.parseDouble(SHORT);
            int istype = (int) (Math.round(stype * 100) / 100);
            String shortening = String.valueOf(istype);



            String AALERT = "";
            double ALERTtype = Double.parseDouble(ALERT);
            int iALERTtype = (int) (Math.round(ALERTtype * 100) / 100);
            AALERT = String.valueOf(iALERTtype);

            if (Language.contentEquals("BLK")) {
                Language = "";
            }
//9971498470
            Response response= null;

            RequestSpecification request;

            if(shortening.contentEquals("3"))
            {
                request  = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7906665842")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language);
            } else{

                request   = RestAssured.given()
                        .param("appid", APPID)
                        .param("userId", UserID)
                        .param("pass", Passd)
                        .param("from", FROM)
                        .param("to", "7906665842")
                        .param("text", MSG)
                        .param("alert", AALERT)
                        .param("selfid", SELFID)
                        .param("intflag", INTFLAG)
                        .param("contenttype", SCTYPE)
                        .param("language", Language)
                        .param("s",shortening);

            }


            // ExtentBASETEST.extentReportsDemo("INFO", "<b>Going to hit the API to check the RCS component </b>");
            Reporter.log("</br><b>Going to hit the API to check the RCS component </b>");


            if(FunctionName.contains("UNICODE"))
            {
                response = request.get();
            }else {
                response = request.post();
            }
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            boolean DLRCHECK = false;
            String RCSRECIEVRTABLENAME = "";
            //System.out.println("Function name is "+FunctionName);

            if (statusCode == 200) {
                // ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                Reporter.log("</br>200 Response recieved");

                String responseid = response.asString().replaceAll("[\\n\\t ]", "");
                // ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);
                Reporter.log("</br>Now going to get  the reciever data from mis for response id " + responseid);
                System.out.println("Response Object  " + responseid);
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(10000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        // ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        Reporter.log("</br><b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");

                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                        if(shortening.contentEquals("1"))
                        {
                            String check1="\"sto\":\"SHORT_URL_PICKER_INPUT_QUEUE\"";
                            String check2="CommonUtility::sendToShortUrlRepository::appId -> "+APPID;
                            if(responseString.contains(check1)&&responseString.contains(check2))
                            {
                                // ExtentBASETEST.extentReportsDemo("INFO", "<b> For the request shortening flag was 1 and request successfully sent to SHORT URL component of RCS and it has been verified in log   both strings are found in log</b>" +"First string "+ check1 +"Second string "+ check2);
                                Reporter.log("</br><b> For the request shortening flag was 1 and request successfully sent to SHORT URL component of RCS and it has been verified in log   both strings are found in log</b>\" +\"First string \"+ check1 +\"Second string \"+ check2");
                            }

                            TestBase.setcurrenttime();
                            Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                            String RCSRecieverLivetablename = Livetablename.get("RCSRECIEVERTABLENAME");
                            String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
                            String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                            boolean shortresult = SQLPOOL.checkshortstageDB(responseid, RCSRecieverLivetablename, ShortstageLiveBeetablename);

                            if (shortresult) {
                                System.out.println("Shortening passed");
                                Map<String, String> BEEMISDATA = SQLPOOL.GETMISDATA_FROM_SHORTSTAGE_RECIEVERTABLE( responseid, RCSRecieverLivetablename,ShortstageLiveBeetablename,"routing_channel");

                                //  ExtentBASETEST.extentReportsDemo("INFO", " The Routing channel for RCS request in Short bee table  is  "+BEEMISDATA.get("routing_channel"));

                                if (BEEMISDATA.isEmpty()) {
                                    //ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                                    Reporter.log("</br>The MISDATA could not be pulled from DB");

                                } else {
                                    //  ExtentBASETEST.extentReportsDemo("INFO", "SHORTENING PASSED");

                                    Reporter.log("</br>SHORTENING PASSED");


                                }


                            } else {
                                //ExtentBASETEST.extentReportsDemo("INFO", "SHORTENING FAILED");
                                Reporter.log("</br>SHORTENING FAILED");
                            }
                        }

                        // ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString );
                        Reporter.log("</br><b> below is the 85 RCS COMPONENT  log info--> </b>"+responseString);
                    } else {
                        // ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                        Reporter.log("</br><b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");


                    }
                }

                //



                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    //ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Reporter.log("</br> The MISDATA could not be pulled from DB ");
                } else {
                    if(MISDATA.get("templateid").isEmpty())
                    { //ExtentBASETEST.extentReportsDemo("FAIL", "Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());


                        Assert.assertTrue(false,"Kindly check the <b>RCS template name </b> that is being sent as empty in MISTABLEDATA-->" + MISDATA.toString());

                    }else {
                        //ExtentBASETEST.extentReportsDemo("PASS", " <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());

                        Reporter.log("</br> <b> RCS template name " +MISDATA.get("templateid")+" is also available </b> in MISTABLEDATA-->" + MISDATA.toString());
                    }

                    //  ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    Reporter.log( "MISTABLEDATA-->" + MISDATA.toString());


                    String submitstatus=MISDATA.get("statusdesc");
                    if(submitstatus.contentEquals("submitted"))
                    {
                        //ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        Reporter.log( " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                        DLRCHECK = true;
                        joinid=MISDATA.get("joinid");
                    }
                    else {
                        //ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+submitstatus);
                        Reporter.log("</br>THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is "+ submitstatus);

                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        //ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            // ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            //ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            // ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        //ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                //ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            //ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            //Assert.fail(e.toString());

        }


    }



    @DataProvider
    public Object[][] getTEXTSPECIFICROWforRCSCAPABILITY() {

        Object data[][] = ExcelUtils.getTestData("RCSCAPABILITY", 0, "TestData_NTEXT.xlsx");

        return data;
    }
    @DataProvider(parallel = true)
    public Object[][] getRCSTESTDATA() {

        Object data[][] = ExcelUtils.getTestData("RCS_TEST_DATA", 82, "TestData_NTEXT.xlsx");

        return data;
    }


    }










