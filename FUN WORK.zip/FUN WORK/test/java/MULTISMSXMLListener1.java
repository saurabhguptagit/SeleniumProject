import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class MULTISMSXMLListener1 {
    Response response;
    Map<String, String> requestHeaders = new HashMap<>();

    Map<String, String> ErrorcodesMAP = new HashMap<>();
    String sheetName = "data";
    TestBase ob;


    @BeforeTest

    public void setHeader() {
        requestHeaders.put("content-type", "application/xml");


    }

    @BeforeTest

    public void setBaseURI() throws Exception {
        ob = new TestBase();
        // ExtentBASETEST.extentReportsDemo("INFO","<h5><b>STARTING THE TEST FOR XMLLanguageAPI LISTNERS</b></h5>");
        String env = ob.GetProperty("Environment");

        RestAssured.baseURI = ob.GetProperty("BASEURI_MULTISMSXMLListener1");


    }


    @Test(priority = 2, enabled = false, dataProvider = "getXMLTemplatedata")
    public void Check_Templates_MULTISMSXMLListener1_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("<b>MULTISMSXMLListener1_Listener_TEMPLATEMATCHING--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            Response response = request.post();
            System.out.println(response);
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id");// + "-1";
                System.out.println(response_id);
                boolean DLRCHECK = false;
                String DLRLivetablename = "";
                Thread.sleep(2000);

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                        System.out.println(responseString);
                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username208"), ob.GetProperty("Password208"), ob.GetProperty("hostname208"), true, "TestMSG", ob.GetProperty("commonloglocation208"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 208 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205")
, ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 208 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  208 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, "TestMSG", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                System.out.println(SMSCRESULT);
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + response_id + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(2000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);
                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        DLRCHECK = true;

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    }

                    System.out.println(MISDATA);
                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                        DLRLivetablename = Livetablename.get("DLRTABLENAME");
                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            DLRCHECK = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }

                }
//DLR
                if (DLRCHECK) {
                    boolean result = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                    System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + result);

                    if (result) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    } else {
                        System.out.println("DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }

                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }

                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }


                    }
                }
                ExtentBASETEST.extentReportsDemo("INFO", "DLR TEST EXECUTED");

                //END

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
//            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getXMLTemplatedata() {
        Object data[][] = ExcelUtils.getTestData("Templatecases", 0, "TestData_MULTISMSXMLListener1.xlsx");
        return data;
    }

    @Test(priority = 2, enabled = true, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSMSCOUNTdata")
    public void Check_SMSCOUNT_MULTISMSXMLListener1_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String smscount) {
        ExtentBASETEST.STARTTEST("<b>MULTISMSXMLListener1_Listener_SMSCOUNT MATCHING--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the SMSCOUNT matching<b>");
            Response response = request.post();


            double b = Double.parseDouble(smscount);
            int SMSCOUNTroundOff = (int) (Math.round(b * 100) / 100);
            System.out.println("Expected sms count is " + SMSCOUNTroundOff);


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id");//+ "-1";
                System.out.println(response_id);
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), false, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 208 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205")
, ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 208 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  208 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, MSG, ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 207 router SERVER</b>");
                    ExtentBASETEST.extentReportsDemo("INFO", "<b> ROUTER COMPONENT COMPLETE REDIS JSON DETAILS--></b>" + jsonbody.toString());

                    TestBase.setcurrenttime();
                    Thread.sleep(6000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);

                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }
                    System.out.println(MISDATA);
                    // ExtentBASETEST.extentReportsDemo("PASS","MISTABLEDATA-->"+MISDATA.toString());
                    if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);

                        System.out.println(MISDATA);
                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            if (SMSCOUNTroundOff == (Integer.parseInt(MISDATA.get("smscount")))) {
                                ExtentBASETEST.extentReportsDemo("PASS", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which is matching with Expected SMS count-->" + SMSCOUNTroundOff);
                            } else {
                                ExtentBASETEST.extentReportsDemo("FAIL", "For request " + response_id + " Actual SMS count-->" + MISDATA.get("smscount") + " which DOES NOT  match with Expected SMS count-->" + SMSCOUNTroundOff);

                            }
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");

                            Thread.sleep(Retry_Waiting_period);

                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }


                }
            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }

        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSMSCOUNTdata() {
        Object data[][] = ExcelUtils.getTestData("SMSCOUNT", 0, "TestData_MULTISMSXMLListener1.xlsx");
        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void International_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 -->" + "</b>");
        try {
//            String MSG = "Test Implicit template";
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1_international.xml","BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1_international.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the International Feature <b>");
            Response response = request.post();

            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id"); //+ "-1";
                System.out.println(response_id);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username208"), ob.GetProperty("Password208"), ob.GetProperty("hostname208"), true, MSG, ob.GetProperty("commonloglocation208"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 208 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205")
, ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 208 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  208 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username142"), ob.GetProperty("Password142"), ob.GetProperty("hostname142"), true, MSG, ob.GetProperty("commonloglocation142"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 142 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username142"), ob.GetProperty("Password142"), ob.GetProperty("hostname142"), ob.GetProperty("commonloglocation142"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 142 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 142 orchestrator SERVER</b>");
                    }
                }

                //
                JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                try {
                    if (jsonbody.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("ERROR ", "The reason may be the request was not submitted to SMSC due to which REDIS JSON COULD NOT BE FOUND IN LOG");
                    }

                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                } catch (Exception e) {

                    ExtentBASETEST.extentReportsDemo("ERROR ", e.toString());

                }

                String smsc = String.valueOf(jsonbody.get("sn"));
                if (smsc.contains("-inter")) {

                    ExtentBASETEST.extentReportsDemo("PASS", "Request " + response_id + " is successfully submitted to SMSC & smsc selected is " + smsc);


                } else if (smsc.contains("NOT SUBMITTED TO SMSC")) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + response_id + " Request has not been submitted to SMSC");
                    Assert.assertTrue(false, "FOR Request " + response_id + " SMSC is not matched for international request---> " + smsc);
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "FOR Request " + response_id + " SMSC is not matched for international request---> " + smsc);
                    Assert.assertTrue(false, "FOR Request " + response_id + " SMSC is not matched for international request--->" + smsc);
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSecondaryAccount")
    public void Check_Secondary_Account_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");
            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.REMOVELANGUAGE_ATTRIBUTE();
            }
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Secondary Account Feature<b>");
            Response response = request.post();

            if (FunctionName.contains("blank_language")) {
                XML_OPERATIONS.ADDLANGUAGE_ATTRIBUTE();
            }


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id");//+ "-1";
                System.out.println(response_id);
                Thread.sleep(2000);
                boolean DLRCHECK = false;
                String DLRLivetablename = "";
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "TestMSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username208"), ob.GetProperty("Password208"), ob.GetProperty("hostname208"), true, "TestMSG", ob.GetProperty("commonloglocation208"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 208 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205")
, ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 208 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  208 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "TestMSG", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), true, "TestMSG", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(response_id, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());

                    ExtentBASETEST.extentReportsDemo("PASS", "Request" + response_id + " is successfully submitted to SMSC");
                    TestBase.setcurrenttime();
                    Thread.sleep(2000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    DLRLivetablename = Livetablename.get("DLRTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);
                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        DLRCHECK = true;

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                    }

                    System.out.println(MISDATA);
                    ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA-->" + MISDATA.toString());
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                        DLRLivetablename = Livetablename.get("DLRTABLENAME");
                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, response_id, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            DLRCHECK = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + response_id);

                    }

                }
//DLR
                if (DLRCHECK) {
                    boolean result = LinuxLogReader.CheckDLRLOGMESSAGE(response_id, response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                    System.out.println("---->THE RESPONSE OF DLR LOG MESSAGE CHECK IS  " + result);

                    if (result) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(response_id, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    } else {
                        System.out.println("DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = false;
                        try {
                            dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(response_id, DLRLivetablename);
                        } catch (Exception e) {
                            ExtentBASETEST.extentReportsDemo("INFO", "There is some issue with DLR fetch " + e);
                            System.out.println("There is some issue with DLR fetch " + e);
                        }

                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, response_id, DLRLivetablename);

                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }

                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }


                    }
                }
                ExtentBASETEST.extentReportsDemo("INFO", "DLR TEST EXECUTED");

                //END

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
//            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getSecondaryAccount() {
        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 22, "TestData_MULTISMSXMLListener1.xlsx");
        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_Duplicate_Message_MULTISMSXMLListener1() {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1_Check_Duplicate_Message--> " + "</b>");
        try {
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1_dup.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Duplicate Message Feature <b>");
            int hitcount = 0;

            for (int i = 1; i < 3; i++) {
                response = request.post();
                hitcount++;
            }

            System.out.println("HIT count  " + hitcount);

            if (hitcount == 2) {

                int statusCode = response.getStatusCode();

                System.out.println("Status code  " + statusCode);

                Response response = request.post();
                System.out.println("Request Object  " + request);
                System.out.println("Status code  " + statusCode);
                if (statusCode == 200) {
                    ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                    System.out.println(statusCode);
                    System.out.println(response.body().asString());
                    String temp = response.body().asString();

//                    String response_id = temp;
                    XmlPath xmlPath = new XmlPath(temp);
                    String responseid = xmlPath.get("push.response-id");
                    System.out.println(responseid);
                    //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                    ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                    TestBase.setcurrenttime();
                    Thread.sleep(3000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");

                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(6000, responseid, PushRecieverLivetablename);
                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                        Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                    }

                    String dbstatus = MISDATA.get("statusdesc");


                    try {
                        if (dbstatus.contentEquals("DUPLICATE MESSAGE FOUND")) {

                            ExtentBASETEST.extentReportsDemo("PASS", "The duplicate message check is passed and msg in DB is <b>" + dbstatus + "</b>");

                            //DLR
                            boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                            if (DLRresult) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                                JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                                ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                                boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                                if (dlrrecieved) {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                    Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);

                                    if (DLRDATA.isEmpty()) {
                                        ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                        Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                    }
                                    ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                    ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                                } else {
                                    ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                                }

                            }

                            ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                            //DLREND

                        } else {

                            ExtentBASETEST.extentReportsDemo("FAIL", "The duplicate message check is NOT passed and msg in DB is <b>" + dbstatus + "</b>");
                        }
                    } catch (Exception e) {
                        System.out.println("Please check the live table...");
                        ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                    }


                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                    Assert.fail("Status code is not success");

                }

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            System.out.println(e);

        }

    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforDUPLICATEMSG() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 13, "TestData_MULTISMSXMLListener1.xlsx");
        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void ALERTDNDERROR_MULTISMSXMLListener1() {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 InvalidDND case" + " " + "</b>");
        try {
            // Specify the base URL to the RESTful web service
//            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MultiSMSXMLListener1_InvalidDND.xml");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MultiSMSXMLListener1_InvalidDND.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Invalid Alert DND Error Test<b>");
            Response response = request.post();

            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String Errorcode= xmlPath.get("push.error.code");
                System.out.println(Errorcode);
                ExtentBASETEST.extentReportsDemo("INFO", "Now going to check the reciever log");

                if (Errorcode.contentEquals("-73")) {
                    System.out.println("InvalidDND case is " + " Passed");
                    ExtentBASETEST.extentReportsDemo("PASS", "Actual response " + Errorcode + " matched with Expected Response " + "-73");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "Actual response " + Errorcode + " did not match with Expected Response " + "-73");

                    Assert.assertEquals(Errorcode, "-73", "Response code not matched for InvalidDND");

                    System.out.println("Actual response " + Errorcode + " matched with Expected Response " + "-73");


                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforALERTDND() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 24, "TestData_MULTISMSXMLListener1.xlsx");

        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforInvalidMSG")
    public void INVALIDMESSAGE_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Invalid Message Error<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id");// + "-1";
                System.out.println(responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + responseid + "  " + MISDATA.toString());
                try {
                    if ("INVALID MESSAGE".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID msg check is successfull</b>");

                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID msg check NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforInvalidMSG() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 11, "TestData_MULTISMSXMLListener1.xlsx");

        return data;
    }
    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXmlLangaugeAPIListenerforTOblank")
    public void INVALID_MSISDN_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 --> " + FunctionName + "</b>");
        try {
            XML_OPERATIONS.ADD_ATTRIBUTE("msisdn", "", "MULTISMSXMLListener1.xml");
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Invalid MSISDN Error<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id");// + "-1";
                System.out.println(responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + responseid + "  " + MISDATA.toString());
                try {
                    if ("INVALID MSISDN".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID MSISDN check is successfull</b>");

                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID msg check NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforTOblank() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 17, "TestData_MULTISMSXMLListener1.xlsx");

        return data;

    }
    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_MSG_BLANK_MULTISMSXMLListener1() {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 --> "+"</b>");
        try {
            // Specify the base URL to the RESTful web service
//            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MultiSMSXMLListener1_InvalidMessage.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Invalid MESSAGE Error<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id");// + "-1";
                System.out.println(responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + responseid + "  " + MISDATA.toString());
                try {
                    if ("INVALID MESSAGE".contentEquals(MISDATA.get("statusdesc"))) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The INVALID msg check is successfull</b>");

                        //DLR

                        boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                        if (DLRresult) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                            JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                            ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                            boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                            if (dlrrecieved) {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                                Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                                if (DLRDATA.isEmpty()) {
                                    ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                    Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                                }
                                ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                                ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                            } else {
                                ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                            }

                        }

                        ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                        //ENDDLR
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The INVALID msg check NOT  successfull</b>");

                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }



    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXmlLangaugeAPIListenerforTilta")
    public void TILTAHANDLING_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the tilda Feature <b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

//                String response_id = temp;
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id");// + "-1";
                System.out.println(responseid);
                Thread.sleep(6000);
                TestBase.setcurrenttime();

                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                System.out.println(MISDATA);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA for response id " + responseid + "  " + MISDATA.toString());

                String actualmsg = ob.GetProperty("SPECIALCHAR_TILTA_TEXT");

                String newLineExpectedmsg = actualmsg.replace('~', '\n');

                String newLineActualmsg = MISDATA.get("messagetext");
                if (newLineExpectedmsg.contentEquals(newLineActualmsg)) {
                    String aar[] = newLineActualmsg.split("\n");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Replaced text with new line ---><b>" + Arrays.deepToString(aar) + "</b>");

                    ExtentBASETEST.extentReportsDemo("INFO", "Please see Text with ~ char ---><b>" + actualmsg + "</b>");
                    ExtentBASETEST.extentReportsDemo("PASS", " <b>The ~  is successfully  converted into new line charracter </b>");
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The ~ in the Actual message " + newLineActualmsg + " is not converted into new line charracter ....Please see Expected text --->" + newLineExpectedmsg);

                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @DataProvider
    public Object[][] getXmlLangaugeAPIListenerforTilta() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 5, "TestData_MULTISMSXMLListener1.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getdatafordefaultsender")
    public void DEFAULTSENDER_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String Expected_sender) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the DEFAULT SENDER<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

//                String response_id = temp;
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username208"), ob.GetProperty("Password208"), ob.GetProperty("hostname208"), true, MSG, ob.GetProperty("commonloglocation208"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 208 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205")
, ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 205 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }
                //
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"), ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    // String actualsender=jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (Expected_sender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Recieved sender is " + recievedsender + "  matching with expected sender " + Expected_sender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "   Recieved sender is " + recievedsender + " NOT matching with expected sender " + Expected_sender);

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());


        }

    }

    @DataProvider
    public Object[][] getdatafordefaultsender() {
        Object data[][] = ExcelUtils.getTestData("DEFAULT_SENDER_TEST", 0, "TestData_MULTISMSXMLListener1.xlsx");
        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSOIPDATA")
    public void Check_SOIP_CASES_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String ExpectedStatusdesc, String ExpectedSMSC) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>XmlLanguageAPIListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the DEFAULT SENDER<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

//                String response_id = temp;
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                Thread.sleep(2000);
                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB ");
                }
                String actualsmsc = MISDATA.get("smscname");
                String actualstatusdesc = MISDATA.get("statusdesc");
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if ((ExpectedStatusdesc.contentEquals(actualstatusdesc)) && actualsmsc.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + FunctionName + "</b> has been passed <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + FunctionName + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b> <br> Expected status  was <b>" + ExpectedStatusdesc + " </b> <br> Actual status is <b>" + actualstatusdesc + "</b>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getSOIPDATA() {

        Object data[][] = ExcelUtils.getTestData("SOIP_TEST", 0, "TestData_MULTISMSXMLListener1.xlsx");

        return data;
    }
    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void Check_SHORTENING_MULTISMSXMLListener1() {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 Shortening " + "</b>");
        try {
            // Specify the base URL to the RESTful web service
//            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1_short.xml", "BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1_short.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Short URL CONVERSTION<b>");
            Response response = request.post();

            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                System.out.println(statusCode);
//                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id");// + "-1";
                System.out.println(responseid);
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "DUMMY", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username208"), ob.GetProperty("Password208"), ob.GetProperty("hostname208"), true, "DUMMY", ob.GetProperty("commonloglocation208"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 208 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205")
, ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 208 processor server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 208 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, "DUMMY", ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 206 orchestrator SERVER</b>");
                    }
                }

                //

                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                ExtentBASETEST.extentReportsDemo("INFO", "Now going to get  the reciever data from mis for response id " + responseid);

                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);


                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");
                String ShortstageLiveBeetablename = Livetablename.get("SHORTSTAGE_BEE_TABLE");
                String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                boolean shortresult = SQLPOOL.checkshortstageDB(responseid, PushRecieverLivetablename, ShortstageLiveBeetablename);

                if (shortresult) {
                    System.out.println("Shortening passed");
                    Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(500, responseid, PushRecieverLivetablename);


                    if (MISDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The MISDATA could not be pulled from DB ");
                    } else {
                        ExtentBASETEST.extentReportsDemo("PASS", "SHORTENING PASSED");

                        ExtentBASETEST.extentReportsDemo("PASS", "MISTABLEDATA with shortening -->" + MISDATA.toString());
                    }


                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject DLRjsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + DLRjsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");

                    //ENDDLR
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "SHORTENING FAILED");
                    Assert.assertTrue(shortresult, "Shortening Failed");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }

    }


    @DataProvider
    public Object[][] getSPECIFICROWforshortening() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 6, "TestData_MULTISMSXMLListener1.xlsx");

        return data;
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getSPECIFICROWforinsufficentcredit")
    public void INSUFFICIENT_CREDIT_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Insufficent credit test<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                boolean DLRCHECKFLAG = false;
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id");
                System.out.println(responseid);
                Thread.sleep(2000);
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");

                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, "MSG", ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>" + responseString);
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 187 SERVER</b>");
                    }
                }
                //
                //PROCESSOR LOG CHECK
                boolean result = LinuxLogReader.CheckLOGERRORMESSAGE("Insufficient Credits", responseid, ob.GetProperty("Username208"), ob.GetProperty("Password208"), ob.GetProperty("hostname208"), false, "DUMMY", ob.GetProperty("commonloglocation208"), ob.GetProperty("PROCESSORLOGFILENAME"));
                if (result) {
                    DLRCHECKFLAG = true;
                    ExtentBASETEST.extentReportsDemo("PASS", "PREPAIDBALANCE  PASSED for " + responseid);

                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "PREPAIDBALANCE  FAILED for " + responseid);

                }


                if (DLRCHECKFLAG) {
                    TestBase.setcurrenttime();
                    Thread.sleep(1000);
                    Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                    String DLRLivetablename = Livetablename.get("DLRTABLENAME");
                    boolean DLRresult = LinuxLogReader.CheckDLRLOGMESSAGE(responseid, responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));

                    if (DLRresult) {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN LOG");
                        JSONObject jsonbody = LinuxLogReader.GETDLRJSONLOG(responseid, ob.GetProperty("Username94"), ob.GetProperty("Password94"), ob.GetProperty("hostname94"), false, "DUMMY", ob.GetProperty("dlrloglocation94"), ob.GetProperty("dlrlogfileName"));
                        ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());


                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED IN LOG GOING TO CHECK IN DB");
                        boolean dlrrecieved = SQLPOOL.CheckMysqlDLRTABLE(responseid, DLRLivetablename);
                        if (dlrrecieved) {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR RECIEVED IN DB");

                            Map<String, String> DLRDATA = SQLPOOL.GETMISDATAFROMDLRLIVETABLE(1000, responseid, DLRLivetablename);
                            if (DLRDATA.isEmpty()) {
                                ExtentBASETEST.extentReportsDemo("INFO", " The DLRDATA could not be pulled from DB ");
                                Assert.assertEquals(false, true, "The DLRDATA could not be pulled from DB ");
                            }
                            ExtentBASETEST.extentReportsDemo("INFO", DLRDATA.toString());
                            ExtentBASETEST.extentReportsDemo("INFO", " DLR db  is passed");
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "DLR NOT RECIEVED in DB");

                        }

                    }

                    ExtentBASETEST.extentReportsDemo("PASS", "DLR TEST EXECUTED");
                }

            } else {
                Assert.fail("Something is wrong");

            }}
            catch(Exception e){
                e.printStackTrace();
            }
        }
@DataProvider

    public Object[][] getSPECIFICROWforinsufficentcredit() {

        Object data[][] = ExcelUtils.getTestData("INSUFFICIENT_CREDIT", 0, "TestData_MULTISMSXMLListener1.xlsx");
        return data;
    }



    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforCLIYES")
    public void CLIYES_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_MULTISMSXMLListener1")+" "+"<b>MultiSMSXMLListner --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the OPENCLI YES<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id");   // + "-1";
                System.out.println(responseid);
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username208"), ob.GetProperty("Password208"), ob.GetProperty("hostname208"), true, MSG, ob.GetProperty("commonloglocation208"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 208 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205")
, ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 208 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  208 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                Thread.sleep(2000);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"),ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " is matching with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  NOT matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "Log check failed going to check in DB only");
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");

                    int DBretrytimes = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrycount"));
                    int Retry_Waiting_period = Integer.parseInt(ob.GetProperty("MISDB_datafetch_retrywaitinginterval"));

                    boolean retrypassed = false;
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>Fetched Retry time from property </b>" + DBretrytimes + "<b>Fetched Retry interval from property </b>" + Retry_Waiting_period);

                    for (int k = 0; k < DBretrytimes; k++) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Retry </b>" + k);


                        TestBase.setcurrenttime();
                        Thread.sleep(1000);
                        Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                        String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                        Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(100, responseid, PushRecieverLivetablename);


                        if (!MISDATA.isEmpty() && (MISDATA.get("statusdesc").contentEquals("SUBMITTED TO SMSC"))) {


                            ExtentBASETEST.extentReportsDemo("PASS", "PASSED IN  RETRY " + k + "--->MISTABLEDATA-->" + MISDATA.toString());
                            retrypassed = true;
                            break;
                        } else {
                            ExtentBASETEST.extentReportsDemo("INFO", "Going to try again IN  RETRY after " + Retry_Waiting_period + " Miliseconds");
                            Thread.sleep(Retry_Waiting_period);
                        }

                    }

                    if (!retrypassed) {
                        ExtentBASETEST.extentReportsDemo("FAIL", "FAILED  IN all  RETRY FOR " + responseid);

                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());


        }


    }

    @DataProvider
    public Object[][] getXMLSPECIFICROWforCLIYES() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 9, "TestData_MULTISMSXMLListener1.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getXMLSPECIFICROWforCLINO")
    public void CLINO_MULTISMSXMLListener1(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language) {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_MULTISMSXMLListener1")+" "+"<b>MultiSMSXMLListner1 --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the OPEN CLI NO<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id");// + "-1";
                System.out.println(responseid);
                Thread.sleep(2000);
                // LISTNER LOG FETCH CODE
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 187 server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if(ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username208"), ob.GetProperty("Password208"), ob.GetProperty("hostname208"), true, MSG, ob.GetProperty("commonloglocation208"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 208 processor SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), ob.GetProperty("commonloglocation205")
, ob.GetProperty("PROCESSORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 208 processor server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  208 processor SERVER</b>");
                    }
                }

                //


                //ORECHESTRATOR  LOG CHECK
                if(ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRING(responseid, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));

                        ExtentBASETEST.extentReportsDemo("INFO", "<b> below is the 206 orchestrator server log info--> </b>"+responseString );
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                //
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,response_id);
                boolean SMSCRESULT = LinuxLogReader.CheckSMSCLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"),ob.GetProperty("rcvrlogfileName"));
                if (SMSCRESULT) {
                    JSONObject jsonbody = LinuxLogReader.GETSMSCJSONLOG(responseid, ob.GetProperty("Username207"), ob.GetProperty("Password207"), ob.GetProperty("hostname207"), false, "DUMMY", ob.GetProperty("commonloglocation207"),ob.GetProperty("rcvrlogfileName"));
                    ExtentBASETEST.extentReportsDemo("INFO", "COMPLETE JSON DETAILS-->" + jsonbody.toString());
                    String actualsender = jsonbody.get("l").toString();
                    String recievedsender = jsonbody.get("as").toString();
                    if (!actualsender.contentEquals(recievedsender)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "For Request " + responseid + "  Actual sender is " + actualsender + " are diffrent   with  Recieved sender is " + recievedsender);

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "For Request " + responseid + "  Actual sender is " + actualsender + " is  matching with  Recieved sender is " + recievedsender + " although OPEN CLI WAS NO");

                    }
                } else {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The responseID " + responseid + "  is not sent to SMSC");
                    Assert.assertTrue(SMSCRESULT, "The responseID " + responseid + "  is not sent to SMSC");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
        }
    }


    @DataProvider
    public Object[][] getXMLSPECIFICROWforCLINO() {

        Object data[][] = ExcelUtils.getTestData("SPECIFICDATA", 10, "TestData_MULTISMSXMLListener1.xlsx");

        return data;
    }





    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void OPENTEMPLATE_MULTISMSXMLListener1() {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_MULTISMSXMLListener1")+" "+"<b>MULTISMSXMLListener1 --> " + "OPENTEMPLATE" + "</b>");
        try {
            String dtm = "676767";
            String dpi = "84343556";
            String tc = "0";


            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/XmlSmsListnerOPENTEMPLATE.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the OPEN CLI NO<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");
                try {
                    Thread.sleep(4000);
                } catch (Exception e) {

                }
                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");

                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);
                if(MISDATA.isEmpty())
                {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                    Assert.assertEquals(false,true,"The MISDATA could not be pulled from DB ");
                }
                ExtentBASETEST.extentReportsDemo("INFO", "this is Expected tc -->  <b>" + tc + "</b>" + " dpi --> <b>" + dpi + "</b>" + "dtm --> <b>" + dtm + "</b>");

                ExtentBASETEST.extentReportsDemo("INFO", "this is Actual --> tc from DB  --> <b>" + MISDATA.get("tempid_category") + "</b>" + " dpi from DB  --> <b>" + MISDATA.get("dlt_peid") + "</b>" + " dtm from DB  --><b>" + MISDATA.get("dlt_tempid") + "</b>");


                String act_tc = MISDATA.get("tempid_category");
                String act_dpi = MISDATA.get("dlt_peid");
                String act_dtm = MISDATA.get("dlt_tempid");


                try {
                    if(act_dpi.isEmpty()||act_dpi.isEmpty()||act_dtm.isEmpty())
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>Some fetched records in db are blank please check </b> this is Actual --> tc from DB  --> <b>" + MISDATA.get("tempid_category") + "</b>" + " dpi from DB  --> <b>" + MISDATA.get("dlt_peid") + "</b>" + " dtm from DB  --><b>" + MISDATA.get("dlt_tempid") + "</b>" );

                        Assert.fail("\"this is Actual --> tc from DB  --> <b>\" + MISDATA.get(\"tempid_category\") + \"</b>\" + \" dpi from DB  --> <b>\" + MISDATA.get(\"dlt_peid\") + \"</b>\" + \" dtm from DB  --><b>\" + MISDATA.get(\"dlt_tempid\") + \"</b>\"");
                    }

                    if (tc.contentEquals(act_tc) && dpi.contentEquals(act_dpi) && dtm.contentEquals(act_dtm)) {
                        System.out.println("Message is passed with dtm dpi tc");
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The actual and expected  tc , dpi and dtm are matching</b>");
                    } else {
                        System.out.println("Message is not passed with dtm ,dpi & tc parameter");
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The actual and expected  tc , dpi and dtm are Not matching</b>");
                    }
                } catch (NullPointerException e) {
                    System.out.println("Please check the live table...");
                    ExtentBASETEST.extentReportsDemo("FAIL", e + "<b> Please check the live table...</b>");
                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }
        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());
        }
    }

    @Test(priority = 2, enabled = false, invocationCount = 1)
    public void Check_TEMP_MULTISMSXMLListener1() {
        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_MULTISMSXMLListener1")+" "+"<b>TEMP --> </b>");
        try {


            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");


           FileReader read=new FileReader(XMLDataInFile);
            //BufferedReader br = new BufferedReader(new FileReader(XMLDataInFile));
            String xmldata="";
int i;
            while ((i = read.read()) != -1)
            {
                xmldata=xmldata+(char)i;
                // Print all the content of a file

        }

            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(xmldata);


            System.out.println("XMLDATA IS  " + "xmlStr="+xmldata);
            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the TEMPLATECONVERSTION<b>");
            Response response = request.post();

            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Response ID " + response.body().asString());



        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }
    @Test(dataProvider = "getNTEXTDARSDATA", priority = 1, enabled = false, invocationCount = 1)
    public void Check_DARS_CASES_MultiSMSXMLListener(String functionname, String userid, String passwd, String AppID, String from, String to, String TestMSG, String alert, String selfID, String Intflag, String Contenttype, String language,  String ExpectedSMSC) {

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_MULTISMSXMLListener1")+" "+"<b>MULTISMSXMLListener_DARS_TEMPLATE_TESTCASES--> " + functionname + "</b>");
        // Specify the base URL to the RESTful web service
        try
        {
            XML_OPERATIONS.SetMULTISMSXMLListener(functionname, userid, passwd, AppID, from, to, TestMSG, alert, selfID, Intflag, Contenttype, language, "MULTISMSXMLListener.xml","BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Template matching<b>");
            Response response = request.post();
            System.out.println(response);
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);

            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                String responseid = response.asString().replaceAll("[\\n\\t ]", "");


                System.out.println("Response Object  " + responseid);
                //RunCommand.CHECKSPECIFICRECIEVER1("saurabhg","saurabhg@123","10.0.6.141",22,responseid);
                ExtentBASETEST.extentReportsDemo("INFO", "Response recieved " + "<b>" + responseid + "</b>");

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(1000, responseid, PushRecieverLivetablename);

                String actualsmsc = MISDATA.get("smscname");
                if(actualsmsc==null)
                {
                    actualsmsc = "BLK";
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + functionname + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
                    Assert.fail("<b>The " + functionname + "</b> has been FAILED  <br> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + actualsmsc + "</b>      Kindly check the DARS Page or data base to make sure that matching SMSC is defined correctly");
                }
                if (actualsmsc.isEmpty()) {
                    actualsmsc = "BLK";
                }

                ExtentBASETEST.extentReportsDemo("INFO", "this is actual  msg from live sql table <b>" + MISDATA.get("statusdesc") + "</b>");
                try {
                    if (ExpectedSMSC.contentEquals(ExpectedSMSC)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The " + functionname + "</b> has been passed <br> <font color=green> Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b> </font>");
                        ExtentBASETEST.extentReportsDemo("INFO", "<font color=blue>The MIS data for the same is below --> <br> " + MISDATA+"</font>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The " + functionname + "</b> has been FAILED  <br> <font color=red>Expected smsc was <b> " + ExpectedSMSC + " </b><br> Actual SMSC is <b>" + ExpectedSMSC + "</b></font>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            //Assert.fail(e.toString());

        }


    }


    @DataProvider
    public Object[][] getNTEXTDARSDATA() {

        Object data[][] = ExcelUtils.getTestData("DARS", 0, "TestData_MULTISMSXMLListener1.xlsx");

        return data;
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_MULTISMSXMLListener1_CAPABILITY_NO() {

        String  ph[]=new String[10];
        ph[1]="9838301908";
        String capability="NO";

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_MULTISMSXMLListener1")+" "+"<b>BASEURI_MULTISMSXMLListener1 -->XMLSMSLISTENER_RCSCAPABLE_NO "+"</b>");
        try {
            // Specify the base URL to the RESTful web service

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MultiSMSXMLListener1_RCS_NO.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the RCS Capability<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                boolean DLRCHECK = false;
                String RCSRECIEVRTABLENAME = "";
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(5000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                        if(capability.contentEquals("YES")) {

                            if (responseString.contains("RCS capable mobile list -> [+91" + ph[1] + "]")) {
                                ExtentBASETEST.extentReportsDemo("PASS", "<b> Capability check is passed "+"RCS capable mobile list -> [+91" + ph[1] + "]");

                            } else {
                                ExtentBASETEST.extentReportsDemo("FAIL", "<b> Capability check is NOT Passed for number</b>");

                            }
                        }


//RCS capable mobile list -> [+919971498470]

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {


                    ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(capability.contentEquals("YES")) {
                        if (submitstatus.contentEquals("submitted")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                            DLRCHECK = true;
                            joinid = MISDATA.get("joinid");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);
                            Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);

                        }
                    } else if(capability.contentEquals("NO"))
                    {
                        if (submitstatus.contentEquals("notCapable") ) {
                            ExtentBASETEST.extentReportsDemo("PASS", " DB has updated with status "+"<b>"+submitstatus+"</b>");
                            String expectedQname="RCS_NOT_CAPABLE_+91" + ph[1];
                            ExtentBASETEST.extentReportsDemo("INFO", " <b> Now going to check not capable redis Q..</b>");

                            String Qdata=JedisQueueReader.GetRedisdata(ob.GetProperty("redis_server_ip"),ob.GetProperty("redis_server_user"),ob.GetProperty("redis_server_pass"),ob.GetProperty("redis_server_host"),ob.GetProperty("redis_server_port"),ob.GetProperty("redis_host_pass"),expectedQname);
                            //  ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);


                            if(Qdata.contentEquals("1"))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);

                            }
                            else
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has NOT  been set..Please check Redis property and investigate Manually ");


                            }
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " NOT CAPABLE CHECK IS FAILED AND RCS status in DB is "+"<b>"+submitstatus+"</b>");

                        }
                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);


                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }


    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count)
    public void CHECK_RCS_MULTISMSXMLListener1_CAPABILITY_YES() {

        String  ph[]=new String[10];
        ph[1]="7838787657";
        String capability="YES";

        ExtentBASETEST.STARTTEST("Request URL-->"+ob.GetProperty("BASEURI_MULTISMSXMLListener1")+" "+"<b>BASEURI_MULTISMSXMLListener1 -->XMLSMSLISTENER_RCSCAPABLE_YES "+"</b>");
        try {
            // Specify the base URL to the RESTful web service

            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MultiSMSXMLListener1_RCS_YES.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the RCS Capability<b>");
            Response response = request.post();


            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id") + "-1";
                System.out.println(responseid);
                boolean DLRCHECK = false;
                String RCSRECIEVRTABLENAME = "";
                //RCS COMPONENT  LOG CHECK
                if(ob.GetProperty("checkRCSLOG").contentEquals("true")) {
                    Thread.sleep(5000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), false, "dummy", ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 85 RCS COMPONENT </b>");
                        String responseString = LinuxLogReader.RUNLINUXCOMMANDANDGETSTRINGFORCAPABILITYCHECK(responseid, ob.GetProperty("Username85"), ob.GetProperty("Password85"), ob.GetProperty("hostname85"), ob.GetProperty("rcsloglocation"), ob.GetProperty("RCSLogfilename"));
                        if(capability.contentEquals("YES")) {

                            if (responseString.contains("RCS capable mobile list -> [+91" + ph[1] + "]")) {
                                ExtentBASETEST.extentReportsDemo("PASS", "<b> Capability check is passed "+"RCS capable mobile list -> [+91" + ph[1] + "]");

                            } else {
                                ExtentBASETEST.extentReportsDemo("FAIL", "<b> Capability check is NOT Passed for number</b>");

                            }
                        }


//RCS capable mobile list -> [+919971498470]

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON 85 RCS COMPONENT</b>");
                    }
                }

                //

                TestBase.setcurrenttime();
                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String RCSDLRTABLENAME = Livetablename.get("RCSDLRTABLENAME");
                RCSRECIEVRTABLENAME = Livetablename.get("RCSRECIEVERTABLENAME");
                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRCSRECIEVERTABLE(500, responseid, RCSRECIEVRTABLENAME);
                String joinid="";

                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", " The MISDATA could not be pulled from DB ");
                } else {


                    ExtentBASETEST.extentReportsDemo("INFO", "MISTABLEDATA-->" + MISDATA.toString());

                    String submitstatus=MISDATA.get("statusdesc");
                    if(capability.contentEquals("YES")) {
                        if (submitstatus.contentEquals("submitted")) {
                            ExtentBASETEST.extentReportsDemo("INFO", " THE RCS REQUEST HAS BEEN SUCCESSFULLY SUBMITTED TO RCS");
                            DLRCHECK = true;
                            joinid = MISDATA.get("joinid");
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);
                            Assert.fail("THE RCS REQUEST HAS NOT  BEEN SUCCESSFULLY SUBMITTED TO RCS and actual status is " + submitstatus);

                        }
                    } else if(capability.contentEquals("NO"))
                    {
                        if (submitstatus.contentEquals("notCapable") ) {
                            ExtentBASETEST.extentReportsDemo("PASS", " DB has updated with status "+"<b>"+submitstatus+"</b>");
                            String expectedQname="RCS_NOT_CAPABLE_+91" + ph[1];
                            ExtentBASETEST.extentReportsDemo("INFO", " <b> Now going to check not capable redis Q..</b>");

                            String Qdata=JedisQueueReader.GetRedisdata(ob.GetProperty("redis_server_ip"),ob.GetProperty("redis_server_user"),ob.GetProperty("redis_server_pass"),ob.GetProperty("redis_server_host"),ob.GetProperty("redis_server_port"),ob.GetProperty("redis_host_pass"),expectedQname);
                            //  ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);


                            if(Qdata.contentEquals("1"))
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has been set for ..</b>" +"RCS_NOT_CAPABLE_+91" + ph[1]+ " with data as "+Qdata);

                            }
                            else
                            {
                                ExtentBASETEST.extentReportsDemo("INFO", " <b> Not capable redis Q has NOT  been set..Please check Redis property and investigate Manually ");


                            }
                        } else {
                            ExtentBASETEST.extentReportsDemo("FAIL", " NOT CAPABLE CHECK IS FAILED AND RCS status in DB is "+"<b>"+submitstatus+"</b>");

                        }
                    }
                }
                Thread.sleep(10000);

                if(DLRCHECK)
                {
                    Map<String, String> DLRDATA = SQLPOOL.GETRCSDATAFROMDLRLIVETABLE(500, joinid, RCSDLRTABLENAME);

//test
                    if (DLRDATA.isEmpty()) {
                        ExtentBASETEST.extentReportsDemo("INFO", " The RCS DLRDATA could not be pulled from DB ");
                    } else {
                        if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED, READ</b>");
                        }else if(DLRDATA.containsValue("sent") && DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT, DELIVERED </b>");
                        }
                        else if(DLRDATA.containsValue("sent") && ! DLRDATA.containsValue("delivered") && ! DLRDATA.containsValue("read"))
                        {
                            ExtentBASETEST.extentReportsDemo("INFO", " The RCS Webhook has been successfully recieved and the current status of RCS message is  <b>SENT </b>");
                        }


                        ExtentBASETEST.extentReportsDemo("PASS", "RCS_DLRDATA-->" + DLRDATA.toString());
                    }

                }


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
            Assert.fail(e.toString());

        }
    }

    @Test(priority = 2, enabled = false, invocationCount = SetandGetGlobalVariable.count, dataProvider = "getJUM_10326")
    public void getJUM_10326_MULTISMSXMLListener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language, String contertedtext) {
        ExtentBASETEST.STARTTEST("Request URL-->" + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + " " + "<b>MULTISMSXMLListener1 --> " + FunctionName + "</b>");
        try {
            // Specify the base URL to the RESTful web service and pass the XML with the given data
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml", "BLK");

            // Load the XML file to send in the request body
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            // Send the request to the API
            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API for template conversion <b>");
            Response response = request.post();

            // Log the request object and status code
            System.out.println("Request Object: " + request);
            int statusCode = response.getStatusCode();
            System.out.println("Status code: " + statusCode);


            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response received");
                System.out.println(statusCode);
                System.out.println(response.body().asString());
                String temp = response.body().asString();

                XmlPath xmlPath = new XmlPath(temp);
                String responseid = xmlPath.get("push.response-id");
                System.out.println("Response ID: " + responseid);

                Thread.sleep(6000);
                TestBase.setcurrenttime();

                Map<String, String> Livetablename = TestBase.Normal_calculateandsetlivetablename();
                String PushRecieverLivetablename = Livetablename.get("PUSHTABLENAME");


                Map<String, String> MISDATA = SQLPOOL.GETMISDATAFROMRECIEVERTABLE(5000, responseid, PushRecieverLivetablename);


                if (MISDATA.isEmpty()) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "The MISDATA could not be pulled from DB");
                    Assert.assertEquals(false, true, "The MISDATA could not be pulled from DB");
                }


                ExtentBASETEST.extentReportsDemo("INFO", "MIS DATA for response ID " + responseid + ": " + MISDATA.toString());


                String actualmsg = MISDATA.get("messagetext");

                System.out.println("This is the expected converted message from Excel: " + contertedtext);
                ExtentBASETEST.extentReportsDemo("INFO", "Expected converted message from Excel: <b>" + contertedtext + "</b>");

                System.out.println("This is the actual converted message from live SQL table: " + actualmsg);
                ExtentBASETEST.extentReportsDemo("INFO", "Actual converted message from live SQL table: <b>" + actualmsg + "</b>");


                try {
                    if (contertedtext.contentEquals(actualmsg)) {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The message conversion is successful</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The message conversion is NOT successful</b>");
                    }
                } catch (NullPointerException e) {
                    ExtentBASETEST.extentReportsDemo("FAIL", "<b>Please check the live table...</b>");
                }

            } else {

                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");
            }

        } catch (Exception e) {

            ExtentBASETEST.extentReportsDemo("FAIL", e.toString());
            Assert.fail(e.toString());
        }

    }

    @DataProvider
    public Object[][] getJUM_10326() {

        Object data[][] = ExcelUtils.getTestData("JUM_10326", 0, "TestData_MULTISMSXMLListener1.xlsx");

        return data;
    }



    @Test(priority = 2, enabled = false, dataProvider = "getXMLCredencedata")
    public void Check_Credence_MULTISMSXMLListener1_Listener(String FunctionName, String UserID, String Passd, String APPID, String FROM, String TO, String MSG, String ALERT, String SELFID, String INTFLAG, String Contenttype, String Language,String credenceCHECK) {
        ExtentBASETEST.STARTTEST("<b>MULTISMSXMLListener1_Listener_Credence--> " + FunctionName + "</b>");
        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST URL " + ob.GetProperty("BASEURI_MULTISMSXMLListener1") + "</b>");

        try {
            // Specify the base URL to the RESTful web service
            XML_OPERATIONS.SetMULTISMSXMLListener(FunctionName, UserID, Passd, APPID, FROM, TO, MSG, ALERT, SELFID, INTFLAG, Contenttype, Language, "MULTISMSXMLListener1.xml","BLK");
            File XMLDataInFile = new File(System.getProperty("user.dir") + "/src/main/resources/Util/XML_REPOSITORY/MULTISMSXMLListener1.xml");
            RequestSpecification request = RestAssured.given().contentType(ContentType.XML).body(XMLDataInFile);

            RestAssured.given().headers(requestHeaders);
            ExtentBASETEST.extentReportsDemo("INFO", "<b style=\"background-color:orange;\">Going to hit the API to check the Credence<b>");
            Response response = request.post();
            System.out.println(response);
            System.out.println("Request Object  " + request);
            int statusCode = response.getStatusCode();

            System.out.println("Status code  " + statusCode);
            if (statusCode == 200) {
                ExtentBASETEST.extentReportsDemo("INFO", "200 Response recieved");
                System.out.println(response.body().asString());
                String temp = response.body().asString();
                XmlPath xmlPath = new XmlPath(temp);
                String response_id = xmlPath.get("push.response-id");// + "-1";
                System.out.println(response_id);
                boolean DLRCHECK = false;
                String DLRLivetablename = "";
                Thread.sleep(2000);
//start
                // LISTNER LOG FETCH CODE
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNER98SERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username187"), ob.GetProperty("Password187"), ob.GetProperty("hostname187"), true, MSG, ob.GetProperty("commonloglocation187"), ob.GetProperty("rcvrlogfileName"));
                    if (LISTNER98SERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 187 SERVER</b>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on 187 Listner SERVER</b>");
                    }
                }
                //

                //PROCESSOR LOG CHECK
                if (ob.GetProperty("checkComponentLog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username205"), ob.GetProperty("Password205"), ob.GetProperty("hostname205"), true, MSG, ob.GetProperty("commonloglocation205"), ob.GetProperty("PROCESSORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 205 processor SERVER</b>");

                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected on  205 processor SERVER</b>");
                    }
                }
                //ORECHESTRATOR  LOG CHECK
                if (ob.GetProperty("CheckOrcheslog").contentEquals("true")) {
                    Thread.sleep(2000);
                    boolean LISTNERPROCESSORSERVERRESULT = LinuxLogReader.checkComponentLog(response_id, ob.GetProperty("Username206"), ob.GetProperty("Password206"), ob.GetProperty("hostname206"), true, MSG, ob.GetProperty("commonloglocation206"), ob.GetProperty("ORCHESTRATORLOGFILENAME"));
                    if (LISTNERPROCESSORSERVERRESULT) {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST RECIEVED ON 206 Orchestrator SERVER</b>");
                    } else {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b>Log info could not be detected  ON 206 orchestrator SERVER</b>");
                    }
                }

                Thread.sleep(5000);
//test

                if (true) {


                    String credendedata=JedisQueueReader.Getcredenceredisdata(response_id);
                    if(credendedata.isEmpty()&& credenceCHECK.contentEquals("YES"))
                    {
                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The data is not found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+response_id+" but is was expected to be in Credence Q</b>");

                    }
                    else if(credendedata.isEmpty()&& credenceCHECK.contentEquals("NO"))
                    {
                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The data is not found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+response_id+" AND  is was ALSO NOT expected to be in Credence Q</b>");

                    }
                    else if((!credendedata.isEmpty()) && credenceCHECK.contentEquals("NO"))
                    {
                        ExtentBASETEST.extentReportsDemo("INFO", "<b> CREDENCE DATA IS---></b>"+credendedata);

                        ExtentBASETEST.extentReportsDemo("FAIL", "<b>The data  is  found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+response_id+" but is was NOT expected to be in Credence Q</b>");

                    }

                    else if((!credendedata.isEmpty()) && credenceCHECK.contentEquals("YES"))
                    {

                        ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST HAS BEEN  FORWARDED TO CREDENCE ,DATA IS---></b>"+credendedata);

                        ExtentBASETEST.extentReportsDemo("PASS", "<b>The data is found in THIRDPARTY_SEC_RETRY_QUEUE for responseid "+response_id+" AND  is was ALSO  expected to be in Credence Q</b>");

                    }



                } else {
                    ExtentBASETEST.extentReportsDemo("INFO", "<b>REQUEST NOT RECIEVED ON SMS ROUTER COMPONENT</b>");
                }

                //end


            } else {
                ExtentBASETEST.extentReportsDemo("FAIL", "Status code is not success");
                Assert.fail("Status code is not success");

            }


        } catch (Exception e) {
            ExtentBASETEST.extentReportsDemo("INFO", e.toString());
//            Assert.fail(e.toString());

        }
    }


    @DataProvider
    public Object[][] getXMLCredencedata() {
        Object data[][] = ExcelUtils.getTestData("JUM-5768_CREDENCE", 0, "TestData_MULTISMSXMLListener1.xlsx");
        return data;
    }
}


